package com.yumchina.ai.recommendation;

import com.alibaba.fastjson.JSON;
import com.yumchina.ai.recommendation.domain.City;
import com.yumchina.ai.recommendation.domain.Order;
import org.apache.flink.api.java.tuple.Tuple2;

import java.util.List;

public class JsonTest {
    private void testCity() {
        String s = "{\"date\":\"20190310\",\"cityName\":\"上海\",\"cityCode\":\"00010\"}";
        City city = JSON.parseObject(s, City.class);
        System.out.println(city.toString());
    }

    private void testOrder() {
        String HEADER = "[[Order success, data:";
        String str = "[[Order success, data:{\"transactionId\":\"1552558707626099141\",\"userCode\":\"1C89DD228EF3C57BFFCF8F0F23E3CF4C\",\"orderTime\":1552558714,\"promiseTime\":1552559014,\"orderAmount\":4600,\"realOrderAmount\":4600,\"orderingTime\":1552558726,\"storeCode\":\"HZH118\",\"channel\":\"SuperApp\",\"marketCode\":\"012\",\"cityCode\":\"00031\",\"cityName\":\"宁波\",\"brand\":\"KFC_PRE\",\"orderItems\":[{\"orderItemId\":\"1552558707626099141\",\"linkId\":\"100004559\",\"sizeId\":null,\"baseId\":null,\"num\":1,\"price\":3500,\"realPrice\":3500,\"type\":1,\"couponCode\":null,\"promotionCode\":null,\"itemLinkIds\":[{\"linkId\":\"26649\",\"sizeId\":null,\"baseId\":null,\"num\":1,\"price\":0,\"round\":-1},{\"linkId\":\"100002253\",\"sizeId\":null,\"baseId\":null,\"num\":1,\"price\":0,\"round\":-1},{\"linkId\":\"100000437\",\"sizeId\":null,\"baseId\":null,\"num\":1,\"price\":0,\"round\":-1},{\"linkId\":\"28314\",\"sizeId\":null,\"baseId\":null,\"num\":1,\"price\":0,\"round\":-1}]},{\"orderItemId\":\"1552558707626099141\",\"linkId\":\"100018884\",\"sizeId\":null,\"baseId\":null,\"num\":1,\"price\":1100,\"realPrice\":1100,\"type\":0,\"couponCode\":null,\"promotionCode\":null,\"itemLinkIds\":null},{\"orderItemId\":\"1552558707626099141\",\"linkId\":\"0\",\"sizeId\":null,\"baseId\":null,\"num\":1,\"price\":4600,\"realPrice\":4600,\"type\":0,\"couponCode\":null,\"promotionCode\":null,\"itemLinkIds\":null}]}]]";
        str = str.substring(HEADER.length(), str.length() - 2);

        str = "{\"transactionId\":\"1554017282641092013\",\"userCode\":\"F4614EDE0B1B3B7CA5C2D1A3126716FD\",\"orderTime\":1554017310,\"promiseTime\":1554017610,\"orderAmount\":1700,\"realOrderAmount\":1000,\"orderingTime\":35,\"storeCode\":\"SZH271\",\"channel\":\"SuperApp\",\"marketCode\":\"011\",\"cityCode\":\"00036\",\"cityName\":\"苏州\",\"brand\":\"KFC_PRE\",\"orderItems\":[{\"orderItemId\":\"1554017282641092013\",\"linkId\":\"100017166\",\"sizeId\":null,\"baseId\":null,\"num\":1,\"price\":1700,\"realPrice\":1000,\"type\":3,\"couponCode\":\"810481145770676262\",\"promotionCode\":\"HN7BZSI0KH\",\"itemLinkIds\":null},{\"orderItemId\":\"1554017282641092013\",\"linkId\":\"0\",\"sizeId\":null,\"baseId\":null,\"num\":1,\"price\":1000,\"realPrice\":1000,\"type\":0,\"couponCode\":null,\"promotionCode\":null,\"itemLinkIds\":null}]}";
        Order order = JSON.parseObject(str,Order.class);
        System.out.println(order.toOrderString());
        List<String> orderItems = order.toOrderItemString();
        for (String item : orderItems) {
            System.out.println(item);
        }

        Tuple2 tuple2 = new Tuple2<>(order.toOrderString(), order.toOrderItemString());
        System.out.println(tuple2.toString());
    }


    public static void main(String[] args) {
        JsonTest test = new JsonTest();
        test.testOrder();
    }
}
