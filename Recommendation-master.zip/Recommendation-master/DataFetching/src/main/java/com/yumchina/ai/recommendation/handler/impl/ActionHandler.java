package com.yumchina.ai.recommendation.handler.impl;

import com.alibaba.fastjson.JSON;
import com.yumchina.ai.recommendation.domain.Action;
import com.yumchina.ai.recommendation.enums.TopicType;
import com.yumchina.ai.recommendation.handler.Handler;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.flink.streaming.api.datastream.DataStream;

public class ActionHandler extends Handler {
    @Override
    public void transform(DataStream<String> stream) {
        DataStream<String> result = stream.map(
                str ->  JSON.parseObject(str, Action.class).toString()
        ).filter(str -> str != null);

        try{
            addHdfsSink(result, TopicType.TOPIC_ACTION.getName());
        }catch (Exception e) {
            LOG.error("Fail to add ACTION Sink");
            LOG.error(ExceptionUtils.getStackTrace(e));
        }
    }
}
