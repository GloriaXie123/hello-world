package com.yumchina.ai.recommendation.domain;

import com.yumchina.ai.recommendation.environment.GlobalConfig;

public class CityLevel {
    private String date;
    private String cityCode;
    private String cityLevel;

    @Override
    public String toString() {
        String splitter = GlobalConfig.getSplitter();
        return date + splitter
                + cityCode + splitter
                + cityLevel ;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCityLevel() {
        return cityLevel;
    }

    public void setCityLevel(String cityLevel) {
        this.cityLevel = cityLevel;
    }



}
