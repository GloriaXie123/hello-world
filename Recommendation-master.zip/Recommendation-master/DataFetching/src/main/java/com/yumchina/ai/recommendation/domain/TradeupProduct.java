package com.yumchina.ai.recommendation.domain;

import com.yumchina.ai.recommendation.environment.GlobalConfig;

public class TradeupProduct {
    private String date;
    private int type;
    private String marketCodes;
    private String cityCodes;
    private String storeCodes;
    private String promotionCode;
    private String productName;
    private String linkId;
    private String systemId;
    private int price;

    public String toString() {
        String splitter = GlobalConfig.getSplitter();
        return date + splitter
                + type + splitter
                + marketCodes + splitter
                + cityCodes + splitter
                + storeCodes + splitter
                + productName + splitter
                + linkId + splitter
                + systemId + splitter
                + price;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getMarketCodes() {
        return marketCodes;
    }

    public void setMarketCodes(String marketCodes) {
        this.marketCodes = marketCodes;
    }

    public String getCityCodes() {
        return cityCodes;
    }

    public void setCityCodes(String cityCodes) {
        this.cityCodes = cityCodes;
    }

    public String getStoreCodes() {
        return storeCodes;
    }

    public void setStoreCodes(String storeCodes) {
        this.storeCodes = storeCodes;
    }

    public String getPromotionCode() {
        return promotionCode;
    }

    public void setPromotionCode(String promotionCode) {
        this.promotionCode = promotionCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getLinkId() {
        return linkId;
    }

    public void setLinkId(String linkId) {
        this.linkId = linkId;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

}
