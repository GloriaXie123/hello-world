package com.yumchina.ai.recommendation.domain;

import com.yumchina.ai.recommendation.environment.GlobalConfig;

public class City {
    public String date;
    public String cityName;
    public String cityCode;

    @Override
    public String toString() {
        String splitter = GlobalConfig.getSplitter();
        return date + splitter
                + cityName + splitter
                + cityCode;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

}
