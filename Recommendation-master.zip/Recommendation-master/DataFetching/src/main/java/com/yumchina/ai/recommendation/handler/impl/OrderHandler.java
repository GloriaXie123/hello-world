package com.yumchina.ai.recommendation.handler.impl;

import com.alibaba.fastjson.JSON;
import com.yumchina.ai.recommendation.domain.Order;
import com.yumchina.ai.recommendation.enums.TopicType;
import com.yumchina.ai.recommendation.handler.Handler;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.streaming.api.datastream.DataStream;

import java.util.List;

public class OrderHandler extends Handler {
    private static final String HEADER = "[[Order success, data:";

    @Override
    public void transform(DataStream<String> stream) {
        DataStream<Tuple3<String, List<String>, List<String>>> result = stream.map(
                new MapFunction<String, Tuple3<String, List<String>, List<String>>>() {
                    @Override
                    public Tuple3<String, List<String>, List<String>> map(String str) {
                        try {
                            //LOG.info("-- Received ORDER msg ---: " + str);
                            str = str.substring(HEADER.length(), str.length() - 2);
                            Order order = JSON.parseObject(str, Order.class);
                            //LOG.info("-- Parsed ORDER msg ---: " + order.toString());
                            return new Tuple3<>(order.toOrderString(), order.toOrderItemString(), order.toItemLinkIdString());
                        } catch (Exception e) {
                            LOG.error("fail to process ORDER string: " + str + ", error msg: ");
                            LOG.error(ExceptionUtils.getStackTrace(e));
                            return null;
                        }
                    }
                }).filter(tuple -> tuple != null);

        try {
            //写order
            DataStream<String> orderStream = result
                    .map(new Tuple3Map1());
            addHdfsSink(orderStream, TopicType.TOPIC_ORDER.getName());

            //写orderItem
            DataStream<String> orderItemStream = result
                    .map(new Tuple3Map2())
                    .flatMap(new ItemsFlatMap());
            addHdfsSink(orderItemStream, TopicType.TOPIC_ORDER_ITEM.getName());

            //写itemLinkId
            DataStream<String> itemLinkIdStream = result
                    .map(new Tuple3Map3())
                    .flatMap(new ItemsFlatMap());
            addHdfsSink(itemLinkIdStream, TopicType.TOPIC_ORDER_ITEM_LINKID.getName());

        } catch (Exception e) {
            LOG.error("Fail to add ORDER hdfs Sink");
            LOG.error(ExceptionUtils.getStackTrace(e));
        }
    }


}
