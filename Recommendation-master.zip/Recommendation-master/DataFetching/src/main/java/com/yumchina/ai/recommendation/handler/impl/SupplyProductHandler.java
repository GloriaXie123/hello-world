
package com.yumchina.ai.recommendation.handler.impl;

import com.alibaba.fastjson.JSON;
import com.yumchina.ai.recommendation.domain.SupplyProduct;
import com.yumchina.ai.recommendation.enums.TopicType;
import com.yumchina.ai.recommendation.handler.Handler;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.flink.streaming.api.datastream.DataStream;

public class SupplyProductHandler extends Handler {
    @Override
    public void transform(DataStream<String> stream) {
        DataStream<String> result = stream.map(
                string -> JSON.parseObject(string, SupplyProduct.class).toString()
        ).filter(str -> str != null);

        try{
            addHdfsSink(result, TopicType.TOPIC_SUPPLY_PRODUCT.getName());
        }catch (Exception e) {
            LOG.error("Fail to add SUPPLY PRODUCT hdfs Sink");
            LOG.error(ExceptionUtils.getStackTrace(e));
        }
    }
}