package com.yumchina.ai.recommendation.domain;

import com.yumchina.ai.recommendation.environment.GlobalConfig;

public class StoreProductItem {
    private String linkId;
    private String systemId;
    private Integer price;
    private String iMenuCn;
    private String iDescCn;
    private String iSalesFlag;
    private Long validFrom;
    private Long validTo;
    private Long startTime;
    private Long endTime;
    private String showNameCn;


    public String getLinkId() {
        return linkId;
    }

    public void setLinkId(String linkId) {
        this.linkId = linkId;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public String getiMenuCn() {
        return iMenuCn;
    }

    public void setiMenuCn(String iMenuCn) {
        this.iMenuCn = iMenuCn;
    }

    public String getiDescCn() {
        return iDescCn;
    }

    public void setiDescCn(String iDescCn) {
        this.iDescCn = iDescCn;
    }

    public String getiSalesFlag() {
        return iSalesFlag;
    }

    public void setiSalesFlag(String iSalesFlag) {
        this.iSalesFlag = iSalesFlag;
    }

    public Long getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(Long validFrom) {
        this.validFrom = validFrom;
    }

    public Long getValidTo() {
        return validTo;
    }

    public void setValidTo(Long validTo) {
        this.validTo = validTo;
    }

    public Long getStartTime() {
        return startTime;
    }

    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }

    public Long getEndTime() {
        return endTime;
    }

    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }

    public String getShowNameCn() {
        return showNameCn;
    }

    public void setShowNameCn(String showNameCn) {
        this.showNameCn = showNameCn;
    }

    public String toString() {
        String splitter = GlobalConfig.getSplitter();
        return getLinkId() + splitter
                + getSystemId();
    }

}
