package com.yumchina.ai.recommendation.domain;

import com.yumchina.ai.recommendation.environment.GlobalConfig;

public class Store {
    private String date;
    private String marketName;
    private String cityName;
    private String cityCode;
    private String marketCode;
    private String storeCode;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getMarketName() {
        return marketName;
    }

    public void setMarketName(String marketName) {
        this.marketName = marketName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getMarketCode() {
        return marketCode;
    }

    public void setMarketCode(String marketCode) {
        this.marketCode = marketCode;
    }

    public String getStoreCode() {
        return storeCode;
    }

    public void setStoreCode(String storeCode) {
        this.storeCode = storeCode;
    }

    @Override
    public String toString() {
        String splitter = GlobalConfig.getSplitter();
        return date + splitter
                + marketName + splitter
                + cityName + splitter
                + cityCode + splitter
                + marketCode + splitter
                + storeCode ;
    }

}
