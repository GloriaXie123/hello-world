package com.yumchina.ai.recommendation.environment;

import org.apache.flink.api.java.utils.ParameterTool;

public class GlobalConfig {
    private static String DEFAULT_ENV = "dev";
    private static String DEFAULT_KEBEROS_USER = "srv_kp_testuser";
    private static String DEFAULT_KAFKA_BROKER = "127.0.0.1:9010";
    private static String DEFAULT_BUCKET_FORMAT = "yyyy-MM-dd-HH";
    private static String DEFAULT_SPLITTER = "\t";
    private static long DEAULT_ROLL_INTERVAL = 60000L;

    private static ParameterTool parameter;

    public static void setParameter(ParameterTool parameter) {
        GlobalConfig.parameter = parameter;
    }

    public static String getEnv() {
        String env = parameter.get("ai.recommendation.env", DEFAULT_ENV);
        return env;
    }

    public static String getSplitter() {
        if (parameter == null) return DEFAULT_SPLITTER;
        String splitter = parameter.get("ai.recommendation.splitter", DEFAULT_SPLITTER);
        return splitter;
    }

    public static String getKeberosUser() {
        String user = parameter.get("ai.recommendation.keberos.user", DEFAULT_KEBEROS_USER);
        return user;
    }

    public static String getKafkaBroker() {
        String broker = parameter.get("ai.recommendation.kafka.broker", DEFAULT_KAFKA_BROKER);
        return broker;
    }

    public static long getRolloverInterval() {
        long interval = parameter.getLong("ai.recommendation.roll.interval", DEAULT_ROLL_INTERVAL);
        return interval;
    }

    public static String getBucketFormat() {
        String bucketFormat = parameter.get("ai.recommendation.bucket.format", DEFAULT_BUCKET_FORMAT);
        return bucketFormat;
    }

}
