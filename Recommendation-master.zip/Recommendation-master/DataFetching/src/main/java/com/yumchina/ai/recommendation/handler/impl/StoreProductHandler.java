package com.yumchina.ai.recommendation.handler.impl;

import com.alibaba.fastjson.JSON;
import com.yumchina.ai.recommendation.domain.StoreProduct;
import com.yumchina.ai.recommendation.enums.TopicType;
import com.yumchina.ai.recommendation.handler.Handler;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;

import java.util.List;

public class StoreProductHandler extends Handler {
    @Override
    public void transform(DataStream<String> stream) {
        DataStream<Tuple2<String, List<String>>> stream1 = stream.map(
                new MapFunction<String, Tuple2<String, List<String>>>() {
                    @Override
                    public Tuple2<String, List<String>> map(String str) {
                        try {
                            StoreProduct storeProduct =  JSON.parseObject(str, StoreProduct.class);
                            return new Tuple2<>(storeProduct.toString(), storeProduct.toItemString());
                        } catch (Exception e) {
                            LOG.error("fail to process STORE PRODUCT string: " + str + ", error msg: ");
                            LOG.error(ExceptionUtils.getStackTrace(e));
                            return null;
                        }
                    }
                }).filter(tuple -> tuple != null);
        try{
            //写storeProduct数据
            DataStream<String> storeProductStream = stream1
                    .map(new Tuple2Map1());
            addHdfsSink(storeProductStream, TopicType.TOPIC_STORE_PRODUCT.getName());

            //写storeProduct中linkId的数据
            DataStream<String> storeProductLinkIdStream = stream1
                    .map(new Tuple2Map2())
                    .flatMap(new ItemsFlatMap());;
            addHdfsSink(storeProductLinkIdStream, TopicType.TOPIC_STORE_PRODUCT_LINKID.getName());

        } catch (Exception e){
            LOG.error("Fail to add STORE PRODUCT hdfs Sink");
            LOG.error(ExceptionUtils.getStackTrace(e));
        }
    }



}
