package com.yumchina.ai.recommendation.domain;

import com.yumchina.ai.recommendation.environment.GlobalConfig;

import java.util.List;

public class OrderItem {
    private String orderItemId;
    private String linkId;
    private String sizeId;
    private String baseId;
    private int num;
    private int price;
    private int realPrice;
    private int type;
    private String couponCode;
    private String promotionCode;
    private List<OrderItemLinkId> itemLinkIds;

    @Override
    public String toString() {
        String splitter = GlobalConfig.getSplitter();
        return orderItemId + splitter
                + linkId + splitter
                + sizeId + splitter
                + baseId + splitter
                + num + splitter
                + price + splitter
                + realPrice + splitter
                + type + splitter
                + couponCode + splitter
                + promotionCode;
    }

    public String getOrderItemId() {
        return orderItemId;
    }

    public void setOrderItemId(String orderItemId) {
        this.orderItemId = orderItemId;
    }

    public String getLinkId() {
        return linkId;
    }

    public void setLinkId(String linkId) {
        this.linkId = linkId;
    }

    public String getSizeId() {
        return sizeId;
    }

    public void setSizeId(String sizeId) {
        this.sizeId = sizeId;
    }

    public String getBaseId() {
        return baseId;
    }

    public void setBaseId(String baseId) {
        this.baseId = baseId;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getRealPrice() {
        return realPrice;
    }

    public void setRealPrice(int realPrice) {
        this.realPrice = realPrice;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public String getPromotionCode() {
        return promotionCode;
    }

    public void setPromotionCode(String promotionCode) {
        this.promotionCode = promotionCode;
    }

    public List<OrderItemLinkId> getItemLinkIds() {
        return itemLinkIds;
    }

    public void setItemLinkIds(List<OrderItemLinkId> itemLinkIds) {
        this.itemLinkIds = itemLinkIds;
    }




}
