package com.yumchina.ai.recommendation.domain;

import com.yumchina.ai.recommendation.environment.GlobalConfig;

public class OrderItemLinkId {
    private String linkId;
    private String sizeId;
    private String baseId;
    private int num;
    private int price;
    private int round;

    @Override
    public String toString() {
        String splitter = GlobalConfig.getSplitter();
        return linkId + splitter
                + sizeId + splitter
                + baseId + splitter
                + num + splitter
                + price + splitter
                + round;
        
    }
   public String getLinkId() {
        return linkId;
    }

    public void setLinkId(String linkId) {
        this.linkId = linkId;
    }

    public String getSizeId() {
        return sizeId;
    }

    public void setSizeId(String sizeId) {
        this.sizeId = sizeId;
    }

    public String getBaseId() {
        return baseId;
    }

    public void setBaseId(String baseId) {
        this.baseId = baseId;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getRound() {
        return round;
    }

    public void setRound(int round) {
        this.round = round;
    }


}
