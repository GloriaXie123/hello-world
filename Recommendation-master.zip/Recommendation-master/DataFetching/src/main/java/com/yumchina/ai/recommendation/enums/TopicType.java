package com.yumchina.ai.recommendation.enums;

import java.util.ArrayList;
import java.util.List;

public enum TopicType {
    TOPIC_ORDER("order"),

    TOPIC_ORDER_ITEM("order_item"),

    TOPIC_ORDER_ITEM_LINKID("order_item_linkId"),

    TOPIC_CITY("city"),

    TOPIC_STORE("store"),

    TOPIC_TRADEUP_PRODUCT("tradeup_product"),

    TOPIC_RECOMMEND_FILTER("recommend_filter"),

    TOPIC_STORE_PRODUCT("store_product"),

    TOPIC_STORE_PRODUCT_LINKID("store_product_linkId"),

    TOPIC_SUPPLY_PRODUCT("supply_product"),

    TOPIC_CITY_LEVEL("city_level"),

    TOPIC_ACTION("action");

    private String name;

    TopicType(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public static List<String> getAllTopics() {
        List<String> all = new ArrayList<>();
        for (TopicType type : TopicType.values()) {
            all.add(type.getName());
        }
        return all;
    }
}
