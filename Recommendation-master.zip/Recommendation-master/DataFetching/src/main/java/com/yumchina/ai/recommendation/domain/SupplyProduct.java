package com.yumchina.ai.recommendation.domain;

import com.alibaba.fastjson.annotation.JSONField;
import com.yumchina.ai.recommendation.environment.GlobalConfig;

public class SupplyProduct {
    private String date;
    private String linkId;
    private int type;
    private String size;
    private String temperature;
    private String material;
    private String taste;
    private String makingWay;
    private int suitableNum;
    private int num;
    private int isNew;
    private int isForcedRecommend;
    private String subClass;
    private String category;
    @JSONField(name = "class")
    private String clazz;
    private String subCategory;

    @Override
    public String toString() {
        String splitter = GlobalConfig.getSplitter();
        return date + splitter
                + linkId + splitter
                + type + splitter
                + size + splitter
                + temperature + splitter
                + material + splitter
                + taste + splitter
                + makingWay + splitter
                + suitableNum + splitter
                + num + splitter
                + isNew + splitter
                + isForcedRecommend + splitter
                + subClass + splitter
                + category + splitter
                + clazz + splitter
                + subCategory  ;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLinkId() {
        return linkId;
    }

    public void setLinkId(String linkId) {
        this.linkId = linkId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getTaste() {
        return taste;
    }

    public void setTaste(String taste) {
        this.taste = taste;
    }

    public String getMakingWay() {
        return makingWay;
    }

    public void setMakingWay(String makingWay) {
        this.makingWay = makingWay;
    }

    public int getSuitableNum() {
        return suitableNum;
    }

    public void setSuitableNum(int suitableNum) {
        this.suitableNum = suitableNum;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getIsNew() {
        return isNew;
    }

    public void setIsNew(int isNew) {
        this.isNew = isNew;
    }

    public int getIsForcedRecommend() {
        return isForcedRecommend;
    }

    public void setIsForcedRecommend(int isForcedRecommend) {
        this.isForcedRecommend = isForcedRecommend;
    }

    public String getSubClass() {
        return subClass;
    }

    public void setSubClass(String subClass) {
        this.subClass = subClass;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getClazz() {
        return clazz;
    }

    public void setClazz(String clazz) {
        this.clazz = clazz;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }
}
