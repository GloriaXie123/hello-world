package com.yumchina.ai.recommendation.domain;

import com.yumchina.ai.recommendation.environment.GlobalConfig;

import java.util.ArrayList;
import java.util.List;

public class StoreProduct {

    private String channel;
    private String date;
    private String storeCode;
    private List<StoreProductItem> items;

    @Override
    public String toString() {
        String splitter = GlobalConfig.getSplitter();
        return channel + splitter
                + date + splitter
                + storeCode;
    }

    public List<String> toItemString(){
        String splitter = GlobalConfig.getSplitter();

        List<String> results = new ArrayList<>();
        for (StoreProductItem item : items) {
            String str = getStoreCode() + splitter
                    + item.toString();
            results.add(str);
        }
        return results;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStoreCode() {
        return storeCode;
    }

    public void setStoreCode(String storeCode) {
        this.storeCode = storeCode;
    }

}
