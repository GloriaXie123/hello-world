package com.yumchina.ai.recommendation.handler;

import com.yumchina.ai.recommendation.enums.TopicType;
import com.yumchina.ai.recommendation.handler.impl.*;
import org.apache.commons.collections.map.HashedMap;

import java.util.Map;

public class HandlerFactory {
    private static final Handler actionHandler = new ActionHandler();
    private static final Handler cityHandler = new CityHandler();
    private static final Handler orderHandler = new OrderHandler();
    private static final Handler storeHandler = new StoreHandler();
    private static final Handler tradeUpProductHandler = new TradeupProductHandler();
    private static final Handler cityLevelHandler = new CityLevelHandler();
    private static final Handler supplyHandler = new SupplyProductHandler();
    private static final Handler storeProductHandler = new StoreProductHandler();
    private static final Handler recommendFilterHandler = new RecommendFilterHandler();

    private static Map<String, Handler> handlerMap = null;

    static {
        handlerMap = new HashedMap();
        handlerMap.put(TopicType.TOPIC_ACTION.getName(), actionHandler);
        handlerMap.put(TopicType.TOPIC_CITY.getName(), cityHandler);
        handlerMap.put(TopicType.TOPIC_ORDER.getName(), orderHandler);
        handlerMap.put(TopicType.TOPIC_STORE.getName(), storeHandler);
        handlerMap.put(TopicType.TOPIC_TRADEUP_PRODUCT.getName(), tradeUpProductHandler);
        handlerMap.put(TopicType.TOPIC_CITY_LEVEL.getName(),cityLevelHandler);
        handlerMap.put(TopicType.TOPIC_SUPPLY_PRODUCT.getName(),supplyHandler);
        handlerMap.put(TopicType.TOPIC_STORE_PRODUCT.getName(),storeProductHandler);
        handlerMap.put(TopicType.TOPIC_RECOMMEND_FILTER.getName(),recommendFilterHandler);

    }

    private HandlerFactory() {

    }

    public static Handler getHandler(String topic) {
        return handlerMap.get(topic);
    }
}
