package com.yumchina.ai.recommendation.handler;

import com.yumchina.ai.recommendation.environment.GlobalConfig;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.connectors.fs.bucketing.BucketingSink;
import org.apache.flink.streaming.connectors.fs.bucketing.DateTimeBucketer;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

public abstract class Handler {
    protected static final Logger LOG = LoggerFactory.getLogger("");

    public abstract void transform(DataStream<String> stream);

    public static class ItemsFlatMap implements FlatMapFunction<List<String>, String> {
        @Override
        public void flatMap(List<String> items, Collector<String> out) throws Exception {
            for (String item : items) {
                out.collect(item);
            }
        }
    }

    public static class Tuple2Map1 implements MapFunction<Tuple2<String, List<String>>, String> {
        @Override
        public String map(Tuple2<String, List<String>> tuple) throws Exception {
            return tuple.f0;
        }
    }

    public static class Tuple2Map2 implements MapFunction<Tuple2<String, List<String>>, List<String>> {
        @Override
        public List<String> map(Tuple2<String, List<String>> tuple) throws Exception {
            return tuple.f1;
        }
    }


    public static class Tuple3Map1 implements MapFunction<Tuple3<String, List<String>, List<String>>, String> {
        @Override
        public String map(Tuple3<String, List<String>, List<String>> tuple) throws Exception {
            return tuple.f0;
        }
    }

    public static class Tuple3Map2 implements MapFunction<Tuple3<String, List<String>, List<String>>, List<String>> {
        @Override
        public List<String> map(Tuple3<String, List<String>, List<String>> tuple) throws Exception {
            return tuple.f1;
        }
    }

    public static class Tuple3Map3 implements MapFunction<Tuple3<String, List<String>, List<String>>, List<String>> {
        @Override
        public List<String> map(Tuple3<String, List<String>, List<String>> tuple) throws Exception {
            return tuple.f2;
        }
    }

    public void addHdfsSink(DataStream<String> stream, String topic) {
        String basePath = "/aie/recommendation/topic_bucket/"+topic;
        BucketingSink<String> sink = new BucketingSink<>(basePath);
        String bucketFormat = GlobalConfig.getBucketFormat();
        sink.setBucketer(new DateTimeBucketer<>(bucketFormat, ZoneId.of("Asia/Shanghai")));
        sink.setBatchSize(1024 * 1024 * 128); //128MB

        long interval = GlobalConfig.getRolloverInterval();
        sink.setBatchRolloverInterval(interval);

        SimpleDateFormat df = new SimpleDateFormat("-yyyy-MM-dd-HH-mm");//设置日期格式
        sink.setPartSuffix(df.format(new Date()));//设置后缀为系统时间
        sink.setUseTruncate(false);

//      messageStream.rebalance().writeAsText("D:/aie/kafkaHDFS/" + topic + ".txt", FileSystem.WriteMode.OVERWRITE).setParallelism(1);

        stream.addSink(sink).name(topic + " Sink to HDFS");
    }


	/*
	public void addHdfsParquetSink(DataStream<BaseDO> stream, String topic) {
		String hdfsPath = GlobalConfig.getHdfsPath();
		String basePath = hdfsPath + "/aie/recommendation/topic_bucket/"+topic;
		String bucketFormat = GlobalConfig.getBucketFormat();

		DateTimeBucketAssigner<?> bucketAssigner =
				new DateTimeBucketAssigner<>(bucketFormat, ZoneId.of("Asia/Shanghai"));
		StreamingFileSink<?> streamingFileSink = StreamingFileSink
				.forBulkFormat(new Path(basePath), ParquetAvroWriters.forReflectRecord(BaseDO.class))
				.withBucketAssigner(bucketAssigner)
				.build();

		stream.addSink(streamingFileSink).name(topic + " Sink to HDFS");
	}
	*/

}
