package com.yumchina.ai.recommendation.domain;

import com.yumchina.ai.recommendation.environment.GlobalConfig;

public class Action {
    private int action;
    private String brand;
    private String channel;
    private String linkids;//注意i是小写
    private int page;
    private String promotionCode;
    private String systemIds;
    private long systemTime;
    private String transactionId;
    private String userCode;


    @Override
    public String toString() {
        String splitter = GlobalConfig.getSplitter();
        return action + splitter
                + brand + splitter
                + channel + splitter
                + linkids + splitter +
                + page + splitter
                + promotionCode + splitter
                + systemIds + splitter
                + systemTime + splitter
                + transactionId + splitter
                + userCode + splitter;
    }

    public int getAction() {
        return action;
    }

    public void setAction(int action) {
        this.action = action;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getLinkids() {
        return linkids;
    }

    public void setLinkids(String linkids) {
        this.linkids = linkids;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public String getPromotionCode() {
        return promotionCode;
    }

    public void setPromotionCode(String promotionCode) {
        this.promotionCode = promotionCode;
    }

    public String getSystemIds() {
        return systemIds;
    }

    public void setSystemIds(String systemIds) {
        this.systemIds = systemIds;
    }

    public long getSystemTime() {
        return systemTime;
    }

    public void setSystemTime(long systemTime) {
        this.systemTime = systemTime;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }



}
