package com.yumchina.ai.recommendation;

import org.apache.flink.streaming.connectors.fs.Clock;
import org.apache.flink.streaming.connectors.fs.bucketing.Bucketer;
import org.apache.hadoop.fs.Path;



public class TopicBucketer<T> implements Bucketer<T> {

    private final String topic;

    public TopicBucketer(String topic){ this.topic = topic; }

    public Path getBucketPath(Clock clock, Path basePath, T element) { return new Path(basePath + "/" + topic); }

    public String toString() { return "TopicBucketer"+this.topic; }
}
