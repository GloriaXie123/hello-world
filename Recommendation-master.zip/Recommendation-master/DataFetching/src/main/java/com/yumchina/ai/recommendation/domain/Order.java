package com.yumchina.ai.recommendation.domain;

import com.yumchina.ai.recommendation.environment.GlobalConfig;

import java.util.ArrayList;
import java.util.List;

public class Order {

    private String transactionId;
    private String userCode;
    private long orderTime;
    private long promiseTime;
    private int orderAmount;
    private int realOrderAmount;
    private int orderingTime;
    private String storeCode;
    private String channel;
    private String marketCode;
    private String cityCode;
    private String cityName;
    private String brand;
    private List<OrderItem> orderItems;

    @Override
    public String toString() {
        String splitter = GlobalConfig.getSplitter();
        return getTransactionId() + splitter
                + getUserCode() + splitter
                + getOrderTime() + splitter
                + getPromiseTime() + splitter
                + getOrderAmount() + splitter
                + getStoreCode() + splitter
                + getMarketCode() + splitter
                + getCityName() + splitter
                + getBrand();
    }

    public String toOrderString() {
        String splitter = GlobalConfig.getSplitter();
        return getTransactionId() + splitter
                + getUserCode() + splitter
                + getOrderTime() + splitter
                + getPromiseTime() + splitter
                + getOrderAmount() + splitter
                + getStoreCode() + splitter
                + getMarketCode() + splitter
                + getCityName() + splitter
                + getBrand();
    }

    public List<String> toOrderItemString() {
        String splitter = GlobalConfig.getSplitter();
        List<String> results = new ArrayList<>();
        for (OrderItem item : orderItems) {
            String result = getTransactionId() + splitter
                    + item.toString();
            results.add(result);
        }
        return results;
    }

    public List<String> toItemLinkIdString() {
        String splitter = GlobalConfig.getSplitter();
        List<String> results = new ArrayList<>();
        for (OrderItem item : orderItems) {
            if (item == null || item.getItemLinkIds() == null) continue;

            for (OrderItemLinkId itemLinkId : item.getItemLinkIds()) {
                String result = getTransactionId() + splitter
                                + item.getOrderItemId() + splitter
                                + item.getLinkId() + splitter
                                + itemLinkId.toString();
                results.add(result);
            }
        }
        return results;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public long getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(long orderTime) {
        this.orderTime = orderTime;
    }

    public long getPromiseTime() {
        return promiseTime;
    }

    public void setPromiseTime(long promiseTime) {
        this.promiseTime = promiseTime;
    }

    public int getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(int orderAmount) {
        this.orderAmount = orderAmount;
    }

    public int getRealOrderAmount() {
        return realOrderAmount;
    }

    public void setRealOrderAmount(int realOrderAmount) {
        this.realOrderAmount = realOrderAmount;
    }

    public int getOrderingTime() {
        return orderingTime;
    }

    public void setOrderingTime(int orderingTime) {
        this.orderingTime = orderingTime;
    }

    public String getStoreCode() {
        return storeCode;
    }

    public void setStoreCode(String storeCode) {
        this.storeCode = storeCode;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getMarketCode() {
        return marketCode;
    }

    public void setMarketCode(String marketCode) {
        this.marketCode = marketCode;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public List<OrderItem> getOrderItems() {
        return this.orderItems;
    }

    public void setOrderItems(List<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }

}
