package com._4paradigm.bumblebee.runner.demon.parquet;

import org.apache.flink.core.fs.Path;
import org.apache.flink.formats.parquet.avro.ParquetAvroWriters;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.filesystem.StreamingFileSink;
import org.apache.flink.streaming.api.functions.sink.filesystem.bucketassigners.DateTimeBucketAssigner;
import org.junit.Test;

import java.io.File;

public class ParquetTest {
    //@Test
    public void testWriteParquetAvroSpecific() throws Exception {

        final File folder = new File("E:\\code\\ideaCode\\flinkDataStation\\target");//TEMPORARY_FOLDER.newFolder();

        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
        env.enableCheckpointing(60000);

        DataStream<Address> stream = env.addSource(
                new AdreeSource());

        StreamingFileSink<Address> parquetFileSink = StreamingFileSink
                .forBulkFormat(Path.fromLocalFile(folder), ParquetAvroWriters.forReflectRecord(Address.class))
                .withBucketAssigner(new DateTimeBucketAssigner<>("'date='yyyy-MM-dd'/hour='HH"))
                .build();

        stream.addSink(parquetFileSink);

        env.execute();

        //validateResults(folder, SpecificData.get(), data);
    }
}
