package com._4paradigm.bumblebee.runner.demon.kafka;

import org.apache.flink.table.functions.ScalarFunction;

import java.util.List;
import java.util.Map;

public class HashCode extends ScalarFunction {
    private int factor = 12;

    public HashCode(int factor) {
        this.factor = factor;
    }

    public Map<String,String> eval(List<Map<String,String>> value) {
        return value.get(0);
    }
}