package com._4paradigm.bumblebee.runner.demon.avro;

import org.apache.avro.Schema;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

public class AvroTest {
    public static void main(String[] args) {
        List<Schema.Field> fields = new ArrayList<Schema.Field>();
        fields.add(new Schema.Field("field_name1", Schema.create(Schema.Type.STRING), null, null));
        fields.add(new Schema.Field("field_name2", Schema.create(Schema.Type.INT), null, null));

// create RecordSchema
        Schema schema = Schema.createRecord("foobar", "just a test", "avro.test", false, fields);

        System.out.println(schema.getFields().get(0).toString());
// get full-name and doc
        System.out.println(schema.getFullName());
        System.out.println(schema.getDoc());

// get field
        System.out.println(schema.getField("field_name1").toString());
// field name
        System.out.println(schema.getField("field_name2").name());
// field position
        System.out.println(schema.getField("field_name2").pos());
// field schema
        System.out.println(schema.getField("field_name2").schema().toString());
// field order
        System.out.println(schema.getField("field_name2").order().toString());

        System.out.println(schema.toString());

//print the fields
        StringWriter writer = new StringWriter();
        //JsonGenerator gen = Schema.FACTORY.createJsonGenerator(writer);
        //schema.fieldsToJson(new Names(), gen);
      //  gen.flush();
        System.out.println(writer.toString());
   }
}
