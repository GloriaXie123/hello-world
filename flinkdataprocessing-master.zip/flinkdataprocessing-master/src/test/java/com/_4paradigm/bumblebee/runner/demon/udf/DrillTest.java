package com._4paradigm.bumblebee.runner.demon.udf;

import com._4paradigm.bumblebee.udf.Drill;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

public class DrillTest {
    //@Test
    public void test1(){
        Map<String,String> map ;
        String store_product_schema = "struct<storeCode:string,channel:string,date:string,linkIds:array<struct<linkId:string,systemId:string,price:string,itemcount:int,iMenuCn:string,iDescCn:string,iSalesFlag:string,validFrom:bigint,validTo:bigint,startTime:bigint,endTime:bigint,showNameCn:string,itemLinkids:array<struct<linkId:string,systemId:string,round:int,price:int,iMenuCn:string,iDescCn:string,iSalesFlag:string,validFrom:bigint,validTo:bigint,startTime:bigint,endTime:bigint,showNameCn:string,quantity:int,itemCount:string>>>>>";
        String order_schema = "struct<transactionId:string,userCode:string,orderTime:bigint,promiseTime:bigint,orderAmount:int,realOrderAmount:int,orderingTime:int,storeCode:string,channel:string,marketCode:string,cityCode:string,cityName:string,brand:string,address:string,addressType:string,coordinate_x:string,coordinate_y:string,userId:string,deliveryTimeOfMap:string,gender:string,iLinkMan:string,iRemark:string,needInvoice:string,invoiceTitle:string,payChannel:string,bookingType:boolean,openId:string,deviceId:string,orderItems:array<struct<orderItemId:string,linkId:string,sizeId:string,baseId:string,num:int,price:int,realPrice:int,type:int,couponCode:string,promotionCode:string,itemLinkIds:array<struct<linkId:string,sizeId:string,baseId:string,num:int,price:int,round:int>>>>>";
        String action_schema = "struct<transactionId:string,userCode:string,systemTime:bigint,brand:string,channel:string,page:int,action:int,items:array<struct<linkIds:string,systemIds:string,type:int>>,promotionCode:string>";
        String menu_force_schema = "struct<date:string,brand:string,storeCode:string,linkId:string,sizeId:string,baseId:string,type:int,couponCode:string,promotionCode:string,validFrom:string,validTo:string,startTime:string,endTime:string,itemLinkIds:array<struct<linkId:string,sizeId:string,baseId:string,type:int,round:int>>>";
        map = new HashMap();
        map.put("kafka_store_product",store_product_schema);
        map.put("kafka_order",order_schema);
        map.put("kafka_action",action_schema);
        map.put("kafka_menu_force",menu_force_schema);

        Drill drill = new Drill(map,"order#orderItems#orderItemId*linkId*itemLinkIds");
        System.out.println( drill.getTypeRow2("order#orderItems#orderItemId*linkId*itemLinkIds"));
       ;
    }
}
