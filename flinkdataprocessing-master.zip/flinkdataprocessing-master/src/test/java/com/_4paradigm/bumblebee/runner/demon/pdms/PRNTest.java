package com._4paradigm.bumblebee.runner.demon.pdms;

/*
import com._4paradigm.pdms.telamon.client.TelamonClient;
import com._4paradigm.pdms.telamon.enumeration.ResourceStatus;
import com._4paradigm.pdms.telamon.enumeration.StorageFormat;
import com._4paradigm.pdms.telamon.model.CommonSchemaTerm;
import com._4paradigm.pdms.telamon.model.Table;
import com._4paradigm.pdms.telamon.model.TableGroup;
import com._4paradigm.pdms.telamon.v1.enumeration.PRNType;
import com._4paradigm.pdms.telamon.v1.util.PRN;
 */
import org.apache.commons.compress.utils.Lists;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public class PRNTest {
    public static void main(String[] args) throws Exception {

        String serverUrl = "http://gateway.360cdh.autoui.4pd.io";
        String accessKey = "e5f1fc70-7d1d-4f60-9bd6-fd949078adad";
        int workspaceId = 1;

        /*
        //TelamonClient client = new TelamonClient(serverUrl);
        TelamonClient client = new TelamonClient(serverUrl, accessKey, workspaceId);

        //Table Group
        TableGroup group = new TableGroup();
        PRN gPrn = PRN.builder().namespace("4paradigm_test")
                .name("shangyueTest")
                .type(PRNType.TableGroup)
                .buildSimplePRN();
        group.setPrn(gPrn.toString());
        //client.createTableGroup(group);


        //String groupPrn =group.getPrn();
        String hdfsPrefix = "hdfs://172.27.133.18:8020/tmp/sy/"; //头部基础地址
        String groupPrn = "4paradigm_test/shangyueTest.table-group";
        String tableName = "topic_20190722191247_20190722191747";
        //String url = hdfsPrefix + groupPrn + tableName;
        //hdfs://172.27.133.18:8020/tmp/sy/4paradigm_test/shangyueTest.table-group/topic_20190722181612_20190722182112.table/
        Table table = new Table();
        PRN prn = PRN.builder().namespace(PRN.getNamespace(groupPrn))
                .groupName(PRN.getName(groupPrn))
                .groupType(PRN.getType(groupPrn))
                .name(tableName)
                .type(PRNType.Table)
                .buildDepGroupPRN();
        table.setPrn(prn.toString());
        table.setUrl(hdfsPrefix + PRN.toPath(prn.toString()));

        List<CommonSchemaTerm> lists =  Lists.newArrayList();
        lists.add(new CommonSchemaTerm("local_day_string","String"));
        lists.add(new CommonSchemaTerm("local_time_string","String"));
        lists.add(new CommonSchemaTerm("foo","String"));
        lists.add(new CommonSchemaTerm("bar","String"));
        lists.add(new CommonSchemaTerm("ts","String"));

        table.setSchema(lists); // 真正的 schema
        table.setStorageFormat(StorageFormat.parquet);
        table.setResourceStatus(ResourceStatus.SUCCESS);
        table.setSize(500L); // TODO 需要计算
        table.setLineNum(500L); // TODO 需要计算

        client.createTable(table);

         */
    }

}
