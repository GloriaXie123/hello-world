package com._4paradigm.bumblebee.runner.demon.zzpp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class zzTest {
    public static void main(String[] args) {
        String parem = "aabb[{}]";
        String pattern = "aabb\\[.*\\]";
        Pattern mPAvatar = Pattern.compile(pattern);
        System.out.println(Pattern.matches(pattern,parem));
        Matcher mMAvatar = mPAvatar.matcher(parem);
        while (mMAvatar.find()) {
            System.out.println(mMAvatar.group());
    }

    }
}
