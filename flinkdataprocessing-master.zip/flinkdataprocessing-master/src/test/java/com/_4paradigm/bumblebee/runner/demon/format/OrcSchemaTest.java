package com._4paradigm.bumblebee.runner.demon.format;

import com._4paradigm.bumblebee.connector.format.OrcSchemaAnalysis;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.orc.TypeDescription;
import org.junit.Test;

public class OrcSchemaTest {

    @Test
    public void test(){
        String orcSchemaStr = "struct<transactionId:string,userCode:string,systemTime:bigint,brand:string,channel:string,page:int,action:int,items:array<struct<linkids:string,systemIds:string,type:int>>,promotionCode:string>";
        TypeDescription typeDescription = TypeDescription.fromString(orcSchemaStr);

        TypeInformation type = new OrcSchemaAnalysis().getFlinkSchema (typeDescription);
        System.out.println(type);
        System.out.println(new OrcSchemaAnalysis().getAvroSchema("struct<transactionId:string,userCode:string,systemTime:bigint,brand:string,channel:string,page:int,action:int,promotionCode:string>").toString());
        TypeInformation type2 = Types.ROW_NAMED(
                new String[] { "transactionId", "userCode", "systemTime", "brand", "channel", "page", "action","items","promotionCode" },
                new TypeInformation[]{ Types.STRING, Types.STRING, Types.LONG, Types.STRING,Types.STRING,Types.INT,Types.INT,Types.LIST(Types.ROW_NAMED(
                        new String[] { "linkids", "systemIds", "type" },
                        new TypeInformation[]{ Types.STRING, Types.STRING,Types.INT}
                )), Types.STRING});
        System.out.println(type2);

        TypeInformation type3 =Types.ROW_NAMED(
                new String[] { "transactionId", "userCode", "items" },//Types.POJO(ActionItem.class)
                new TypeInformation[]{ Types.STRING, Types.STRING,Types.OBJECT_ARRAY(Types.ROW_NAMED(
                        new String[] { "linkids", "systemIds", "type" },
                        new TypeInformation[]{ Types.STRING, Types.STRING,Types.INT}
                ))});
        System.out.println(type3);
    }

}
