package com._4paradigm.bumblebee.runner.demon.rtidb;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * 直接读取rtidb的建表文件，获得orc标准schema行
 */
public class SchemaTransformRead {
    public static void main(String[] args) throws IOException {
        if(args.length!=1){
            throw new RuntimeException("请输入rtidb的标准建表文件路径，处理得到ORC schema");
        }
        BufferedReader br = new BufferedReader(new FileReader(args[0]));
        String sb1 = null;
        int i = 1;
        Map<String,String> map = new HashMap();

        while (br.ready()) {
            String str = br.readLine();
            if(i%5 == 0){
                sb1=str.split("\"")[1];
                System.out.println(i+"     "+str.split("\"")[1]);
            }
            if((i-1)%5 == 0 && i!=1){
                map.put(sb1,getType(str.split("\"")[1]));
                System.out.println(i+"     "+getType(str.split("\"")[1]));
            }

            i++;
        }
        System.out.println("Rtidb建表文件转成的hashmap：");
        System.out.println(map);
        String struct = map.toString().replace("{","struct<").replace('}','>').replace(" ","").replace("=",":");
        System.out.println("hashmap转成的ORC schema：");
        System.out.println(struct);
        System.out.println(URLEncoder.encode(struct,"UTF-8"));
    }
    public static String getType(String str){
        String value = null;
        switch (str){
            case "int16" :
                value = "smallint";
                break;
            case "uint16" :
                value = "smallint";
                throw new RuntimeException("不支持无符号的的rtidb数据类型：{}"+str);
            case "int32" :
                value = "int";
                break;
            case "uint32" :
                value = "int";
                throw new RuntimeException("不支持无符号的的rtidb数据类型：{}"+str);
            case "int64" :
                value = "bigint";
                break;
            case "uint64" :
                value = "bigint";
                throw new RuntimeException("不支持无符号的的rtidb数据类型：{}"+str);
            case "float" :
                value = "float";
                break;
            case "double" :
                value = "double";
                break;
            case "string" :
                value = "string";
                break;
            default :
                throw new RuntimeException("不支持无符号的的rtidb数据类型：{}"+str);
        }
       return  value;
    }
    //int16，uint16，int32，uint32，int64，uint64，float，double，string
}
