package com._4paradigm.bumblebee.runner.demon.URL;

import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.JsonNode;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.node.ArrayNode;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Watch {
    public static String sendGet(String url) {
        String result = "";
        BufferedReader in = null;
        try {
            String urlNameString = url;
            URL realUrl = new URL(urlNameString);
            // 打开和URL之间的连接
            URLConnection connection = realUrl.openConnection();
            // 设置通用的请求属性
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent",
                    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            // 建立实际的连接
            connection.connect();
            in = new BufferedReader(new InputStreamReader(
                    connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            System.out.println("发送GET请求出现异常！" + e);
            e.printStackTrace();
        }
        // 使用finally块来关闭输入流
        finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        return result;
    }

    public static void ifHaveNotSucces(String getStr) {
        ObjectMapper objectMapperK = new ObjectMapper();
        JsonNode root = null;
        try {
            root = objectMapperK.readTree(getStr.getBytes());
            JsonNode jnode = root.get("jobs");
            ArrayNode arrayNode = (ArrayNode) jnode;
            for (int i = 0; i < arrayNode.size(); i++) {
                JsonNode jnode2 = arrayNode.get(i);
                if (!jnode2.get("state").asText().equals("RUNNING")) {
                    System.out.println(-1);
                }
            }
        } catch (IOException e) {
            System.out.println(-1);
            e.printStackTrace();
        }
    }

    public static void ifEveryOneSucces(String getStr,String jobListStr) {
        ObjectMapper objectMapperK = new ObjectMapper();
        JsonNode root = null;
        try {
            root = objectMapperK.readTree(getStr.getBytes());
            JsonNode jnode = root.get("jobs");
            ArrayNode arrayNode = (ArrayNode) jnode;
            Map<String,String> map = new HashMap();
            for (int i = 0; i < arrayNode.size(); i++) {
                JsonNode jnode2 = arrayNode.get(i);
                String key = jnode2.get("name").asText().replace("Flink_Job_","");
                if(map.get(key)!=null&&map.get(key).equals("RUNNING")){
                    break;
                }
                map.put(key,jnode2.get("state").asText());
            }
            String[] strs = jobListStr.split(",");
            for (String str:strs) {
                String value = str.trim();
                if(value!=null||!value.equals("")){
                    if(map.get(value)==null){
                        System.out.println(value +": "+"任务没有启动");
                    }else {
                        //System.out.println(value +": "+map.get(value));
                        if(!map.get(value).equals("RUNNING")){
                            System.out.println(value +": "+map.get(value));
                        }
                    }
                }
            }
            /*
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(jobListPath)));
            while (br.ready()){
                String value = br.readLine().trim();

                if(value!=null||!value.equals("")){
                    if(map.get(value)==null){
                        System.out.println(value +": "+"任务没有启动");
                    }else {
                        //System.out.println(value +": "+map.get(value));
                        if(!map.get(value).equals("RUNNING")){
                            System.out.println(value +": "+map.get(value));
                        }
                    }
                }
            }*/

        } catch (IOException e) {
            System.out.println(-1);
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        if(args.length<2){
            //throw new RuntimeException("参数不正确，参数:url [jobListPath]");
        }
        //String jobListPath = "E:\\code\\ideaCode\\flinkDataStation\\src\\main\\resources\\hadoop_conf\\jobName.txt";
        String getStr = sendGet(args[0]+"/jobs/overview");

        //ifHaveNotSucces(getStr);
        ifEveryOneSucces(getStr,args[1]);

    }

}
