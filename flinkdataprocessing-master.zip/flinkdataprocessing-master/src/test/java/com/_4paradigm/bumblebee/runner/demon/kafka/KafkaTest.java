package com._4paradigm.bumblebee.runner.demon.kafka;

import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.java.StreamTableEnvironment;
import org.apache.flink.table.descriptors.Json;
import org.apache.flink.table.descriptors.Kafka;
import org.apache.flink.table.descriptors.Rowtime;
import org.apache.flink.table.descriptors.Schema;
import org.apache.flink.table.functions.ScalarFunction;
import org.apache.flink.types.Row;
import org.junit.Test;

public class KafkaTest {

    //@Test
    public void Tets0() {
        System.out.println(
                "{" +
                        "  type: 'object'," +
                        "  properties: {" +
                        "    lon: {" +
                        "      type: 'number'" +
                        "    }," +
                        "    rideTime: {" +
                        "      type: 'string'," +
                        "      format: 'date-time'" +
                        "    }" +
                        "  }" +
                        "}"
                //{  type: 'object',  properties: {    lon: {      type: 'number'    },    rideTime: {      type: 'string',      format: 'date-time'    }  }}
        );
    }
    //@Test
    public void Tets() {
        // for batch programs use ExecutionEnvironment instead of StreamExecutionEnvironment
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        EnvironmentSettings fsSettings = EnvironmentSettings.newInstance().useOldPlanner().inStreamingMode().build();
        StreamTableEnvironment tableEnv = StreamTableEnvironment.create(env, fsSettings);
        // create a TableEnvironment
        // for batch programs use BatchTableEnvironment instead of StreamTableEnvironment


        tableEnv
                // declare the external system to connect to
                .connect(
                        new Kafka()
                                .version("0.10")
                                .topic("test")
                                .startFromLatest()
                                //.property("zookeeper.connect", "localhost:2181")
                                .property("bootstrap.servers", "172.27.133.19:9092")
                )

                // declare a format for this system
                .withFormat(
                       new Json().deriveSchema()/*
                       .jsonSchema(
                               "{\"type\":\"object\",\"properties\":{\"transactionId\":{\"type\":\"string\"},\"userCode\":{\"type\":\"string\"},\"brand\":{\"type\":\"string\"},\"items\":{\"type\":\"array\",\"items\":{\"type\":\"object\",\"properties\":{\"linkids\":{\"type\":\"string\"},\"systemIds\":{\"type\":\"string\"},\"type\":{\"type\":\"integer\"}}}}}}"
                               // "{  type: 'object',  properties: {    transactionId: {      type: 'string'    },    userCode: {      type: 'string'    }  }}"
                       )*/

                )

                // declare the schema of the table
                .withSchema(
                        //struct<transactionId:string,userCode:string,systemTime:bigint,brand:string,channel:string,page:int,action:int,items:array<struct<linkids:string,systemIds:string,type:int>>,promotionCode:string>

                        new Schema()
                                .field("transactionId", Types.STRING)
                                .field("userCode", Types.STRING)
                                .field("brand", Types.STRING)
                                .field("orderItems",Types.OBJECT_ARRAY(Types.ROW_NAMED(
                                        new String[] { "orderItemId", "linkId", "itemLinkIds" },
                                        new TypeInformation[]{ Types.STRING, Types.STRING,Types.OBJECT_ARRAY(Types.ROW_NAMED(
                                                new String[] { "linkId", "sizeId", "round" },
                                                new TypeInformation[]{ Types.STRING, Types.STRING,Types.BIG_DEC}))})))
                        //
                        //Types.ROW()
                        //Types.LIST(Types.POJO(ActionItem.class))
                        /*
                        Types.ROW_NAMED(
                                        new String[] { "linkids", "systemIds", "type" },
                                        new TypeInformation[]{ Types.STRING, Types.STRING,Types.INT})
                         */
                        /*new Schema()
                                .field("transactionId", "STRING")

                                .field("userCode", "STRING")
                                .field("brand", "STRING")
                                .field("items",Types.LIST(Types.MAP(Types.STRING,Types.STRING)))*/
                )

                // specify the update-mode for streaming tables
                .inAppendMode()

                // register as source, sink, or both and under a name
                .registerTableSource("KafkaTable");

        // create a Table from a SQL query
        //SELECT a, word, length FROM MyTable, LATERAL TABLE(split(a)) as T(word, length)
        //SELECT a, word, length FROM KafkaTable, LATERAL TABLE(split(itemList)) as T(word, length)

        //Table sqlResult  = tableEnv.sqlQuery("SELECT itemList_itmeId,itemList_itemRank FROM KafkaTable, LATERAL TABLE(split(itemList)) as T(itemList_itmeId, itemList_itemRank)");

        tableEnv.registerFunction("hashCode", new HashCode(10));
        // Register the function.
        tableEnv.registerFunction("split", new Split("#"));
        tableEnv.registerFunction("reture", new Retrue());

        Table sqlResult2  = tableEnv.sqlQuery("SELECT *,word FROM KafkaTable, LATERAL TABLE(reture(userCode)) as T(word)");


        // emit a Table API result Table to a TableSink, same for SQL result
        //tapiResult.insertInto("outputTable");
        sqlResult2.printSchema();

        DataStream stream = tableEnv.toAppendStream(sqlResult2, Row.class);
        //stream.print();

        try {
            // execute
            env.execute();
        } catch (Exception e) {
            System.out.println("程序执行错误不应该导致集群挂掉");
            e.printStackTrace();
        }
    }
}
