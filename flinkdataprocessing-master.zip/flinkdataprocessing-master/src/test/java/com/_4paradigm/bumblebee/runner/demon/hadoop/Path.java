package com._4paradigm.bumblebee.runner.demon.hadoop;


import org.apache.flink.core.fs.FileSystem;
import org.apache.flink.core.fs.SafetyNetWrapperFileSystem;
import org.apache.flink.core.fs.local.LocalFileSystem;
import org.apache.flink.runtime.fs.hdfs.HadoopFileSystem;
import org.apache.hadoop.fs.permission.FsAction;
import org.apache.hadoop.fs.permission.FsPermission;
import org.apache.hadoop.mapred.JobConf;

import javax.security.auth.login.Configuration;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class Path {
    public static void main(String[] args) throws Exception {
        new Path().pathTest();
    }

    public void pathTest() throws Exception{
        JobConf jobConf = new JobConf();
        // init and register file system
        String dir = "hdfs://172.27.133.18:8020/tmp/sy/aie";

        org.apache.flink.core.fs.Path path = new org.apache.flink.core.fs.Path(dir);
        FileSystem fs = path.getFileSystem();
        if (fs instanceof SafetyNetWrapperFileSystem) {
            fs = ((SafetyNetWrapperFileSystem) fs).getWrappedDelegate();
        }
        if (fs instanceof HadoopFileSystem) {
            //jobConf.addResource(((HadoopFileSystem) fs).getConfig()); TODO
            jobConf.addResource(((HadoopFileSystem) fs).getHadoopFileSystem().getConf());
        }
        if (!(fs instanceof LocalFileSystem || fs instanceof HadoopFileSystem)) {
            throw new RuntimeException("FileSystem: " + fs.getClass().getCanonicalName() + " is not supported.");
        }
        if(fs.exists(path)){
            // clean up output file in case of failover.
            fs.delete(path, true);
            System.out.println("删除："+path);
        }
        //fs.delete(new Path(dir),true);
    }

    public void testHdfsqx() throws URISyntaxException, IOException {
        JobConf jobConf = new JobConf();
        String dir = "hdfs://172.27.133.18:8020/tmp/sy/aie";
        org.apache.flink.core.fs.Path path = new org.apache.flink.core.fs.Path(dir);
        FsPermission fsp = new FsPermission(FsAction.ALL,FsAction.ALL,FsAction.ALL);
        FileSystem fs = FileSystem.get(new URI(dir));

    }
}
