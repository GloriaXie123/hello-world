package com._4paradigm.bumblebee.runner.demon.orc;

import org.apache.flink.table.api.Types;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hive.ql.exec.vector.LongColumnVector;
import org.apache.hadoop.hive.ql.exec.vector.MapColumnVector;
import org.apache.hadoop.hive.ql.exec.vector.VectorizedRowBatch;
import org.apache.orc.OrcFile;
import org.apache.orc.Reader;
import org.apache.hadoop.fs.Path;
import org.apache.orc.TypeDescription;
import org.apache.orc.Writer;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class OrcTest {
    //@Test
    public void wirteOrc() throws IOException {
        System.setProperty("HADOOP_HOME", "E:\\hadoop-2.7.7");

        String hdfsPathValue = "E:\\code\\ideaCode\\flink-jobrunner\\src\\test\\resources\\data\\write.orc";
        String schemaValue= "struct<x:int,y:int>";
        Configuration conf = new Configuration();
        TypeDescription schema = TypeDescription.fromString(schemaValue);
        Writer writer = OrcFile.createWriter(new Path(hdfsPathValue),
                OrcFile.writerOptions(conf)
                        .setSchema(schema));

        VectorizedRowBatch batch = schema.createRowBatch();
        LongColumnVector x = (LongColumnVector) batch.cols[0];
        LongColumnVector y = (LongColumnVector) batch.cols[1];
        MapColumnVector z = (MapColumnVector) batch.cols[2];
        for(int r=0; r < 10000; ++r) {
            int row = batch.size++;
            x.vector[row] = r;
            y.vector[row] = r * 3;
            // If the batch is full, write it out and start over.
            if (batch.size == batch.getMaxSize()) {
                writer.addRowBatch(batch);
                batch.reset();
            }
        }
        if (batch.size != 0) {
            writer.addRowBatch(batch);
            batch.reset();
        }
        writer.close();
    }

    //@Test
    public void readOrc() throws IOException {
        String hdfsPathValue = "E:\\code\\ideaCode\\flink-jobrunner\\src\\test\\resources\\data\\write.orc";
        String schemaValue= null;
        Configuration conf = new Configuration();
        Reader reader = OrcFile.createReader(new Path(hdfsPathValue),OrcFile.readerOptions(conf));
        schemaValue = reader.getSchema().toString();
        System.out.println(schemaValue);
        System.out.println(reader.getSchema().getFieldNames());
    }


    //@Test
    public void readSchema() throws IOException {
        String schemaValue =  "struct<transactionId:string,userCode:string,systemTime:bigint,brand:string,channel:string,page:int,action:int,items:array<struct<linkids:string,systemIds:string,type:int>>,promotionCode:string>";
        Configuration conf = new Configuration();
        TypeDescription schema = TypeDescription.fromString(schemaValue);
        System.out.println(schema);
        System.out.println(schema.getChildren());
        for (TypeDescription type:schema.getChildren()) {
            System.out.println(type);
        }

    }
    //@Test
    public void readSchema2() throws IOException {
        String schema = "struct<transactionId:string,userCode:string,orderTime:bigint,promiseTime:bigint,orderAmount:int,realOrderAmount:int,orderingTime:int,storeCode:string,channel:string,marketCode:string,cityCode:string,cityName:string,brand:string,address:string,addressType:string,coordinate_x:string,coordinate_y:string,userId:string,deliveryTimeOfMap:string,gender:string,iLinkMan:string,iRemark:string,needInvoice:string,invoiceTitle:string,payChannel:string,bookingType:boolean,openId:string,deviceId:string,orderItems:array<struct<orderItemId:string,linkId:string,sizeId:string,baseId:string,num:int,price:int,realPrice:int,type:int,couponCode:string,promotionCode:string,itemLinkIds:array<struct<linkId:string,sizeId:string,baseId:string,num:int,price:int,round:int>>>>>";
        TypeDescription typeDescription = TypeDescription.fromString(schema);
        System.out.println(typeDescription);
        System.out.println(typeDescription.getChildren());
        List<TypeDescription> typeList= typeDescription.getChildren();
        typeList = new ArrayList(typeList);
        TypeDescription t= typeList.remove(typeList.size()-1);
        System.out.println(typeList);
        System.out.println(t);
        //new OrcSchemaAnalysis().getFlinkSchema(getTypeRow(typeDescription,colum));
    }

    //@Test
    public void readSchema2HiveCreate() {
        String schema = "struct<_apiServer_debug_sample_:string,brand:string,experimentId:string,transactionId:string,userCode:string,uniqueId:string,sell_code:string,predictScore:double,systemTime:bigint,transaction_guid:string,store_code:string,biz_date:string,p_biz_date:int,yumid:string,daypart_name:string,work_day_name:string,cart_kidstoyflag:bigint,cart_side_sold:bigint,cart_coffee_sold:bigint,cart_conge_sold:bigint,cart_nutrition_sold:bigint,cart_panini_sold:bigint,cart_riceroll_sold:bigint,cart_dabing_sold:bigint,cart_burger_sold:bigint,cart_chickensnack_sold:bigint,cart_cob_sold:bigint,cart_csd_sold:bigint,cart_eggtart_sold:bigint,cart_icecream_sold:bigint,cart_sidefrenchfries_sold:bigint,cart_sideothers_sold:bigint,cart_tea_sold:bigint,cart_twister_sold:bigint,cart_wing_sold:bigint,cart_waffle_sold:bigint,cart_croissant_sold:bigint,cart_nonfood_sold:bigint,cart_pie_sold:bigint,cart_juice_sold:bigint,cart_rice_sold:bigint,cart_lto_sold:bigint,cart_combo_unit_sold:bigint,cart_single_unit_sold:bigint,cart_combo_sell_price:double,cart_single_sell_price:double,cart_total_unit_sold:bigint,preorder_channel_name:string,cart_ta:double,tradeup_sell_code:string,sell_code_recall:string,city_val:double,city_rank:int,val:bigint,rank:int,label:int,u_tc:bigint,u_ta:double,u_breakfast_tc:bigint,u_nonbreakfast_tc:bigint,u_morning_tc:bigint,u_lunch_tc:bigint,u_afternoon_tc:bigint,u_dinner_tc:bigint,u_latenight_tc:bigint,u_mon_tc:bigint,u_tue_tc:bigint,u_wen_tc:bigint,u_thu_tc:bigint,u_fri_tc:bigint,u_sat_tc:bigint,u_sun_tc:bigint,u_tier1_tc:bigint,u_tier2_tc:bigint,u_tier3_tc:bigint,u_tier4_tc:bigint,u_tier5_tc:bigint,u_tier6_tc:bigint,u_breakfast_maxta:double,u_nonbreakfast_maxta:double,u_morning_maxta:double,u_lunch_maxta:double,u_afternoon_maxta:double,u_dinner_maxta:double,u_latenight_maxta:double,u_mon_maxta:double,u_tue_maxta:double,u_wen_maxta:double,u_thu_maxta:double,u_fri_maxta:double,u_sat_maxta:double,u_sun_maxta:double,u_breakfast_minta:double,u_nonbreakfast_minta:double,u_morning_minta:double,u_lunch_minta:double,u_afternoon_minta:double,u_dinner_minta:double,u_latenight_minta:double,u_mon_minta:double,u_tue_minta:double,u_wen_minta:double,u_thu_minta:double,u_fri_minta:double,u_sat_minta:double,u_sun_minta:double,u_breakfast_avgta:double,u_nonbreakfast_avgta:double,u_morning_avgta:double,u_lunch_avgta:double,u_afternoon_avgta:double,u_dinner_avgta:double,u_latenight_avgta:double,u_mon_avgta:double,u_tue_avgta:double,u_wen_avgta:double,u_thu_avgta:double,u_fri_avgta:double,u_sat_avgta:double,u_sun_avgta:double,u_breakfast_sumta:double,u_nonbreakfast_sumta:double,u_morning_sumta:double,u_lunch_sumta:double,u_afternoon_sumta:double,u_dinner_sumta:double,u_latenight_sumta:double,u_mon_sumta:double,u_tue_sumta:double,u_wen_sumta:double,u_thu_sumta:double,u_fri_sumta:double,u_sat_sumta:double,u_sun_sumta:double,u_breakfast_std_ta:double,u_nonbreakfast_std_ta:double,u_morning_std_ta:double,u_lunch_std_ta:double,u_afternoon_std_ta:double,u_dinner_std_ta:double,u_latenight_std_ta:double,u_mon_std_ta:double,u_tue_std_ta:double,u_wen_std_ta:double,u_thu_std_ta:double,u_fri_std_ta:double,u_sat_std_ta:double,u_sun_std_ta:double,u_avg_discount:double,u_max_discount:double,u_min_discount:double,u_sum_discount:double,u_std_discount:double,u_avg_ta_by_ps:double,u_std_ta_by_ps:double,u_avg_city_tier:double,u_max_city_tier:int,u_min_city_tier:int,u_std_city_tier:double,u_avg_party_size:double,u_max_party_size:int,u_min_party_size:int,u_std_party_size:double,u_cor_ta_da:double,u_distinct_daypart:bigint,u_distinct_city:bigint,u_distinct_work_day:bigint,u_distinct_store:bigint,u_delivery_tc:bigint,u_delivery_ta:double,u_avg_delivery_party_size:double,u_max_delivery_party_size:int,u_min_delivery_party_size:int,u_std_delivery_party_size:double,u_preorder_tc:bigint,u_preorder_ta:double,u_avg_preorder_party_size:double,u_max_preorder_party_size:int,u_min_preorder_party_size:int,u_std_preorder_party_size:double,u_side_sold:bigint,u_coffee_sold:bigint,u_congee_sold:bigint,u_nutrition_sold:bigint,u_panini_sold:bigint,u_riceroll_sold:bigint,u_dabing_sold:bigint,u_burger_sold:bigint,u_chickensnack_sold:bigint,u_cob_sold:bigint,u_csd_sold:bigint,u_eggtart_sold:bigint,u_icecream_sold:bigint,u_sidefrenchfries_sold:bigint,u_sideothers_sold:bigint,u_tea_sold:bigint,u_twister_sold:bigint,u_wing_sold:bigint,u_waffle_sold:bigint,u_croissant_sold:bigint,u_nonfood_sold:bigint,u_pie_sold:bigint,u_juice_sold:bigint,u_rice_sold:bigint,u_lto_sold:bigint,u_side_sell_price:double,u_coffee_sell_price:double,u_congee_sell_price:double,u_nutrition_sell_price:double,u_panini_sell_price:double,u_riceroll_sell_price:double,u_dabing_sell_price:double,u_burger_sell_price:double,u_chickensnack_sell_price:double,u_cob_sell_price:double,u_csd_sell_price:double,u_eggtart_sell_price:double,u_icecream_sell_price:double,u_sidefrenchfries_sell_price:double,u_sideothers_sell_price:double,u_tea_sell_price:double,u_twister_sell_price:double,u_wing_sell_price:double,u_waffle_sell_price:double,u_croissant_sell_price:double,u_nonfood_sell_price:double,u_pie_sell_price:double,u_juice_sell_price:double,u_rice_sell_price:double,u_lto_sell_price:double,u_single_product_number:double,u_combo_product_number:double,u_kids_meal_toy_num:bigint,u_trade_up_num:int,u_chicken_burger_soldratio_orlean:double,u_chicken_burger_soldratio_spicy:double,u_chicken_burger_soldratio_crusty:double,u_lasttrans_nb_date:string,u_lasttrans_nb_store_code:string,u_lasttrans_nb_city:string,u_lasttrans_nb_city_tier:int,u_lasttrans_nb_ta:double,u_lasttrans_nb_daypart:string,u_lasttrans_nb_sell_code:string,u_lasttrans_b_date:string,u_lasttrans_b_store_code:string,u_lasttrans_b_city:string,u_lasttrans_b_city_tier:int,u_lasttrans_b_ta:double,u_lasttrans_b_daypart:string,u_lasttrans_b_sell_code:string,u_breakfastcard_flag:int,u_coffeecard_flag:int,u_deliverycard_flag:int,u_dashencard_flag:int,s_sumtc:bigint,s_sumta:double,s_avg_ta:double,s_breakfast_tc_ratio:double,s_morning_tc_ratio:double,s_lunch_tc_ratio:double,s_afternoon_tc_ratio:double,s_dinner_tc_ratio:double,s_latenight_tc_ratio:double,s_breakfast_avgta:double,s_morning_avgta:double,s_lunch_avgta:double,s_afternoon_avgta:double,s_dinner_avgta:double,s_latenight_avgta:double,s_city_tier:int,s_side_sold_ratio:double,s_coffee_sold_ratio:double,s_congee_sold_ratio:double,s_nutrition_sold_ratio:double,s_panini_sold_ratio:double,s_riceroll_sold_ratio:double,s_dabing_sold_ratio:double,s_burger_sold_ratio:double,s_chickensnack_sold_ratio:double,s_cob_sold_ratio:double,s_csd_sold_ratio:double,s_eggtart_sold_ratio:double,s_icecream_sold_ratio:double,s_sidefrenchfries_sold_ratio:double,s_sideothers_sold_ratio:double,s_tea_sold_ratio:double,s_twister_sold_ratio:double,s_wing_sold_ratio:double,s_waffle_sold_ratio:double,s_croissant_sold_ratio:double,s_nonfood_sold_ratio:double,s_pie_sold_ratio:double,s_juice_sold_ratio:double,s_rice_sold_ratio:double,s_lto_sold_ratio:double,s_breakfast_avgpartysize:double,s_morning_avgpartysize:double,s_lunch_avgpartysize:double,s_afternoon_avgpartysize:double,s_dinner_avgpartysize:double,s_latenight_avgpartysize:double,s_transport:int,s_typea:int,s_typex:int,s_typesm:int,s_typed:int,s_typec:int,s_typeb:int,s_typer:int,s_typet:int,s_typeapt:int,s_typetpc:int,s_typeo:int,s_typem:int,s_typebs:int,s_typehw:int,s_typeot:int,s_typeu:int,s_typez:int,s_typehp:int,s_types:int,s_typewm:int,kidstoyflag:int,side_flag:int,coffee_flag:int,conge_flag:int,nutrition_flag:int,panini_flag:int,riceroll_flag:int,dabing_flag:int,burger_flag:int,chickensnack_flag:int,cob_flag:int,csd_flag:int,eggtart_flag:int,icecream_flag:int,sidefrenchfries_flag:int,sideothers_flag:int,tea_flag:int,twister_flag:int,wing_flag:int,waffle_flag:int,croissant_flag:int,nonfood_flag:int,pie_flag:int,juice_flag:int,rice_flag:int,lto_flag:int,daypart_sold_ratio:double,category_sold_ratio:double,newproduct_flag:int,item_sell_price:double,item_alc_price:double,price:double,city_name:string>";
        TypeDescription typeDescription = TypeDescription.fromString(schema);
        List<String> listName = typeDescription.getFieldNames();
        List<TypeDescription> typeList= typeDescription.getChildren();
        listName = new ArrayList(listName);
        typeList = new ArrayList(typeList);

        StringBuffer sb = new StringBuffer();
        sb.append("CREATE TABLE `aie_recommendation.preorder_kfc_tradeup_logging`(\n");
        for (int i = 0;i<listName.size();i++) {
            sb.append("`"+listName.get(i)+"` "+orcType2hiveType(typeList.get(i)));
            if(i!=listName.size()-1){
                sb.append(",");
            }
            sb.append("\n");
        }
        sb.append(")\n" +
                "PARTITIONED BY (\n" +
                "`year` int,\n" +
                "`month` int,\n" +
                "`day` int,\n" +
                "`hour` int\n" +
                ")\n" +
                "ROW FORMAT DELIMITED FIELDS TERMINATED BY '\\t' LINES TERMINATED BY '\\n';\n");
        System.out.println(sb.toString());
    }

    public String orcType2hiveType(TypeDescription typeInformation){
        if (Types.STRING().equals(typeInformation)) { return "STRING"; }
        else if( Types.BOOLEAN().equals(typeInformation)){ return "BOOLEAN";}
        else if( Types.BYTE().equals(typeInformation)){ return "STRING";}//
        else if( Types.SHORT().equals(typeInformation)){ return "SMALLINT";}
        else if( Types.INT().equals(typeInformation)){ return "INT";}
        else if( Types.LONG().equals(typeInformation)){ return "BIGINT";}
        else if( Types.FLOAT().equals(typeInformation)){ return "FLOAT";}
        else if( Types.DOUBLE().equals(typeInformation)){ return "DOUBLE";}
        else if( Types.DECIMAL().equals(typeInformation)){ return "DOUBLE";}
        else if( Types.SQL_DATE().equals(typeInformation)){ return "BIGINT";}
        else if( Types.SQL_TIME().equals(typeInformation)){ return "BIGINT";}//
        else if( Types.SQL_TIMESTAMP().equals(typeInformation)){ return "BIGINT";}//
        else if( Types.INTERVAL_MONTHS().equals(typeInformation)){ return "STRING";}//
        else if( Types.INTERVAL_MILLIS().equals(typeInformation)){ return "STRING";}//
        else {
            return "STRING";
        }
    }
}
