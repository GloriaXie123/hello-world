package com._4paradigm.bumblebee.runner.demon.kafka;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.table.api.Types;
import org.apache.flink.table.functions.TableFunction;
import org.apache.flink.types.Row;
import org.apache.flink.api.common.typeinfo.TypeInformation;


import java.util.List;
import java.util.Map;

// The generic type "Tuple2<String, Integer>" determines the schema of the returned table as (String, Integer).
public class Split extends TableFunction<Row> {//Tuple2<String, Integer>  Tuple3<String, String,Integer>
    private String separator = "";

    public Split(String separator) {
        this.separator = separator;
    }

    public void eval(Row[] value) {
        if(value!=null){
            for(int j=0;j<value.length;j++){
                Row row = value[j];

                System.out.println(row.toString());
                System.out.println(row.getArity());
                System.out.println(row.getField(0));
                System.out.println(row.hashCode());
                if(row!=null){
                    String fid0 = null;
                    String fid1 = null;
                    String fid2 = null;
                    if(row.getField(0)!=null){
                        fid0 = row.getField(0).toString();
                    }
                    if(row.getField(1)!=null){
                        fid1 = row.getField(1).toString();
                    }
                    if(row.getField(2)!=null){
                        fid2 = row.getField(2).toString();
                    }
                    //collect(new Tuple3<String, String,Integer>(fid0,fid1,Integer.parseInt(fid2)));
                    collect(row);
                }
                //collect(new Tuple2<String, Integer>(s, s.length()));
            }
        }

    }

    @Override
    public TypeInformation<Row> getResultType() {
        //Types.ROW(Types.STRING ...)
        //Types.ROW(Object ...);
        return Types.ROW(Types.STRING(),Types.STRING(), Types.INT());
    }
}

