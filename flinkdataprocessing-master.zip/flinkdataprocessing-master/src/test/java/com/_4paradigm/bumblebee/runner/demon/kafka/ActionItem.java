package com._4paradigm.bumblebee.runner.demon.kafka;

import lombok.Data;

@Data
public class ActionItem {
    private String linkids;
    private String systemIds;
    private int type;

    @Override
    public String toString() {
        String splitter = "\t";
        return  getLinkids() + splitter
                + getSystemIds() + splitter
                + getType();
    }
}
