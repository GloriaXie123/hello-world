package com._4paradigm.bumblebee.runner.demon.udf;

import com._4paradigm.bumblebee.udf.LogAnalyzeSwitch2;
import org.junit.Test;

public class LogTest {

    //@Test
    public void test(){
        String testStr = "{\"level\":\"info\",\"log_id\":\"15686893421695658\",\"msg\":\"TRADEUP:request:[{\\\"systemTime\\\":\\\"1568689342\\\",\\\"promiseTime\\\":\\\"1568691142\\\",\\\"cityName\\\":\\\"鍖椾含\\\",\\\"cityCode\\\":\\\"00013\\\",\\\"storeCode\\\":\\\"BJN152\\\",\\\"brand\\\":\\\"KFC_D\\\",\\\"transactionId\\\":\\\"15686321441168375\\\",\\\"marketCode\\\":\\\"007\\\",\\\"channel\\\":\\\"MWOS_WechatMini\\\",\\\"key\\\":\\\"a10bcb9c8ee0e145fb3c998c469be67e\\\",\\\"shoppingCart\\\":[{\\\"linkId\\\":\\\"31222\\\",\\\"type\\\":\\\"3\\\",\\\"num\\\":\\\"1\\\",\\\"price\\\":\\\"1600\\\",\\\"realPrice\\\":\\\"0\\\",\\\"systemId\\\":\\\"26343\\\"},{\\\"linkId\\\":\\\"100008340\\\",\\\"type\\\":\\\"1\\\",\\\"num\\\":\\\"1\\\",\\\"price\\\":\\\"3900\\\",\\\"realPrice\\\":\\\"3900\\\",\\\"systemId\\\":\\\"51392\\\",\\\"itemLinkIds\\\":[{\\\"linkId\\\":\\\"26627\\\",\\\"type\\\":\\\"2\\\",\\\"num\\\":\\\"5\\\",\\\"price\\\":\\\"0\\\",\\\"addPrice\\\":\\\"0\\\",\\\"systemId\\\":\\\"6219\\\",\\\"round\\\":\\\"2\\\"}]}],\\\"userCode\\\":\\\"BFF326275706147E5E74E5E1290972C1\\\",\\\"userId\\\":\\\"3ae0100d-3802-4c1d-9170-51419c5eea41_1\\\",\\\"extraParam\\\":\\\"{\\\\\\\"POI_type\\\\\\\":\\\\\\\"\\\\\\\",\\\\\\\"address1\\\\\\\":\\\\\\\"\\\\\\\",\\\\\\\"address2\\\\\\\":\\\\\\\"\\\\\\\",\\\\\\\"coordinate_x\\\\\\\":\\\\\\\"116.481335\\\\\\\",\\\\\\\"coordinate_y\\\\\\\":\\\\\\\"39.977202\\\\\\\",\\\\\\\"deliveryCoupon\\\\\\\":\\\\\\\"0\\\\\\\",\\\\\\\"deliveryTimeOfMap\\\\\\\":\\\\\\\"30\\\\\\\",\\\\\\\"gender\\\\\\\":\\\\\\\"1\\\\\\\",\\\\\\\"iLinkMan\\\\\\\":\\\\\\\"灏忕邯\\\\\\\"}\\\",\\\"openId\\\":\\\"oYkEu5WI2e-8A2K0PtJHhbus8fAA\\\",\\\"isPrime\\\":\\\"0\\\"}]\",\"time\":\"2019-09-17 11:02:22\"}";
        new LogAnalyzeSwitch2("struct<message:string>").eval(testStr,"TRADEUP");
    }
}
