package com._4paradigm.bumblebee.runner.demon.AllConnect;

import com._4paradigm.bumblebee.connector.format.FormatTools;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.orc.TypeDescription;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class SimpleTest {
    //@Test
    public void test1() {
        System.out.println("{" +
                "  \"type\": \"record\"," +
                "  \"name\": \"test\"," +
                "  \"fields\" : [" +
                "    {\"name\": \"a\", \"type\": \"long\"}," +
                "    {\"name\": \"b\", \"type\": \"string\"}" +
                "  ]" +
                "}");
    }

    //@Test
    public void test2() {
        ArrayList<String> names = new ArrayList<String>();
        names.add("transactionId");
        names.add("userCode");
        names.add("couponCode");
        String[] st = {};
        String[] strs = names.toArray(st);
        //String[] strs = () names.toArray();
        System.out.println(strs[1]);
    }



    //@Test
    public void OrcTest() {
        String orcStr = "struct<local_day_string:string,local_time_string:string,foo:string,bar:string>";
        TypeDescription typeDescription = TypeDescription.fromString(orcStr);
        List<String> fieldNames = typeDescription.getFieldNames();
        List<TypeDescription> types = typeDescription.getChildren();

        String[] str = {};
        String[] fieldNamesStrs = fieldNames.toArray(str);

        TypeInformation[] typeCopy = new TypeInformation[types.size()];
        for (TypeDescription type: types) {
            typeCopy[0] = new FormatTools().switchType(type.toString());
        }



        System.out.println(fieldNamesStrs.length);
        System.out.println(typeCopy.length);
        System.out.println(fieldNamesStrs[0]);
        System.out.println(typeCopy[0]);
    }
}
