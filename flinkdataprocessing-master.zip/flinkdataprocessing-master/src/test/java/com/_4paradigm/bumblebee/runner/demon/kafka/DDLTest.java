package com._4paradigm.bumblebee.runner.demon.kafka;

import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.java.StreamTableEnvironment;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.table.api.java.BatchTableEnvironment;

public class DDLTest {
    public static void main(String[] args) throws Exception {

        // FLINK STREAMING QUERY
        EnvironmentSettings fsSettings = EnvironmentSettings.newInstance().useOldPlanner().inStreamingMode().build();
        StreamExecutionEnvironment fsEnv = StreamExecutionEnvironment.getExecutionEnvironment();
        StreamTableEnvironment fsTableEnv = StreamTableEnvironment.create(fsEnv, fsSettings);
        // or TableEnvironment fsTableEnv = TableEnvironment.create(fsSettings);

        /*// FLINK BATCH QUERY
        ExecutionEnvironment fbEnv = ExecutionEnvironment.getExecutionEnvironment();
        BatchTableEnvironment fbTableEnv = BatchTableEnvironment.create(fbEnv);*/

/*// BLINK STREAMING QUERY
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.java.StreamTableEnvironment;
        StreamExecutionEnvironment bsEnv = StreamExecutionEnvironment.getExecutionEnvironment();
        EnvironmentSettings bsSettings = EnvironmentSettings.newInstance().useBlinkPlanner().inStreamingMode().build();
        StreamTableEnvironment bsTableEnv = StreamTableEnvironment.create(bsEnv, bsSettings);
// or TableEnvironment bsTableEnv = TableEnvironment.create(bsSettings);

// BLINK BATCH QUERY
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.TableEnvironment;
        EnvironmentSettings bbSettings = EnvironmentSettings.newInstance().useBlinkPlanner().inBatchMode().build();
        TableEnvironment bbTableEnv = TableEnvironment.create(bbSettings);*/

        String s1 = "CREATE TABLE MyKafka1 (\n" +
                "  `user` BIGINT,\n" +
                "  message VARCHAR,\n" +
                "  ts VARCHAR\n" +
                ") WITH (\n" +
                "  -- declare the external system to connect to\n" +
                "  'connector.type' = 'kafka',\n" +
                "  'connector.version' = '0.10',\n" +
                "  'connector.topic' = 'test1',\n" +
                "  'connector.startup-mode' = 'earliest-offset',\n" +
                "  'connector.properties.0.key' = 'zookeeper.connect',\n" +
                "  'connector.properties.0.value' = '172.27.133.126:2181',\n" +
                "  'connector.properties.1.key' = 'bootstrap.servers',\n" +
                "  'connector.properties.1.value' = '172.27.133.126:9092',\n" +
                "  'update-mode' = 'append',\n" +
                "  -- declare a format for this system\n" +
                "  'format.type' = 'json',\n" +
                "  'format.fail-on-missing-field' = 'false',\n" +
                "  'format.derive-schema' = 'true'"+
                ")";
        fsTableEnv.sqlUpdate(s1);
        String s2 = "CREATE TABLE MyKafka2 (\n" +
                "  `user` BIGINT,\n" +
                "  message VARCHAR,\n" +
                "  ts VARCHAR\n" +
                ") WITH (\n" +
                "  -- declare the external system to connect to\n" +
                "  'connector.type' = 'kafka',\n" +
                "  'connector.version' = '0.10',\n" +
                "  'connector.topic' = 'test',\n" +
                "  'connector.startup-mode' = 'earliest-offset',\n" +
                "  'connector.properties.0.key' = 'zookeeper.connect',\n" +
                "  'connector.properties.0.value' = '172.27.133.126:2181',\n" +
                "  'connector.properties.1.key' = 'bootstrap.servers',\n" +
                "  'connector.properties.1.value' = '172.27.133.126:9092',\n" +
                "  'update-mode' = 'append',\n" +
                "  -- declare a format for this system\n" +
                "  'format.type' = 'json',\n" +
                "  'format.fail-on-missing-field' = 'false',\n" +
                "  'format.derive-schema' = 'true'"+
                ")";
        fsTableEnv.sqlUpdate(s2);
        String s3 ="insert into MyKafka2 select * from MyKafka1";
        fsTableEnv.sqlUpdate(s3);

        fsTableEnv.execute("SY");
    }
}
