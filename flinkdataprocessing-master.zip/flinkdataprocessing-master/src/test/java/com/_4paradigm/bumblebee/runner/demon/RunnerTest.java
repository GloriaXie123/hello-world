package com._4paradigm.bumblebee.runner.demon;

import com._4paradigm.bumblebee.common.BatchAndStreamRunner;

import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.ObjectMapper;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class RunnerTest {
    public static String kafkaArgs = null;
    public static String HiveArgs = null;
    public static String OrcArgs = null;
    public static String FileSystemArgs = null;

    //@Test
    public void testArgs() {
        //kafka
        Map<String, Object> kafkamap = new HashMap<String, Object>() {
            {
                //put("version", "0.11");
                //put("zookeeper.connect", null);//
                put("bootstrap.servers", "172.27.133.19:9092");//"172.27.128.206:9092"
                put("topic", "test");
                //put("groupId", "test");//
                //put("consumeMethod", "latest");
                //put("offSetsJson", null);
                put("format", "json");
                //put("format", "csv");
                //put("fieldDelimiter", ";");
                //put("lineDelimiter", "\n");
                //put("abc", "abc");//模拟 kafka 高级参数
                //put("adad","1223");
                //put("failOnMissingField", false);
                put("schema", "struct<local_day_string:string,local_time_string:string,foo:string,bar:string>");
                put("tableName", "table1");
            }
        };
        Map<String, Object> kafkasqlmap = new HashMap<String, Object>() {
            {
                //flink sql算法名和hql有差异 blink较贴合
                //UNIX_TIMESTAMP(SUBSTR(CONCAT(local_day_string,local_time_string,'0'),0,17),'yyyyMMddHHmmssSSS') as ts
                put("sql","select *,CONCAT(local_day_string,local_time_string,'0') as ts from table1");
            }
        };
        Map<String, Object> kafka2rtidbmap = new HashMap<String, Object>() {
            {
                put("zkEndpoint", "172.27.133.116:7181");
                put("zkRootPath", "/rtidb_1340");
                put("tableName", "timetest");
                put("timeColumn", "ts");
                put("timeColumnFormat", "yyyyMMddHHmmssSSS");
            }
        };
        Map<String, Object> kafka2pdmsmap = new HashMap<String, Object>() {
            {
                put("telamonHost", "http://gateway.360cdh.autoui.4pd.io");
                put("accessKey","e5f1fc70-7d1d-4f60-9bd6-fd949078adad");
                put("workspaceId", "1");
                put("hdfsPrefix", "hdfs://172.27.133.18:8020/tmp/sy");
                put("groupPrn","4paradigm_test/shangyueTest.table-group");
                put("blockSize", "4");
                put("timeLength", "300");
            }
        };
        Map<String, Object> kafkasource = new HashMap<String, Object>() {
            {
                //put("name", "shangyue_201906031208");
                //put("parallelism", 5);
                put("jobType", "stream");
                //put("checkPointPath", null);
                put("sourceType", "kafka");
                put("sourceProperties",kafkamap);
                put("operation", kafkasqlmap);
                put("sinkType", "sdp");
                put("sinkProperties", kafka2pdmsmap);
            }
        };
        //Orc
        Map<String, Object> orcmap = new HashMap<String, Object>() {
            {
                put("hdfsPath", "hdfs://hacluster/tmp/test-data-flat.orc");
                put("schema", "struct<_col1:string,_col2:string>");
                put("tableName", "OrcTable");
            }
        };
        Map<String, Object> orcsqlmap = new HashMap<String, Object>() {
            {
                put("sql", "select _col1 as string1,_col2 as string2 from OrcTable limit 10");
            }
        };
        Map<String, Object> orc2rtidbmap = new HashMap<String, Object>() {
            {
                put("zkEndpoint", "172.27.133.116:7181");
                put("zkRootPath", "/rtidb_1340");
                put("tableName", "test");
                put("timeColumn", "");
                put("timeColumnFormat", "");
            }
        };
        Map<String, Object> orcsource = new HashMap<String, Object>() {
            {
                put("name", "shangyue_201906031208");
                put("parallelism", 5);
                put("jobType", "batch");
                put("checkPointPath", null);
                put("sourceType", "orc");
                put("sourceProperties",orcmap);
                put("operation", orcsqlmap);
                put("sinkType", "rtidb");
                put("sinkProperties", orc2rtidbmap);
            }
        };
        //hive
        Map<String, Object> hivemap = new HashMap<String, Object>() {
            {
                put("hiveMetastoreURI", "thrift://172.27.128.141:21088");
                put("database", "default");
            }
        };
        Map<String, Object> hivesqlmap = new HashMap<String, Object>() {
            {
                put("sql", "select * from student limit 10");
            }
        };
        Map<String, Object> hive2rtidbmap = new HashMap<String, Object>() {
            {
                put("zkEndpoint", "172.27.133.116:7181");
                put("zkRootPath", "/rtidb_1340");
                put("tableName", "student");
                put("timeColumn", "");
                put("timeColumnFormat", "");
            }
        };
        Map<String, Object> hivesource = new HashMap<String, Object>() {
            {
                put("name", "shangyue_201906031208");
                put("parallelism", 5);
                put("jobType", "batch");
                put("checkPointPath", null);
                put("sourceType", "hive");
                put("sourceProperties",hivemap);
                put("operation", hivesqlmap);
                put("sinkType", "rtidb");
                put("sinkProperties", hive2rtidbmap);
            }
        };
        //fileSystem
        Map<String, Object> fileSystemmap = new HashMap<String, Object>() {
            {
                put("path",
//                        "file:///Users/shangyue/OneDrive/git/IDEA/4paradigm/flinkjobrunner/src/test/resources/data/test.csv"
                                "hdfs://hacluster/tmp/test.csv"
                );
                put("format", "csv");
                put("fieldDelimiter", ",");
                put("lineDelimiter", "\n");
                put("quoteCharacter", null);
                put("commentPrefix", null);
                put("ignoreFirstLine", true);
                put("ignoreParseErrors", false);
                put("schema", "struct<name:string,age:int,gender:string>");
                put("tableName", "sm_user");
            }
        };
        Map<String, Object> fileSystemsqlmap = new HashMap<String, Object>() {
            {
                put("sql", "select name as string1 from sm_user");
            }
        };
        Map<String, Object> fileSystem2rtidbmap = new HashMap<String, Object>() {
            {
                put("zkEndpoint", "172.27.133.116:7181");
                put("zkRootPath", "/rtidb_1340");
                put("tableName", "test");
                put("timeColumn", "");
                put("timeColumnFormat", "");
            }
        };
        Map<String, Object> fileSystemsource = new HashMap<String, Object>() {
            {
                put("name", "shangyue_201906031208");
                put("parallelism", 5);
                put("jobType", "batch");
                put("checkPointPath", null);
                put("sourceType", "FileSystem");
                put("sourceProperties",fileSystemmap);
                put("operation", fileSystemsqlmap);
                put("sinkType", "rtidb");
                put("sinkProperties", fileSystem2rtidbmap);
            }
        };
        //JSON.toJSONString()
        ObjectMapper mapper = new ObjectMapper();
        try {
            System.out.println(mapper.writeValueAsString(kafkasource));
            System.out.println(mapper.writeValueAsString(orcsource));
            System.out.println(mapper.writeValueAsString(hivesource));
            System.out.println(mapper.writeValueAsString(fileSystemsource));

            kafkaArgs=URLEncoder.encode(mapper.writeValueAsString(kafkasource), "UTF-8");
            HiveArgs = URLEncoder.encode(mapper.writeValueAsString(hivesource), "UTF-8");
            OrcArgs = URLEncoder.encode(mapper.writeValueAsString(orcsource), "UTF-8");
            FileSystemArgs = URLEncoder.encode(mapper.writeValueAsString(fileSystemsource), "UTF-8");
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        System.out.println(kafkaArgs);
        System.out.println(HiveArgs);
        System.out.println(OrcArgs);
        System.out.println(FileSystemArgs);
    }

    //hosts 必须要配置
    //@Test
    public void testKafkaRunner() throws Exception {
        testArgs();
        String[] arg = {kafkaArgs};
        BatchAndStreamRunner.run(arg);
    }
    //@Test
    public void testHiveRunner() throws Exception {
        testArgs();
        String[] arg = {HiveArgs};
        BatchAndStreamRunner.run(arg);
    }
    // Caused by: java.net.UnknownHostException: hacluster  //TODO 本地调试未解决
    //@Test
    public void testOrcRunner() throws Exception {
        testArgs();
        String[] arg = {OrcArgs};
        BatchAndStreamRunner.run(arg);
    }
    //@Test
    public void testFileSystemRunner() throws Exception {
        testArgs();
        String[] arg = {FileSystemArgs};
        BatchAndStreamRunner.run(arg);
    }

}

