package com._4paradigm.bumblebee.runner.demon.parquet;

import org.apache.flink.streaming.api.functions.source.SourceFunction;


public class AdreeSource implements SourceFunction<Address> {

    @Override
    public void run(SourceContext<Address> sourceContext) throws Exception {
        while(true){
            sourceContext.collect(new Address(1, "a", "b", "c", "12345","adsfdf"));
        }
    }

    @Override
    public void cancel() {

    }
}
