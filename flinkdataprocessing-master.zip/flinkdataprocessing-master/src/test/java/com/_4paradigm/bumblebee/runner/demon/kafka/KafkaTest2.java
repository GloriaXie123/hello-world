package com._4paradigm.bumblebee.runner.demon.kafka;

import org.apache.avro.Schema;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.core.fs.Path;
import org.apache.flink.formats.parquet.avro.ParquetAvroWriters;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.filesystem.StreamingFileSink;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010;
import org.apache.flink.table.api.java.StreamTableEnvironment;
import org.apache.flink.types.Row;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

public class KafkaTest2 {

    public static void main(String[] args) {
        // for batch programs use ExecutionEnvironment instead of StreamExecutionEnvironment
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        env.setParallelism(1);
        env.setMaxParallelism(1);
        StreamTableEnvironment tableEnv = StreamTableEnvironment.create(env);
//
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "172.25.138.65:9010,172.25.138.66:9010,172.25.138.67:9010,172.25.138.68:9010,172.25.138.69:9010,172.25.138.70:9010,172.25.138.72:9010,172.25.138.73:9010");
        properties.setProperty("group.id", "test");
        DataStream<String> stream = env
                .addSource(new FlinkKafkaConsumer010<String>("store_product", new SimpleStringSchema(), properties));

        stream.map(new LogString()).print();
        
        //final StreamingFileSink<String> sink = StreamingFileSink.forRowFormat(new Path(""), new SimpleStringEncoder<>("UTF-8")).build();

        List<Schema.Field> fields = new ArrayList<Schema.Field>();
        fields.add(new Schema.Field("field_name1", Schema.create(Schema.Type.STRING), null, null));
        fields.add(new Schema.Field("field_name2", Schema.create(Schema.Type.INT), null, null));
        Schema schema = Schema.createRecord("foobar", "just a test", "avro.test", false, fields);

        final StreamingFileSink<Row> sink = StreamingFileSink.forBulkFormat(
                Path.fromLocalFile(new File("E:\\code\\ideaCode\\flinkDataStation\\target")),
                ParquetAvroWriters.forReflectRecord(Row.class))
                .build();
        //stream.addSink(sink);




        // create a Table from a SQL query
        //Table sqlResult = tableEnv.sqlQuery("SELECT * FROM table1");
        //sqlResult.printSchema();
        //DataStream stream = tableEnv.toAppendStream(sqlResult, Row.class);
        //stream.print();

        try {
            env.execute();
        } catch (Exception e) {
            System.out.println("运行中出现问题导致任务中断");
            e.printStackTrace();
        }
    }

    public static class LogString implements MapFunction<String, String> {
        @Override
        public String map(String row) throws Exception {
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return df.format(new Date())+"\t"+row;
        }
    }

}
