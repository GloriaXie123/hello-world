package com._4paradigm.bumblebee.runner.demon.table

import java.time.ZoneId

import com._4paradigm.bumblebee.Bucketing.BucketingTableSink
import com._4paradigm.bumblebee.connector.format.FormatTools
import org.apache.flink.core.fs.Path
import org.apache.flink.streaming.connectors.fs.bucketing.{BucketingSink, DateTimeBucketer}
import org.apache.flink.types.Row
import org.apache.flink.streaming.api.scala._
import org.apache.flink.table.api.{EnvironmentSettings, Types}
import org.apache.flink.table.api.scala._
import org.apache.flink.table.descriptors.{Json, Kafka, Schema}

object KafkaSourceTest {
  def main(args: Array[String]): Unit = {

    val fsSettings = EnvironmentSettings.newInstance().useOldPlanner().inStreamingMode().build()
    val fsEnv = StreamExecutionEnvironment.getExecutionEnvironment
    val fsTableEnv = StreamTableEnvironment.create(fsEnv, fsSettings)

    val topic = "city"
    fsTableEnv
      .connect(
      new Kafka()
        .version("0.10")
        .topic(topic)
        .startFromLatest()
        //.property("zookeeper.connect", "localhost:2181")
        .property("bootstrap.servers", "172.27.133.19:9092")
    )

      // declare a format for this system
      .withFormat(
      new Json().deriveSchema()/*
                       .jsonSchema(
                               "{\"type\":\"object\",\"properties\":{\"transactionId\":{\"type\":\"string\"},\"userCode\":{\"type\":\"string\"},\"brand\":{\"type\":\"string\"},\"items\":{\"type\":\"array\",\"items\":{\"type\":\"object\",\"properties\":{\"linkids\":{\"type\":\"string\"},\"systemIds\":{\"type\":\"string\"},\"type\":{\"type\":\"integer\"}}}}}}"
                               // "{  type: 'object',  properties: {    transactionId: {      type: 'string'    },    userCode: {      type: 'string'    }  }}"
                       )*/

    )

      // declare the schema of the table
      .withSchema(
      //struct<transactionId:string,userCode:string,systemTime:bigint,brand:string,channel:string,page:int,action:int,items:array<struct<linkids:string,systemIds:string,type:int>>,promotionCode:string>

      new Schema()
        .field("brand",Types.STRING)
        .field("date",Types.STRING )
        .field("cityName",Types.STRING )

    )
      // specify the update-mode for streaming tables
      .inAppendMode()

      // register as source, sink, or both and under a name
      .registerTableSource("KafkaTable");



    // create a Table from a SQL query
    //SELECT a, word, length FROM MyTable, LATERAL TABLE(split(a)) as T(word, length)
    //SELECT a, word, length FROM KafkaTable, LATERAL TABLE(split(itemList)) as T(word, length)

    //Table sqlResult  = tableEnv.sqlQuery("SELECT itemList_itmeId,itemList_itemRank FROM KafkaTable, LATERAL TABLE(split(itemList)) as T(itemList_itmeId, itemList_itemRank)");
    val sqlResult2  = fsTableEnv.sqlQuery("SELECT * FROM KafkaTable");

    // emit a Table API result Table to a TableSink, same for SQL result
    //tapiResult.insertInto("outputTable");
    sqlResult2.printSchema();
    //val stream = bsTableEnv.toAppendStream(sqlResult2, new Row().getClass);
    val stream = fsTableEnv.toAppendStream[Row](sqlResult2)
    stream.print

    //bucketing Table sink
    val basePath = "hdfs://172.27.133.18:8020/tmp/sy/aie/recommendation/topic_bucket/"+topic
    val path = new Path(basePath)
    val fs = path.getFileSystem()
    fs.delete(path, true);
    val  hdfsSink = new BucketingSink[Row](basePath)
    val bucketFormat = "yyyy-MM-dd-HH";
    hdfsSink.setBucketer(new DateTimeBucketer(bucketFormat, ZoneId.of("Asia/Shanghai")));
    hdfsSink.setBatchSize(1024 * 1024 * 128); //128MB
    val interval = 60000L
    hdfsSink.setBatchRolloverInterval(interval);
    //var df = new SimpleDateFormat("-yyyy-MM-dd-HH-mm");//设置日期格式
    //hdfsSink.setPartSuffix(df.format(new Date()));//设置后缀为系统时间
    hdfsSink.setUseTruncate(false);

    //streamCopy1.addSink(hdfsSink);

    val sink = new BucketingTableSink(hdfsSink,"/t");

    val bucketSchemaStr = "struct<brand:string,date:string,cityName:string>";
    sink.configure(new FormatTools().getOrcSchemaName(bucketSchemaStr),new FormatTools().getOrcSchemaType(bucketSchemaStr));
    fsTableEnv.registerTableSink("bucket_table", sink);

    //stream.addSink(hdfsSink)
    fsTableEnv.sqlUpdate("insert into bucket_table select * from KafkaTable")

    fsTableEnv.execute("scala_job")
  }
}
