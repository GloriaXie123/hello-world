package com._4paradigm.bumblebee.runner.demon.udf;

import com._4paradigm.bumblebee.connector.format.OrcSchemaAnalysis;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.table.api.Types;
import org.apache.flink.types.Row;
import org.apache.orc.TypeDescription;
import org.junit.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class YumChinaSchemaMap {
    public Map<String,String> map ;
    public YumChinaSchemaMap(){
        String store_product_schema = "struct<storeCode:string,channel:string,date:string,linkIds:array<struct<linkId:string,systemId:string,price:string,itemcount:int,iMenuCn:string,iDescCn:string,iSalesFlag:string,validFrom:bigint,validTo:bigint,startTime:bigint,endTime:bigint,showNameCn:string,itemLinkids:array<struct<linkId:string,systemId:string,round:int,price:int,iMenuCn:string,iDescCn:string,iSalesFlag:string,validFrom:bigint,validTo:bigint,startTime:bigint,endTime:bigint,showNameCn:string,quantity:int,itemCount:string>>>>>";
        String order_schema = "struct<transactionId:string,userCode:string,orderTime:bigint,promiseTime:bigint,orderAmount:int,realOrderAmount:int,orderingTime:int,storeCode:string,channel:string,marketCode:string,cityCode:string,cityName:string,brand:string,address:string,addressType:string,coordinate_x:string,coordinate_y:string,userId:string,deliveryTimeOfMap:string,gender:string,iLinkMan:string,iRemark:string,needInvoice:string,invoiceTitle:string,payChannel:string,bookingType:boolean,openId:string,deviceId:string,orderItems:array<struct<orderItemId:string,linkId:string,sizeId:string,baseId:string,num:int,price:int,realPrice:int,type:int,couponCode:string,promotionCode:string,itemLinkIds:array<struct<linkId:string,sizeId:string,baseId:string,num:int,price:int,round:int>>>>>";
        String action_schema = "struct<transactionId:string,userCode:string,systemTime:bigint,brand:string,channel:string,page:int,action:int,items:array<struct<linkIds:string,systemIds:string,type:int>>,promotionCode:string>";
        String menu_force_schema = "struct<date:string,brand:string,storeCode:string,linkId:string,sizeId:string,baseId:string,type:int,couponCode:string,promotionCode:string,validFrom:string,validTo:string,startTime:string,endTime:string,itemLinkIds:array<struct<linkId:string,sizeId:string,baseId:string,type:int,round:int>>>";

        map = new HashMap();
        map.put("store_product_schema",store_product_schema);
        map.put("order_schema",order_schema);
        map.put("action_schema",action_schema);
        map.put("menu_force_schema",menu_force_schema);
    }

    public TypeInformation<Row> getResultType(String word) {
        if(word!=null){
            switch (word){
                case "store_product#linkIds" ://第二层
                    return getTypeRow1(word);
                case "store_product#linkIds#itemLinkids"://第三层
                    return getTypeRow2(word);
                case "order#orderItems"://第二层
                    return getTypeRow1(word);
                case "order#orderItems#itemLinkIds"://第三层
                    return getTypeRow2(word);
                case "action#items"://第二层
                    return getTypeRow1(word);
                case "menu_force#itemLinkIds"://第二层
                    return getTypeRow1(word);
                    default:
                        throw new RuntimeException("没有注册的表 列信息");
            }
        }else{
            throw new RuntimeException("word 不能为 null");
        }
    }

    //取出第2层:List<Row> 的Row类型
    public TypeInformation<Row> getTypeRow1(String word) {
        String topic = word.split("#")[0];
        String colum =  word.split("#")[1];
        TypeDescription typeDescription = TypeDescription.fromString(map.get(topic+"_schema"));

        return new OrcSchemaAnalysis().getFlinkSchema(getTypeRow(typeDescription,colum));
    }

    //取出第3层:List<Row> 中的Row类型中 List<Row> 的Row类型
    public TypeInformation<Row> getTypeRow2(String word) {
        String topic = word.split("#")[0];
        String colum1 =  word.split("#")[1];
        String colum2 =  word.split("#")[2];
        TypeDescription typeDescription = TypeDescription.fromString(map.get(topic+"_schema"));
        return new OrcSchemaAnalysis().getFlinkSchema(getTypeRow(getTypeRow(typeDescription,colum1),colum2));
    }

    //取出typeDescription描述 的colum列 list<Row> 的 Row的类型
    public TypeDescription getTypeRow(TypeDescription typeDescription,String colum) {
        List<String> names = typeDescription.getFieldNames();
        Integer num = null;
        for(int i=0;i<names.size();i++){
            if(names.get(i).equals(colum)){
                num = i;
                break;
            }
        }
        if(num == null){
            throw new RuntimeException("Row 中没有此列 :"+colum);
        }
        TypeDescription typeChild2 = typeDescription.getChildren().get(num);
        TypeDescription type2clm = null;
        if (typeChild2.getCategory().getName().equals("array")){
            type2clm = typeChild2.getChildren().get(0);
        }
        return type2clm;
    }

    @Test
    public void test(){
        System.out.println(getResultType("store_product#linkIds"));
        System.out.println(getResultType("store_product#linkIds#itemLinkids"));
        System.out.println(getResultType("order#orderItems"));
        System.out.println(getResultType("order#orderItems#itemLinkIds"));
        System.out.println(getResultType("action#items"));
        System.out.println(getResultType("menu_force#itemLinkIds"));

        System.out.println(Types.ROW(Types.STRING(), Types.INT()));
    }
}
