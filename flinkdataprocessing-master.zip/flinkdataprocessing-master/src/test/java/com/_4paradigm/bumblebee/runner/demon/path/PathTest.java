package com._4paradigm.bumblebee.runner.demon.path;

import org.apache.flink.api.java.utils.ParameterTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URISyntaxException;

public class PathTest {
    public static final Logger LOG = LoggerFactory.getLogger(PathTest.class);

    public static void main(String[] args) throws IOException, URISyntaxException {
        ParameterTool para = ParameterTool.fromPropertiesFile(PathTest.class.getClassLoader().getResource("").getPath()+"hadoop_conf/" + "env.properties");
        System.out.println(para.get("ai.recommendation.env"));
        LOG.info(para.get("ai.recommendation.env"));

        String path = PathTest.class.getResource("/conf/dev/env.properties").getPath().replace("file:","");

        LOG.info(PathTest.class.getResource("/conf/dev/env.properties").getPath());
        System.out.println(PathTest.class.getResource("/conf/dev/env.properties").getPath());

        LOG.info(PathTest.class.getClassLoader().getResource("conf/dev/env.properties").getPath());
        System.out.println(PathTest.class.getClassLoader().getResource("conf/dev/env.properties").toURI().getPath());

        LOG.info(PathTest.class.getClassLoader().getResource("").getPath());
        System.out.println(PathTest.class.getClassLoader().getResource("").getPath());

        //LOG.info(PathTest.class.getClassLoader().getResource("/").getPath());//NULL
        //System.out.println(PathTest.class.getClassLoader().getResource("/").getPath());

        //ParameterTool para = ParameterTool.fromPropertiesFile(path);

        LOG.info( ParameterTool.fromPropertiesFile(path).get("ai.recommendation.env"));
        LOG.info( ParameterTool.fromPropertiesFile(PathTest.class.getClassLoader().getResource("conf/dev/env.properties").getPath()).get("ai.recommendation.env"));
        LOG.info( ParameterTool.fromPropertiesFile(PathTest.class.getClassLoader().getResource("").getPath()+"conf/dev/env.properties").get("ai.recommendation.env"));
        //LOG.info( ParameterTool.fromPropertiesFile(PathTest.class.getClassLoader().getResource("/").getPath()+"conf/dev/env.properties").get("ai.recommendation.env"));
    }


}
