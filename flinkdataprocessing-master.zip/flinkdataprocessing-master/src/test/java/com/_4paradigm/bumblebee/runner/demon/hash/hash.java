package com._4paradigm.bumblebee.runner.demon.hash;

public class hash {
    public static void main(String[] args) {
        String str = "test3/test3test3.stream-job";
        System.out.println(str.hashCode());
    }
}
