package com._4paradigm.bumblebee.runner.demon.data;

import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Data {
    @Test
    public void testDate() {
        Date date = new Date();
        System.out.println(date.getTime());

        System.out.println(System.currentTimeMillis());

        SimpleDateFormat sdf  = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String current = sdf.format(System.currentTimeMillis());
        System.out.println(current);

        try{
            //1、日期转字符串
            Calendar calendar = Calendar.getInstance();
            Date date1 = calendar.getTime();
            String dateStringParse = sdf.format(date1);
            System.out.println(dateStringParse);
            //2、字符串转日期
            String dateString = "2017-12-20 14:02:08";
            Date dateParse = sdf.parse(dateString);
            System.out.println(dateParse);
        } catch (ParseException e){
            e.printStackTrace();
        }
    }


     @Test
    public void timeTest() throws Exception{
         Date a = new Date(1578370082519L);
        System.out.println(a);

    }
}
