package com._4paradigm.bumblebee.runner.demon.kafka;

import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.table.functions.TableFunction;
import org.apache.flink.types.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class Retrue extends TableFunction<String> {
    private static final Logger LOG = LoggerFactory.getLogger(Retrue.class);
    private long startTime;

    public void eval(String value) {
        startTime = System.currentTimeMillis();
        for(int i = 0;i<10000;i++){
            collect(value);
        }
        long endTime = System.currentTimeMillis();
        System.out.println("UDF时长："+(endTime-startTime)+"ms");
    }
}

