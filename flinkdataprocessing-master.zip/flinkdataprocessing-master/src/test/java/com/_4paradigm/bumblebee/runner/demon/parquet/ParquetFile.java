package com._4paradigm.bumblebee.runner.demon.parquet;

//import org.apache.parquet.avro.AvroParquetWriter;
//import org.apache.parquet.avro.AvroParquetWriter;
import org.apache.flink.core.fs.FileSystem;
import org.apache.flink.core.fs.SafetyNetWrapperFileSystem;
import org.apache.flink.core.fs.local.LocalFileSystem;
import org.apache.flink.runtime.fs.hdfs.HadoopFileSystem;
        import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.TaskAttemptID;
import org.apache.parquet.hadoop.*;
        import org.apache.parquet.hadoop.metadata.CompressionCodecName;
import org.apache.parquet.hadoop.util.ContextUtil;
import org.junit.Test;
import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.parquet.column.ParquetProperties;
import org.apache.parquet.example.data.Group;
import org.apache.parquet.example.data.simple.SimpleGroup;
import org.apache.parquet.example.data.simple.SimpleGroupFactory;
import org.apache.parquet.format.converter.ParquetMetadataConverter;
import org.apache.parquet.hadoop.example.ExampleParquetWriter;
import org.apache.parquet.hadoop.example.GroupReadSupport;
import org.apache.parquet.hadoop.metadata.ParquetMetadata;
import org.apache.parquet.schema.MessageType;
import org.apache.parquet.schema.MessageTypeParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParquetFile {
    Logger LOG = LoggerFactory.getLogger(ParquetFile.class);
    int blockSize = 128 * 1024 * 1024;
    boolean enableDictionary = false;
    CompressionCodecName compression = CompressionCodecName.UNCOMPRESSED;
    String dir = "file:///E:\\OneDrive\\git\\IDEA\\flinkjobrunner\\src\\test\\resources\\data";

        private static Logger logger = LoggerFactory
                .getLogger(ParquetFile.class);
        private static String schemaStr = "message schema {"
                + "optional int64 log_id;"
                + "optional binary idc_id;"
                + "optional int64 house_id;"
                + "optional int64 src_ip_long;"
                + "optional int64 dest_ip_long;"
                + "optional int64 src_port;"
                + "optional int64 dest_port;"
                + "optional int32 protocol_type;"
                + "optional binary url64;"
                + "optional binary access_time;}";
        static MessageType schema =MessageTypeParser.parseMessageType(schemaStr);
        /**
         * 创建时间：2017-8-3
         * 创建者：meter
         * 返回值类型：void
         * @描述：输出MessageType
         */
        //@Test
        public void testParseSchema(){
            logger.info(schema.toString());
        }

        /**
         * 创建时间：2017-8-3
         * 创建者：meter
         * 返回值类型：void
         * @描述：获取parquet的Schema
         * @throws Exception
         */
        //@Test
        public void testGetSchema() throws Exception {
            // windows 下测试入库impala需要这个配置
            System.setProperty("hadoop.home.dir", "E:\\hadoop-2.7.7");
            Path parquetFilePath = new Path(
                    "file:///E:\\OneDrive\\git\\IDEA\\flinkjobrunner\\src\\test\\resources\\data\\test.parq");
            Configuration configuration = new Configuration();
            ParquetMetadata readFooter = null;
            readFooter = ParquetFileReader.readFooter(configuration,
                    parquetFilePath, ParquetMetadataConverter.NO_FILTER);
            MessageType schema =readFooter.getFileMetaData().getSchema();
            logger.info(schema.toString());
        }

        /**
         * 创建时间：2017-8-3
         * 创建者：meter
         * 返回值类型：void
         * @描述：测试写parquet文件
         * @throws IOException
         */
        //@Test
        public void testParquetWriter() throws IOException {
            System.setProperty("hadoop.home.dir", "E:\\hadoop-2.7.7");
            Path file = new Path(
                    "file:///E:\\OneDrive\\git\\IDEA\\flinkjobrunner\\src\\test\\resources\\data\\test.parq");
            ExampleParquetWriter.Builder builder = ExampleParquetWriter
                    .builder(file).withWriteMode(ParquetFileWriter.Mode.OVERWRITE)
                    .withWriterVersion(ParquetProperties.WriterVersion.PARQUET_1_0)
                    //.withCompressionCodec(CompressionCodecName.SNAPPY)
                    //.withConf(configuration)
                    .withType(schema);
            /*
             * file, new GroupWriteSupport(), CompressionCodecName.SNAPPY, 256 *
             * 1024 * 1024, 1 * 1024 * 1024, 512, true, false,
             * ParquetProperties.WriterVersion.PARQUET_1_0, conf
             */
            ParquetWriter<Group> writer = builder.build();
            SimpleGroupFactory groupFactory = new SimpleGroupFactory(schema);

            String[] access_log = { "111111", "22222", "33333", "44444", "55555",
                    "666666", "777777", "888888", "999999", "101010" };
            for(int i=0;i<1000;i++){
                System.out.println("1");
                writer.write(groupFactory.newGroup()
                        .append("log_id", Long.parseLong(access_log[0]))
                        .append("idc_id", access_log[1])
                        .append("house_id", Long.parseLong(access_log[2]))
                        .append("src_ip_long", Long.parseLong(access_log[3]))
                        .append("dest_ip_long", Long.parseLong(access_log[4]))
                        .append("src_port", Long.parseLong(access_log[5]))
                        .append("dest_port", Long.parseLong(access_log[6]))
                        .append("protocol_type", Integer.parseInt(access_log[7]))
                        .append("url64", access_log[8])
                        .append("access_time", access_log[9]));
            }
            System.out.println(writer.getDataSize());
            writer.close();
        }
/**
    @Test
    public void testParquetWriter2() throws IOException {
        System.setProperty("hadoop.home.dir", "E:\\hadoop-2.7.7");
        Path file = new Path(
                "file:///E:\\OneDrive\\git\\IDEA\\flinkjobrunner\\src\\test\\resources\\data\\test2.parq");
        String schemaStr = "{" +
                "  \"namespace\": \"org.myorganization\"," +
                "  \"type\": \"record\"," +
                "  \"name\": \"UserMessage\"," +
                "    \"fields\": [" +
                "      {\"name\": \"timestamp\", \"type\": \"string\"}," +
                "      {\"name\": \"user\", \"type\": \"long\"}," +
                "      {\"name\": \"message\", \"type\": [\"string\", \"null\"]}" +
                "    ]" +
                "}";
        ParquetWriter<Object> writer = AvroParquetWriter.builder(file)
                .withSchema(new Schema.Parser().parse(schemaStr))
               // .withCompressionCodec(CompressionCodecName.UNCOMPRESSED)
                .withPageSize(500)
                .withRowGroupSize(128 * 1024 * 1024)
                .withDictionaryEncoding(false)
                .withWriteMode(ParquetFileWriter.Mode.OVERWRITE)
                .withValidation(false)
                .build();
        SimpleGroupFactory groupFactory = new SimpleGroupFactory(schema);
        String[] access_log = { "111111", "22222", "33333", "44444", "55555",
                "666666", "777777", "888888", "999999", "101010" };
        for(int i=0;i<1000;i++){
            System.out.println("1");
            writer.write(groupFactory.newGroup()
                    .append("log_id", Long.parseLong(access_log[0]))
                    .append("idc_id", access_log[1])
                    .append("house_id", Long.parseLong(access_log[2]))
                    .append("src_ip_long", Long.parseLong(access_log[3]))
                    .append("dest_ip_long", Long.parseLong(access_log[4]))
                    .append("src_port", Long.parseLong(access_log[5]))
                    .append("dest_port", Long.parseLong(access_log[6]))
                    .append("protocol_type", Integer.parseInt(access_log[7]))
                    .append("url64", access_log[8])
                    .append("access_time", access_log[9]));
        }
        System.out.println(writer.getDataSize());
        writer.close();
    }
    **/

    //@Test
    public void testParquetWriter3() throws IOException {
        System.setProperty("hadoop.home.dir", "E:\\hadoop-2.7.7");
        //org.apache.hadoop.mapreduce.RecordWriter<Void, Row> realWriter;
        JobConf jobConf = new JobConf();
        // init and register file system
        String fileName = "Test" + 1 + "-" +
                1 + ".parquet";
        org.apache.flink.core.fs.Path path = new org.apache.flink.core.fs.Path(dir, fileName);
        FileSystem fs = path.getFileSystem();
        if (fs instanceof SafetyNetWrapperFileSystem) {
            fs = ((SafetyNetWrapperFileSystem) fs).getWrappedDelegate();
        }

        if (fs instanceof HadoopFileSystem) {
            //((HadoopFileSystem) fs).getConfig()
            jobConf.addResource(((HadoopFileSystem) fs).getHadoopFileSystem().getConf());
        }

        if (!(fs instanceof LocalFileSystem || fs instanceof HadoopFileSystem)) {
            throw new RuntimeException("FileSystem: " + fs.getClass().getCanonicalName() + " is not supported.");
        }

        // clean up output file in case of failover.
        fs.delete(path, true);


//        ParquetOutputFormat realOutputFormat = new ExampleOutputFormat();
//                ParquetOutputFormat();
        //new RowWritableWriteSupport(fieldTypes)

        LOG.info("creating new record writer..." + this);

//        String PARQUET_FLINK_SCHEMA = "parquet.flink.schema";
//        jobConf.set(PARQUET_FLINK_SCHEMA, ParquetSchemaConverter.convert(fieldNames, fieldTypes).toString());
//        RowWritableWriteSupport.setSchema(ParquetSchemaConverter.convert(fieldNames, fieldTypes), jobConf);

        try {
            // create a TaskInputOutputContext

            TaskAttemptID taskAttemptID = new TaskAttemptID();

            TaskAttemptContext taskContext = ContextUtil.newTaskAttemptContext(jobConf, taskAttemptID);

            LOG.info("initialize serde with table properties.{}"+taskContext);
            initializeSerProperties(taskContext);
            ParquetWriter<Group> realWriter= ExampleParquetWriter
                    .builder(new Path(fileName)).withWriteMode(ParquetFileWriter.Mode.OVERWRITE)
                    .withWriterVersion(ParquetProperties.WriterVersion.PARQUET_1_0)
                    .withCompressionCodec(CompressionCodecName.SNAPPY)
                    .withConf(ContextUtil.getConfiguration(taskContext))
                    .withType(schema).build();
            LOG.info("creating real writer to write at " + dir);
            System.out.println(taskContext);
            System.out.println(path.toUri());
           // realWriter = realOutputFormat.getRecordWriter(taskContext, new org.apache.hadoop.fs.Path(path.toUri()));

            LOG.info("real writer: " + realWriter);
            //realWriter.write(null,new Row(3));
            SimpleGroupFactory groupFactory = new SimpleGroupFactory(schema);
            String[] access_log = { "111111", "22222", "33333", "44444", "55555",
                    "666666", "777777", "888888", "999999", "101010" };
            realWriter.write(groupFactory.newGroup()
                    .append("log_id", Long.parseLong(access_log[0]))
                    .append("idc_id", access_log[1])
                    .append("house_id", Long.parseLong(access_log[2]))
                    .append("src_ip_long", Long.parseLong(access_log[3]))
                    .append("dest_ip_long", Long.parseLong(access_log[4]))
                    .append("src_port", Long.parseLong(access_log[5]))
                    .append("dest_port", Long.parseLong(access_log[6]))
                    .append("protocol_type", Integer.parseInt(access_log[7]))
                    .append("url64", access_log[8])
                    .append("access_time", access_log[9]));
            realWriter.close();
        } catch (Exception e) {
           e.printStackTrace();
        }
    }



        private void initializeSerProperties(JobContext job) {
            org.apache.hadoop.conf.Configuration conf = ContextUtil.getConfiguration(job);
            if (blockSize > 0) {
                LOG.info("get override parquet.block.size property with: {}", blockSize);
                conf.setInt(ParquetOutputFormat.BLOCK_SIZE, blockSize);

                LOG.info("get override dfs.blocksize property with: {}", blockSize);
                conf.setInt("dfs.blocksize", blockSize);
            }

            LOG.info("get override parquet.enable.dictionary property with: {}", enableDictionary);
            conf.setBoolean(
                    ParquetOutputFormat.ENABLE_DICTIONARY, enableDictionary);

            if (compression != null) {
                //get override compression properties via "tblproperties" clause if it is set
                LOG.info("get override compression properties with {}", compression.name());
                conf.set(ParquetOutputFormat.COMPRESSION, compression.name());
            }
        }

        /**
         * 创建时间：2017-8-3
         * 创建者：meter
         * 返回值类型：void
         * @throws IOException
         * @描述：测试读parquet文件
         */
        //@Test
        public void testParquetReader() throws IOException{
            System.setProperty("hadoop.home.dir", "E:\\hadoop-2.7.7");
            Path file = new Path("file:///E:\\OneDrive\\git\\IDEA\\flinkjobrunner\\src\\test\\resources\\data\\test.parq");
            ParquetReader.Builder<Group> builder = ParquetReader.builder(new GroupReadSupport(), file);

            ParquetReader<Group> reader = builder.build();
            SimpleGroup group =(SimpleGroup) reader.read();
            logger.info("schema:"+group.getType().toString());
            logger.info("idc_id:"+group.getString(1, 0));
        }




}
