package com._4paradigm.bumblebee.runner.demon.path;

public class Path {

    //@Test
    public void testSysystem (){
        String property =System.getProperty("user.dir");
        System.out.println(property);
        java.net.URL uri = this.getClass().getResource("/");
        System.out.println(uri);
        System.out.println(this.getClass().getResource("/").getPath());
    }
}
