package com._4paradigm.bumblebee.runner.demon.kafka;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.*;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.lang.String;


public class JsonAnalysis<O> implements MapFunction<String, O> {
    public static final Logger LOG = LoggerFactory.getLogger(JsonAnalysis.class);
    ObjectMapper mapper ;
    HashMap<String,Object> jsonMap;
    O mType;

    public JsonAnalysis(Class<O> clz) {
        try {
            mType = clz.newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public HashMap<String, Object> Stringmap2HashMap(String value)  {
        if(mapper == null ){
            mapper = new ObjectMapper();
        }
        try {
            jsonMap  = mapper.readValue(value, new HashMap<String,Object>().getClass());
        } catch (Exception e) {
            try {
                LOG.warn("不是标准json，截取前的字符串： "+value);
                value = value.substring(value.indexOf("{"),value.lastIndexOf("}")+1);
                LOG.warn("不是标准json，截取后的字符串： "+value);
                jsonMap  = mapper.readValue(value, new HashMap<String,Object>().getClass());
            }catch (Exception err) {
                jsonMap = new HashMap<>();
                LOG.error("不是标准json，截取后依然不是json："+value);
                //e.printStackTrace();
                //err.printStackTrace();
            }
        }
        return jsonMap;
    }

    @Override
    public O map(String value) throws Exception {
        switch (mType.getClass().toString()){
            case "class org.apache.flink.api.java.tuple.Tuple1":
                return (O)new Tuple1("1");
            case "class org.apache.flink.api.java.tuple.Tuple2" :
                return (O)new Tuple2("1","2");
            case "class org.apache.flink.api.java.tuple.Tuple3" :
                return (O)new Tuple3("1","2","3");
            case "class org.apache.flink.api.java.tuple.Tuple4" :
                return (O)new Tuple4("1","2","3","4");
            case "class org.apache.flink.api.java.tuple.Tuple5" :
                return (O)new Tuple5("1","2","3","4","5");
            case "class org.apache.flink.api.java.tuple.Tuple6" :
                return (O)new Tuple6("1","2","3","4","5","6");
            case "class org.apache.flink.api.java.tuple.Tuple7" :
                return (O)new Tuple7("1","2","3","4","5","6","7");
            //你可以有任意数量的case语句
            default :
                //语句
        }


        return null;
    }
}