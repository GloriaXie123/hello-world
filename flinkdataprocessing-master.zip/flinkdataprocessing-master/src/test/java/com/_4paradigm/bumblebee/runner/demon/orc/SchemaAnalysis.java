package com._4paradigm.bumblebee.runner.demon.orc;

import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.orc.TypeDescription;

import java.util.ArrayList;
import java.util.List;

public class SchemaAnalysis {
    public static void main(String[] args) {
        String orcSchemaStr = "struct<transactionId:string,userCode:string,systemTime:bigint,brand:string,channel:string,page:int,action:int,items:array<struct<linkids:string,systemIds:string,type:int>>,promotionCode:string>";
        TypeDescription typeDescription = TypeDescription.fromString(orcSchemaStr);

        TypeInformation type = flind (typeDescription);
        System.out.println(type);

        TypeInformation type2 =Types.ROW_NAMED(
                new String[] { "transactionId", "userCode", "systemTime", "brand", "channel", "page", "action","items","promotionCode" },
                new TypeInformation[]{ Types.STRING, Types.STRING, Types.LONG, Types.STRING,Types.STRING,Types.INT,Types.INT,Types.LIST(Types.ROW_NAMED(
                        new String[] { "linkids", "systemIds", "type" },
                        new TypeInformation[]{ Types.STRING, Types.STRING,Types.INT}
                )), Types.STRING});
        System.out.println(type2);

    }

    //@Test
    public void testSchema()  {
        String schemaValue =
                //"struct<C_MAC_ADDR:string,C_CUSTOMER_ID:string,C_MERCH_ID:string,C_CARD_NO:string,C_ACCT_ZONE:string,N_TRXCODE:string,C_DAILY_OPENBUY:string,C_INDI_OPENBUY:string,N_PHONE_NO:string,N_BOUND_PHONE_NO:string,C_ACCT_NO:string,D_TXN_DATETIME:string,N_TXN_AMT:string,C_TXN_CURR:string,C_PAY_NAME:string,C_PAYEE_ACCT:string,C_PAYEE_NAME:string,C_SK_SEQ:string,C_TXN_IP:string,C_BALANCE:string,C_ACCT_TYPE:string,C_TXN_TYPE:string,C_TXN_CHANNEL:string,C_PAYEE_BANK_NAME:string,C_SERIAL_NO:string,D_REGISTER_DATETIME:string,C_PAYEE_ACCT_ZONE:string,C_COMMONLY_PAYEE_FLAG:string,C_TRUST_PAYEE_FLAG:string,C_MEDIUM_NO:string,C_TRUST_CLIENT_FLAG:string,C_VERIFY_TYPE:string,C_PAYEE_CUSTOMER_ID:string,C_CPU_ID:string,C_MEMORY_CAPACITY:string,C_SYSTEM_VERSION:string,C_BROWSER_VERSION:string,C_BROWSER_LANG:string,C_SCREEN_RESOLUTION:string,C_APP_VERSION:string,C_FACTORY_INFO:string>";
                //"struct<C_MAC_ADDR:string,C_CUSTOMER_ID:string,C_MERCH_ID:string,C_CARD_NO:string,C_ACCT_ZONE:string,N_TRXCODE:string,C_DAILY_OPENBUY:string,C_INDI_OPENBUY:string,N_PHONE_NO:string,N_BOUND_PHONE_NO:string,C_ACCT_NO:string,D_TXN_DATETIME:string,N_TXN_AMT:string,C_TXN_CURR:string,C_PAY_NAME:string,C_PAYEE_ACCT:string,C_PAYEE_NAME:string,C_SK_SEQ:string,C_TXN_IP:string,C_BALANCE:string,C_ACCT_TYPE:string,C_TXN_TYPE:string,C_TXN_CHANNEL:string,C_PAYEE_BANK_NAME:string,C_SERIAL_NO:string,D_REGISTER_DATETIME:string,C_PAYEE_ACCT_ZONE:string,C_COMMONLY_PAYEE_FLAG:string,C_TRUST_PAYEE_FLAG:string,C_MEDIUM_NO:string,C_TRUST_CLIENT_FLAG:string>";
                "struct<o_age_bin:int,ocus_invalid_acct_cert_actl_result:string,i_adays_bin:int,icus_invalid_acct_cert_actl_result:string,c_app_version:string,ocus_cert_provi_situ_type_cd:string,c_txn_unit_price:string,c3_outareacode2_inareacode2_amt_bin:string,ocus_icbc_emply_ind:string,c_indi_openbuy:double,c3_o_city_i_city_city:string,ocus_birth_dt:string,o_lola_1:double,o_lola_2:double,i_city:string,c_payee_customer_id:string,c_hour:int,c_verify_type:string,o_adays:bigint,ip_pre_bin1:string,ip_pre_bin2:string,c_txn_puduct_type:string,icus_birth_dt:string,outcustnum:string,i_odays:bigint,ocus_asset_month_accum:string,c_acct_type:string,c_memory_capacity:double,c3_outareacode2_inareacode2_c_hour:string,c3_o_prov_o_adays_bin_i_adays_bin:string,o_adays_bin:int,icus_marriage_status_cd:string,ocus_proper_career_cd:string,c_txn_ip:string,icus_disp_situ_type_cd:string,usercerttype:int,flag:string,c2_outareacode2_inareacode2:string,ocus_career_cd:string,city:string,n_phone_no:string,icus_career_cd:string,c_trust_payee_flag:string,c_browser_version:string,n_trxcode:string,c_payee_bank_name:string,icus_dom_resdnt_ind:string,icus_adj_situ_type_cd:string,o_odays:bigint,c_acct_no:string,c2_czoneconde_outareacode2:string,c3_outareacode2_inareacode2_czoneconde:string,c_system_version:string,ocus_start_dt:string,c_factory_info:string,icus_integrality_check_result:string,c_merch_id:string,prov:string,c3_o_prov_i_prov_prov:string,ocus_career_status_cd:string,c_day:int,c_acct_zone:string,ocus_integrality_ind_cd:string,inareacode2:string,c2_czoneconde_inareacode2:string,bilabel:string,c_commonly_payee_flag:string,icus_start_dt:string,icus_proper_industry_cd:string,o_age:int,c_trx_direction_flag:string,is_tx_z:int,icus_birth_cty_cd:string,c_pay_name:string,ocus_vip_cust_ind:string,ocus_belong_corp_type_cd:string,lola_1:double,ocus_pri_econ_src_cd:string,lola_2:double,c3_o_prov_i_prov_amt_bin:string,c2_prov_o_prov:string,i_country:string,d_txn_datetime:string,ocus_ethnic_cd:string,c_mac_addr:string,logtime:string,c_card_no:string,ocus_integrality_check_result:string,country:string,icus_pri_econ_src_cd:string,ocus_disp_situ_type_cd:string,incustnum:string,out_card_pre_bin1:string,c_medium_no:string,out_card_pre_bin2:string,is_tx_abn:int,c3_o_city_o_adays_bin_i_adays_bin:string,c_sk_seq:string,icus_ethnic_cd:string,ocus_proper_industry_cd:string,c2_city_i_city:string,c2_prov_i_prov:string,icus_icbc_emply_ind:string,ocus_edu_degree_cd:string,c_payee_acct_zone:string,ts0:bigint,icus_vip_cust_ind:string,c_serial_no:string,o_country:string,c3_o_city_o_age_bin_i_age_bin:string,ocus_birth_cty_cd:string,logdate:string,inaccttype:int,c_txn_curr:string,lat:double,is_intran:string,oi_country:string,c2_o_city_i_city:string,c2_o_adays_bin_i_adays_bin:string,c2_o_prov_i_prov:string,c3_o_city_i_city_amt_bin:string,icus_belong_corp_type_cd:string,ocus_gender_cd:string,incardopendate:string,i_age_bin:int,c_txn_type:string,icus_integrality_ind_cd:string,icus_cust_sell_status_cd:string,long_0:double,c_customer_id:string,outaccttype:int,c_cpu_id:string,czoneconde:string,oi_prov:string,in_card_pre_bin2:string,ocus_identity_actl_result_type_cd:string,icus_edu_degree_cd:string,ocus_adj_situ_type_cd:string,in_card_pre_bin1:string,d_register_datetime:string,icus_identity_actl_result_type_cd:string,n_bound_phone_no:string,outcardopendate:string,c3_o_city_i_city_c_hour:string,icus_cert_provi_situ_type_cd:string,c_balance:double,i_odays_bin:int,d_txn_time:string,c_payee_name:string,c_browser_lang:string,ocus_dom_resdnt_ind:string,oi_city:string,icus_proper_career_cd:string,c_trust_client_flag:string,amt_bin:int,i_age:int,icus_gender_cd:string,o_prov:string,outareacode2:string,i_prov:string,i_lola_2:double,i_lola_1:double,c2_o_age_bin_i_age_bin:string,c_register_flag:string,ocus_marriage_status_cd:string,n_txn_amt:double,o_city:string,label:string,c_txn_count:string,c_dow:int,i_adays:bigint,incardno:string,icus_asset_month_accum:string,c2_city_o_city:string,mac_pre_bin2:string,c2_outaccttype_inaccttype:string,mac_pre_bin1:string,d_txn_date:string,c_daily_openbuy:double,c_tradflag:string,c_screen_resolution:string,o_odays_bin:int,d_txn_time_std:bigint,c_txn_channel:string,icus_career_status_cd:string,c3_o_prov_i_prov_c_hour:string,c3_o_prov_o_age_bin_i_age_bin:string,ocus_cust_sell_status_cd:string>";
        System.out.println(TypeDescription.fromString(schemaValue).getFieldNames());
        System.out.println(TypeDescription.fromString(schemaValue).getChildren());
    }

    public static TypeInformation flind (TypeDescription typeDescription){
        String CategoryName = typeDescription.getCategory().getName();
        switch (CategoryName){
            case "boolean" : return Types.BOOLEAN;
            case "tinyint" : return Types.SHORT;
            case "smallint" : return Types.SHORT;
            case "int" : return Types.INT;
            case "bigint" : return Types.LONG;
            case "float" : return Types.FLOAT;
            case "double" : return Types.DOUBLE;
            case "string" : return Types.STRING;
            case "date" : return Types.SQL_DATE;
            case "timestamp" : return Types.SQL_TIMESTAMP;
            //case "binary" : return  Types.BINARY;
            // case "decimal" : return  Types.DECIMAL;
            case "varchar" : return Types.STRING;
            case "char" : return Types.STRING;
            case "array" :
                    if (typeDescription.getChildren().size() != 1) {//TODO
                        throw new RuntimeException("list 是多种类型的列,正在支持，请使用结构体struct");
                    }else {
                        if (typeDescription.getChildren().get(0).getCategory().equals("struct")) {
                            return Types.OBJECT_ARRAY(flind(typeDescription.getChildren().get(0)));
                        } else {//TODO 更多复合复杂类型待验证 支持Types.PRIMITIVE_ARRAY()
                            return Types.LIST(flind(typeDescription.getChildren().get(0)));
                        }
                    }
            case "map" :
                throw new RuntimeException("建议使用结构体struct") ;
            case "struct" :
                List<String> fieldNames = typeDescription.getFieldNames();
                String[] fieldNamesCopy = new String[fieldNames.size()];
                for(int i = 0; i < fieldNames.size(); i = i+1){
                    fieldNamesCopy[i] = fieldNames.get(i);
                }
                List<TypeDescription> typeChildren = typeDescription.getChildren();
                TypeInformation[] typeChildrenCopy = new TypeInformation[typeChildren.size()];
                for(int i = 0; i < typeChildren.size(); i = i+1){
                    typeChildrenCopy[i] = flind(typeChildren.get(i));
                }
                return Types.ROW_NAMED(fieldNamesCopy,typeChildrenCopy);
            case "uniontype" :
                throw new RuntimeException("不支持的数据类型") ;
            default :
                throw new RuntimeException("不支持的数据类型");
        }
    }
}
