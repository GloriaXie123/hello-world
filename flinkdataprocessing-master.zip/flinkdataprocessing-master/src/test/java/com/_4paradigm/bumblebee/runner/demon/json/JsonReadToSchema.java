package com._4paradigm.bumblebee.runner.demon.json;

import org.apache.commons.io.FileUtils;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.orc.TypeDescription;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class JsonReadToSchema {
    public static void main(String[] args) throws IOException {
        String basepath = "E:\\code\\ideaCode\\flinkDataStation\\src\\test\\resources\\data\\sample-schema-0719.json";
        String input = FileUtils.readFileToString(new File(basepath), "UTF-8");//内容

        //json strng
        ObjectMapper mapper = new ObjectMapper();
        ArrayList jsonArray  = mapper.readValue(input,new ArrayList<HashMap<String,String>>().getClass());
        String jsonCopy = mapper.writeValueAsString(jsonArray);
        System.out.println(jsonCopy);

        String str = "struct<";
        Iterator<HashMap<String,String>> it = jsonArray.iterator();
        while (it.hasNext()){
            HashMap<String,String> map = it.next();
            str = str +  map.get("name") +":"+ map.get("type").toLowerCase()+",";
        }
        str = str.substring(0,str.length()-1)+">";
        System.out.println(str);

        TypeDescription typeDescription = TypeDescription.fromString(str);
        List<String> list = typeDescription.getFieldNames();
        System.out.println(list);
        System.out.println(list.size());
        System.out.println(typeDescription.toJson());
    }
}
