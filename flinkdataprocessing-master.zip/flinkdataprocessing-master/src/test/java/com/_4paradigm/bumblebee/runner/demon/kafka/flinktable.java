package com._4paradigm.bumblebee.runner.demon.kafka;

import com._4paradigm.bumblebee.connector.format.FormatTools;
import com._4paradigm.bumblebee.connector.format.OrcSchemaAnalysis;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.serialization.SimpleStringEncoder;
import org.apache.flink.api.common.typeinfo.TypeInformation;
//import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.core.fs.Path;
import org.apache.flink.formats.parquet.avro.ParquetAvroWriters;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.filesystem.StreamingFileSink;
import org.apache.flink.streaming.api.functions.sink.filesystem.bucketassigners.DateTimeBucketAssigner;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.java.StreamTableEnvironment;
import org.apache.flink.table.descriptors.*;
import org.apache.flink.api.common.serialization.SimpleStringEncoder;
import org.apache.flink.core.fs.Path;
import org.apache.flink.streaming.api.functions.sink.filesystem.StreamingFileSink;
import org.apache.flink.table.api.Types;
import org.apache.flink.types.Row;
import org.apache.flink.core.fs.Path;


import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class flinktable {
    public static void main(String[] args) throws Exception {
        // for batch programs use ExecutionEnvironment instead of StreamExecutionEnvironment
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        env.setParallelism(1);
        env.enableCheckpointing(60000);
        //env.setMaxParallelism(1);
        // create a TableEnvironment
        // for batch programs use BatchTableEnvironment instead of StreamTableEnvironment

        String orcSchema = "struct<local_day_string:string,local_time_string:string,foo:string,bar:string>";
        StreamTableEnvironment tableEnv = StreamTableEnvironment.create(env);

        tableEnv.connect(
                new Kafka()
                        .version("0.11")
                        .topic("test")
                        .startFromLatest()
                        .property("bootstrap.servers", "172.27.133.19:9092")
        )
                // declare a format for this system
                .withFormat(new Json().deriveSchema().failOnMissingField(false))
                // declare the schema of the table
                .withSchema(
                        new FormatTools().getSchema(orcSchema)
                )
                // specify the update-mode for streaming tables
                .inAppendMode()
                // register as source, sink, or both and under a name
                .registerTableSource("table1");
        // create a Table from a SQL query
        Table sqlResult = tableEnv.sqlQuery("SELECT * FROM table1");
        sqlResult.printSchema();
        DataStream stream = tableEnv.toAppendStream(sqlResult, Row.class);

        Schema schema = new OrcSchemaAnalysis().getAvroSchema(orcSchema);
        System.out.println(schema.toString());

        final StreamingFileSink<GenericRecord> sink = StreamingFileSink.forBulkFormat(
                new Path("hdfs://172.27.133.18:8020/tmp/sy/aie/recommendation/topic_bucket/test"),
                ParquetAvroWriters.forGenericRecord(schema))
                //.withBucketAssigner(new DateTimeBucketAssigner<>("'date='yyyy-MM-dd'/hour='HH"))
                .build();

/*
        StreamingFileSink
                .forRowFormat(new Path(""), new SimpleStringEncoder<>("UTF-8"))
                .build();
*/


        SingleOutputStreamOperator<GenericRecord> GenericRecordStream = stream.map(new Row2GenericRecord(schema.toString()));
        //st.print();
        GenericRecordStream.addSink(sink);
                /**
         //对数据的source有格式限制，不能直接转换使用
        final File folder =new File("data");
         String schemaStr = "{" +
                 "  \"namespace\": \"org.myorganization\"," +
                 "  \"type\": \"record\"," +
                 "  \"name\": \"UserMessage\"," +
                 "    \"fields\": [" +
                 "      {\"name\": \"timestamp\", \"type\": \"string\"}," +
                 "      {\"name\": \"user\", \"type\": \"long\"}," +
                 "      {\"name\": \"message\", \"type\": [\"string\", \"null\"]}" +
                 "    ]" +
                 "}";
        org.apache.avro.Schema schema = new org.apache.avro.Schema.Parser().parse(schemaStr);
        stream.addSink(
                StreamingFileSink.forBulkFormat(
                        Path.fromLocalFile(folder),
                        ParquetAvroWriters.forGenericRecord(schema))
                        .build());
**/
        env.execute();
    }

}

class Row2GenericRecord implements MapFunction<Row, GenericRecord> {
    String schemaStr;
    public Row2GenericRecord(String schemaStr){
        this.schemaStr =schemaStr;
    }
    @Override
    public GenericRecord map(Row row) throws Exception {
        int arity = row.getArity();
        org.apache.avro.Schema schema = new org.apache.avro.Schema.Parser().parse(schemaStr);
        GenericRecord genericReocrd = new GenericData.Record(schema);
        List<org.apache.avro.Schema.Field> list = schema.getFields();
        for(int j=0;j<arity;j++){

            genericReocrd.put(list.get(j).name(),row.getField(j));
        }
        return genericReocrd;
    }
}
