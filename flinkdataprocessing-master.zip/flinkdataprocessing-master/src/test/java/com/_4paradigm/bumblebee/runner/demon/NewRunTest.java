package com._4paradigm.bumblebee.runner.demon;

import com._4paradigm.bumblebee.common.BatchAndStreamRunner;
import org.apache.commons.io.FileUtils;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;

import java.io.*;
import java.net.URLEncoder;
import java.util.HashMap;

public class NewRunTest {
    public static void main(String[] args) throws IOException {
        String path = jsonPath();//地址
        //String jsonStr = readJsonFile(path);//内容
        String input = FileUtils.readFileToString(new File(path), "UTF-8");//内容

        //json strng
        ObjectMapper mapper = new ObjectMapper();
        HashMap<String,Object> jsonMap  = mapper.readValue(input, new HashMap<String,Object>().getClass());
        String jsonCopy = mapper.writeValueAsString(jsonMap);
        System.out.println(jsonCopy);

        //encode string
        String encodeStr = URLEncoder.encode(jsonCopy, "UTF-8");
        System.out.println(encodeStr);

        //Test Run
        String[] arg = {encodeStr};
        BatchAndStreamRunner.run(arg);
    }

    public  static String  jsonPath() throws IOException {
        java.net.URL uri =NewRunTest.class.getResource("/");
        String path = new File(uri.getPath(),"../../"+ "Json/devJson/order.json").getCanonicalPath();
         return  path;
    }
    //@Test
    public  void jsonPathTest() throws IOException {
        System.out.println(System.getProperty("user.dir"));
        System.out.println(NewRunTest.class.getResource("/"));
        System.out.println(NewRunTest.class.getResource(""));
    }

    /**
     * 读取json文件，返回json串
     * @param fileName
     * @return
     */
    public static String readJsonFile(String fileName) {
        String jsonStr = "";
        try {
            File jsonFile = new File(fileName);
            FileReader fileReader = new FileReader(jsonFile);

            Reader reader = new InputStreamReader(new FileInputStream(jsonFile),"utf-8");
            int ch = 0;
            StringBuffer sb = new StringBuffer();
            while ((ch = reader.read()) != -1) {
                sb.append((char) ch);
            }
            fileReader.close();
            reader.close();
            jsonStr = sb.toString();
            return jsonStr;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
