package com._4paradigm.bumblebee.runner.demon.kafka;
import com._4paradigm.bumblebee.Bucketing.BucketingTableSink;
import com._4paradigm.bumblebee.connector.format.FormatTools;
import com._4paradigm.bumblebee.connector.format.OrcSchemaAnalysis;
import com._4paradigm.bumblebee.connector.format.YumChinaJsonRowDeserializationSchema;
import com._4paradigm.bumblebee.ritdb.RtiDBOutputFormat;
import com._4paradigm.bumblebee.ritdb.RtiDBTableSink;
import com._4paradigm.bumblebee.udf.Drill;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.core.fs.FileSystem;
import org.apache.flink.core.fs.Path;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.fs.bucketing.BucketingSink;
import org.apache.flink.streaming.connectors.fs.bucketing.DateTimeBucketer;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010;

import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.java.StreamTableEnvironment;
import org.apache.flink.table.sinks.TableSink;
import org.apache.flink.types.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class KafkaStreamToTable {
    public static final Logger LOG = LoggerFactory.getLogger(KafkaStreamToTable.class);

    public static void main(String[] args) throws IOException {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
        env.getConfig().setRestartStrategy(RestartStrategies.noRestart());
        env.getConfig().disableSysoutLogging();
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);

        Map<String,String> map ;
        String store_product_schema = "struct<storeCode:string,channel:string,date:string,linkIds:array<struct<linkId:string,systemId:string,price:string,itemcount:int,iMenuCn:string,iDescCn:string,iSalesFlag:string,validFrom:bigint,validTo:bigint,startTime:bigint,endTime:bigint,showNameCn:string,itemLinkids:array<struct<linkId:string,systemId:string,round:int,price:int,iMenuCn:string,iDescCn:string,iSalesFlag:string,validFrom:bigint,validTo:bigint,startTime:bigint,endTime:bigint,showNameCn:string,quantity:int,itemCount:string>>>>>";
        String order_schema = "struct<transactionId:string,userCode:string,orderTime:bigint,promiseTime:bigint,orderAmount:int,realOrderAmount:int,orderingTime:int,storeCode:string,channel:string,marketCode:string,cityCode:string,cityName:string,brand:string,address:string,addressType:string,coordinate_x:string,coordinate_y:string,userId:string,deliveryTimeOfMap:string,gender:string,iLinkMan:string,iRemark:string,needInvoice:string,invoiceTitle:string,payChannel:string,bookingType:boolean,openId:string,deviceId:string,orderItems:array<struct<orderItemId:string,linkId:string,sizeId:string,baseId:string,num:int,price:int,realPrice:int,type:int,couponCode:string,promotionCode:string,itemLinkIds:array<struct<linkId:string,sizeId:string,baseId:string,num:int,price:int,round:int>>>>>";
        String action_schema = "struct<transactionId:string,userCode:string,systemTime:bigint,brand:string,channel:string,page:int,action:int,items:array<struct<linkIds:string,systemIds:string,type:int>>,promotionCode:string>";
        String menu_force_schema = "struct<date:string,brand:string,storeCode:string,linkId:string,sizeId:string,baseId:string,type:int,couponCode:string,promotionCode:string,validFrom:string,validTo:string,startTime:string,endTime:string,itemLinkIds:array<struct<linkId:string,sizeId:string,baseId:string,type:int,round:int>>>";
        String  recommend_tf = "struct<extra:struct<transactionId:string,systemTime:string,brand:string,scene:string,bucketId:string,planType:string,storeCode:string,cityCode:string,marketCode:string>,list:array<struct<aLinkId:string,bLinkId:string,couponTitle:string,calligraphy:string,linkId:string,sizeId:string,baseId:string,type:string,couponCode:string,itemLinkIds:array<struct<linkId:string,sizeId:string,baseId:string,round:string,type:string>>,promotionCode:string,rank:string>>>";
        map = new HashMap();
        map.put("kafka_store_product",store_product_schema);
        map.put("kafka_order",order_schema);
        map.put("kafka_action",action_schema);
        map.put("kafka_menu_force",menu_force_schema);
        map.put("kafka_recommend_filter",recommend_tf);

        //kafka数据源
        String topic = "recommend_filter";
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers","172.27.133.19:9092" );
        properties.setProperty("group.id", "test");

        String orcSchemaStr = map.get("kafka_"+topic);
        System.out.println(new OrcSchemaAnalysis().getFlinkSchema(orcSchemaStr));
        YumChinaJsonRowDeserializationSchema deserializationSchema = new YumChinaJsonRowDeserializationSchema(topic,
                /*
                Types.ROW_NAMED(
                        new String[] { "transactionId", "userCode", "items" },//Types.POJO(ActionItem.class)
                        new TypeInformation[]{ Types.STRING, Types.STRING,Types.LIST(Types.ROW_NAMED(
                                new String[] { "linkids", "systemIds", "type" },
                                new TypeInformation[]{ Types.STRING, Types.STRING,Types.INT}
                        ))})//Types.PRIMITIVE_ARRAY(Types.BYTE)
                 */
                new OrcSchemaAnalysis().getFlinkSchema(orcSchemaStr)
        );

        FlinkKafkaConsumer010<Row> kafkaSource = new FlinkKafkaConsumer010(topic, deserializationSchema, properties);
        kafkaSource.setStartFromLatest();

        DataStream<Row> stream = env.addSource(kafkaSource);
        //stream.print();

        //stream 转 Table
        EnvironmentSettings fsSettings = EnvironmentSettings.newInstance().useOldPlanner().inStreamingMode().build();
        StreamTableEnvironment tableEnv = StreamTableEnvironment.create(env, fsSettings);
        //StreamTableEnvironment tableEnv = StreamTableEnvironment.create(env);
        //tableEnv.registerFunction("hashCode", new HashCode(10));
        // Register the function.
        //tableEnv.registerFunction("split", new Split("#"));
        tableEnv.registerFunction("recommend_filter_drill2",new Drill(map,"recommend_filter#list"));
        tableEnv.registerFunction("recommend_filter_drill3",new Drill(map,"recommend_filter#list#itemLinkIds"));
        //tableEnv.registerFunction("recommend_filter_drill",new ObjectSpread(map,"recommend_filter#extra"));

        tableEnv.registerDataStream("table1",stream);

        Table table1 = tableEnv.sqlQuery("SELECT * FROM table1");
        table1.printSchema();
        //tableEnv.sqlQuery("SELECT * FROM table1, LATERAL TABLE(recommend_filter_drill3(list)) as T(linkId,sizeId,baseId,`round`,type), LATERAL TABLE(recommend_filter_drill(extra)) as T2(transactionId,systemTime,brand,scene,bucketId,planType,storeCode,cityCode,marketCode)").printSchema();
        Table table2 = tableEnv.sqlQuery(
                //"SELECT transactionId,itemList_itmeId,itemList_itemRank,itemList_type FROM table1, LATERAL TABLE(split(linkIds)) as T(itemList_itmeId, itemList_itemRank,itemList_type)"
       //"select linkIds[0].itemLinkids[0].itemCount from table1"
               // "SELECT itemLinkIds_linkId as linkId,itemLinkIds_sizeId as sizeId,itemLinkIds_baseId as baseId,itemLinkIds_type as type,itemLinkIds_round as round FROM table1, LATERAL TABLE(menu_force_drill2(itemLinkIds)) as T(itemLinkIds_linkId,itemLinkIds_sizeId,itemLinkIds_baseId,itemLinkIds_type,itemLinkIds_round)"
                //"SELECT items_linkIds,items_systemIds,items_type FROM table1, LATERAL TABLE(action_drill2(items)) as T(items_linkIds,items_systemIds,items_type)"
                //"SELECT linkId,sizeId,baseId,num,price,round,N2_orderItemId,N2_linkId FROM table1, LATERAL TABLE(order_drill3(orderItems)) as T(linkId,sizeId,baseId,num,price,round,N2_orderItemId,N2_linkId)"//
                //"select storeCode,channel,`date` from table1"
                //"SELECT T2.transactionId,T2.scene,linkId,sizeId,baseId,`round`,type FROM table1, LATERAL TABLE(recommend_filter_drill3(list)) as T(linkId,sizeId,baseId,`round`,type), LATERAL TABLE(recommend_filter_drill(extra)) as T2(transactionId,systemTime,brand,scene,bucketId,planType,storeCode,cityCode,marketCode)"

                //"SELECT extra.transactionId,extra.systemTime,extra.brand,extra.scene,extra.bucketId,extra.planType,extra.storeCode,extra.cityCode,extra.marketCode FROM table1"
                "SELECT extra.transactionId,extra.scene,aLinkId,bLinkId,couponTitle,calligraphy,linkId,sizeId,baseId,type,couponCode,promotionCode,`rank` FROM table1, LATERAL TABLE(recommend_filter_drill2(list)) as T(aLinkId,bLinkId,couponTitle,calligraphy,linkId,sizeId,baseId,type,couponCode,itemLinkIds,promotionCode,`rank`)"
                //"SELECT extra.transactionId,extra.scene,linkId,sizeId,baseId,`round`,type FROM table1, LATERAL TABLE(recommend_filter_drill3(list)) as T(linkId,sizeId,baseId,`round`,type)"

        );

        //lateral view explode(split(order_value,',')) num as order_id
        table2.printSchema();

        DataStream streamCopy1 = tableEnv.toAppendStream(table1, Row.class);
        DataStream streamCopy2 = tableEnv.toAppendStream(table2, Row.class);
        streamCopy1.print();
        streamCopy2.print();

        //Rtidb Table sink
        //TableSchema tableSchema = table1.getSchema();
       /* RtiDBOutputFormat rtiDBOutputFormat = RtiDBOutputFormat.outputFormatBuilder()
                .setTableName("yumChine")
                .setZkEndpoint("172.27.133.116:7181")
                .setZkRootPath("/rtidb_1340")
                .setTableSchema(new String[] { "transactionId", "userCode", "couponCode" })
                .setTimeColName(null)
                .setTimeFormat(null)
                .build();
        RtiDBTableSink rtiDBTableSink = new RtiDBTableSink(rtiDBOutputFormat);
        rtiDBTableSink.configure(new String[] { "transactionId", "userCode", "couponCode" },new TypeInformation[]{Types.STRING, Types.STRING ,Types.STRING});
        tableEnv.registerTableSink("rtidbTable1",rtiDBTableSink);*/
        /*tableEnv.registerTableSink(
                "rtidbTable1",
                new String[] { "transactionId", "userCode", "couponCode" },
                new TypeInformation[]{Types.STRING, Types.STRING ,Types.STRING},
                //tableSchema.getFieldNames(),
                //tableSchema.getFieldTypes(),
                rtiDBTableSink);*/

        //bucketing Table sink
        String basePath = "hdfs://172.27.133.18:8020/tmp/sy/aie/recommendation/topic_bucket/"+topic;
        Path path = new Path(basePath);
        FileSystem fs = path.getFileSystem();
        fs.delete(path, true);
        BucketingSink<Row> hdfsSink = new BucketingSink<>(basePath);
        String bucketFormat = "yyyy-MM-dd-HH";
        hdfsSink.setBucketer(new DateTimeBucketer<>(bucketFormat, ZoneId.of("Asia/Shanghai")));
        hdfsSink.setBatchSize(1024 * 1024 * 128); //128MB
        long interval = 1000L;//60000L
        hdfsSink.setBatchRolloverInterval(interval);
//      SimpleDateFormat df = new SimpleDateFormat("-yyyy-MM-dd-HH-mm");//设置日期格式
//      sink.setPartSuffix(df.format(new Date()));//设置后缀为系统时间
        hdfsSink.setUseTruncate(false);

        //streamCopy1.addSink(hdfsSink);

        BucketingTableSink sink = new BucketingTableSink(hdfsSink,"/t");

        String bucketSchemaStr = "struct<storeCode:string,channel:string,date:string>";
        sink.configure(new FormatTools().getOrcSchemaName(bucketSchemaStr),new FormatTools().getOrcSchemaType(bucketSchemaStr));
        tableEnv.registerTableSink("bucket_table", sink);


        /*tableEnv.sqlUpdate(
                //"insert into bucket_table select transactionId,userCode,systemTime,brand,channel,page,action,promotionCode from table1 "
                "insert into bucket_table select storeCode,channel,`date` from table1"
        );*/


        try {
            env.execute("Consume again");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
