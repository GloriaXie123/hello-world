package com._4paradigm.bumblebee.runner.demon.kafka;


import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.java.StreamTableEnvironment;
import org.apache.flink.table.descriptors.*;

public class Runner {
    public static void main(String[] args) {
        // for batch programs use ExecutionEnvironment instead of StreamExecutionEnvironment
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        env.setParallelism(1);
        env.setMaxParallelism(1);
        // create a TableEnvironment
        // for batch programs use BatchTableEnvironment instead of StreamTableEnvironment
        StreamTableEnvironment tableEnv = StreamTableEnvironment.create(env);
//172.27.133.19:9092

        tableEnv.connect(
                new Kafka()
                        .version("0.11")
                        .topic("test")
                        .startFromLatest()
                        .property("bootstrap.servers", "172.27.133.19:9092")
        )
                // declare a format for this system
                .withFormat(
                        new Json()
                                .deriveSchema()
                                .failOnMissingField(false))
                // declare the schema of the table
                .withSchema(
                        new Schema()
                                .field("local_day_string", Types.STRING)
                                .field("local_time_string", Types.STRING)
                                .field("foo", Types.STRING)
                                .field("bar", Types.STRING)
                )
                // specify the update-mode for streaming tables
                .inAppendMode()
                // register as source, sink, or both and under a name
                .registerTableSource("table1");

        tableEnv.connect(
                new FileSystem()
                        .path("hdfs://172.27.133.18:8020/tmp/sy/test")//"file:///path/to/whatever"
        )
                // declare a format for this system
                .withFormat(new Csv().deriveSchema())
                // declare the schema of the table
                .withSchema(
                        new Schema()
                                .field("local_day_string", Types.STRING)
                                .field("local_time_string", Types.STRING)
                                .field("foo", Types.STRING)
                                .field("bar", Types.STRING)
                )
                // register as source, sink, or both and under a name
                .registerTableSource("table2");


        tableEnv.sqlUpdate(
                "INSERT INTO table2 " +
                        "SELECT * " +
                        "FROM table1 "
        );
        // create a Table from a SQL query
        //Table sqlResult = tableEnv.sqlQuery("SELECT * FROM table1");
        //sqlResult.printSchema();
        //DataStream stream = tableEnv.toAppendStream(sqlResult, Row.class);
        //stream.print();




        /**
         //对数据的source有格式限制，不能直接转换使用
         final File folder =new File("data");
         String schemaStr = "{" +
         "  \"namespace\": \"org.myorganization\"," +
         "  \"type\": \"record\"," +
         "  \"name\": \"UserMessage\"," +
         "    \"fields\": [" +
         "      {\"name\": \"timestamp\", \"type\": \"string\"}," +
         "      {\"name\": \"user\", \"type\": \"long\"}," +
         "      {\"name\": \"message\", \"type\": [\"string\", \"null\"]}" +
         "    ]" +
         "}";
         org.apache.avro.Schema schema = new org.apache.avro.Schema.Parser().parse(schemaStr);
         stream.addSink(
         StreamingFileSink.forBulkFormat(
         Path.fromLocalFile(folder),
         ParquetAvroWriters.forGenericRecord(schema))
         .build());
         **/
        try {
            env.execute();
        } catch (Exception e) {
            System.out.println("运行中出现问题导致任务中断");
            e.printStackTrace();
        }
    }
}
