package com._4paradigm.bumblebee.runner.demon.kafka

import org.apache.flink.streaming.api.scala.DataStream


//import com._4paradigm.bumblebee.parquet.{Stream2ParquetOutputFormat, Stream2ParquetTableSink}
import org.apache.flink.api.common.typeinfo.Types
import org.apache.flink.streaming.api.scala._
import org.apache.flink.table.api.scala._
import org.apache.flink.table.descriptors.{Json, Kafka, Schema}
import org.apache.flink.types.Row

object flinkscalaTable {

  def main(args: Array[String]): Unit = {
    val stream: DataStream[(Long, String,String,Long)] = null

    // for batch programs use ExecutionEnvironment instead of StreamExecutionEnvironment
    val env = StreamExecutionEnvironment.getExecutionEnvironment

    env.setParallelism(1)
    env.setMaxParallelism(1)
    // create a TableEnvironment
    // for batch programs use BatchTableEnvironment instead of StreamTableEnvironment
    val tableEnv = StreamTableEnvironment.create(env)

    tableEnv.connect(
      new Kafka()
        .version("0.11")
        .topic("test")
        .startFromLatest()
        .property("bootstrap.servers", "172.27.133.19:9092")
    )
      // declare a format for this system
      .withFormat(new Json().deriveSchema().failOnMissingField(false))
      // declare the schema of the table
      .withSchema(
      new Schema()
        .field("local_day_string", Types.STRING)
        .field("local_time_string", Types.STRING)
        .field("foo", Types.STRING)
        .field("bar", Types.STRING)
    )

      // specify the update-mode for streaming tables
      .inAppendMode()
      // register as source, sink, or both and under a name
      .registerTableSource("table1");
    // create a Table from a SQL query
    val table = tableEnv.sqlQuery("SELECT * FROM table1")

   /* table.printSchema()
    val stream = tableEnv.toAppendStream[Row](table)
    stream.print

    val tableSchema = table.getSchema
    val stream2ParquetOutputForma = new Stream2ParquetOutputFormat("hdfs://172.27.133.18:8020/tmp/sy",tableSchema.getFieldTypes,tableSchema.getFieldNames)
    val stream2ParquetTableSink = new Stream2ParquetTableSink(stream2ParquetOutputForma);
    stream2ParquetTableSink.configure(tableSchema.getFieldNames,tableSchema.getFieldTypes);
    table.writeToSink(stream2ParquetTableSink)*/

    //val folder = new File("")
    //val sink = StreamingFileSink.forBulkFormat(Path.fromLocalFile(folder),ParquetAvroWriters.forReflectRecord(new Datum().getClass)).build()


    //stream.addSink(sink);

    env.execute
  }
}
