package com._4paradigm.bumblebee.runner.demon;

import com._4paradigm.bumblebee.ritdb.RtidbDataSink;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.util.Collector;


import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Properties;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Kafka2RtidbStreamRuner {
    public static String KAFKA_BOOTSTRAP_SERVERS = "bootstrap.servers";
    public static String KAFKA_GROUP_ID="group.id";
    public static String KAFKA_TOPIC ="kafka.topic";

    public static String RTIDB_ZKENDPOINT="rtidb.zkEndpoint";
    public static String RTIDB_ZKROOTPATH="rtidb.zkRootPath";
    public static String RTIDB_ZKLEADERPATH="rtidb.zkLeaderPath";
    public static String RTIDB_TABLNAME="rtidb.tableName";
    public static String RTIDB_TIMECLOME="rtidb.timeClome";
    //kafka0.11版本
    private static String uuid =UUID.randomUUID().toString();
    protected static final Logger LOGGER = LoggerFactory.getLogger(Kafka2RtidbStreamRuner.class);


    public static void main(String[] args) throws Exception {
        // Checking input parameters
        final ParameterTool params = ParameterTool.fromArgs(args);
        System.out.println("Usage: Kafka2RtidbStreamRuner --bootstrap.servers <servers> --kafka.topic <topic> [--group.id <group> ]" +
                "--rtidb.zkEndpoint <endpoint> --rtidb.zkRootPath <zkrootpath> [--rtidb.zkLeaderPath <leaderpath>] --rtidb.tableName <table> [--rtidb.timeClome <timeClome>]");
        System.out.println("[] is Optional , --name <flinkRunName>");
        //--bootstrap.servers 172.27.133.19:9092 --kafka.topic test --rtidb.zkEndpoint 172.27.133.116:7181,172.27.133.117:7181,172.27.133.118:7181,172.27.133.119:7181,172.27.133.120:7181 --rtidb.zkRootPath /rtidb --rtidb.zkLeaderPath /rtidb/leader --rtidb.tableName ccca_shangyue --rtidb.timeClome D_TXN_DATETIME

        StreamExecutionEnvironment see = StreamExecutionEnvironment.getExecutionEnvironment();
        see.getConfig().setGlobalJobParameters(params);
        //启用拓扑检查点容错
        see.enableCheckpointing(6000);// checkpoint every 6000 msecs
        //see.setStateBackend(new FsStateBackend("hdfs://tmp/flink/checkpoints"));
        see.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
        see.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);

        //传递全局参数
        ParameterTool parameters = ParameterTool.fromArgs(args);
        // 创建一个执行环境
        see.getConfig().setGlobalJobParameters(parameters);

        DataStream<String> stream ;
        if (params.has(KAFKA_BOOTSTRAP_SERVERS) &&
                params.has(KAFKA_TOPIC)
        ) {
            Properties properties = new Properties();
            properties.setProperty(KAFKA_BOOTSTRAP_SERVERS,params.get(KAFKA_BOOTSTRAP_SERVERS));//*172.27.133.19:9092
            // only required for Kafka 0.8
            //properties.setProperty("zookeeper.connect", "localhost:2181")
            properties.put(KAFKA_GROUP_ID, params.get(KAFKA_BOOTSTRAP_SERVERS,uuid));//*group.id如果不设置就将从一个uuid组进行消费
            /**
             properties.put("enable.auto.commit", "true")
             properties.put("auto.offset.reset", "earliest") //latest	earliest
             properties.put("auto.commit.interval.ms", "1000")
             properties.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer")
             properties.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer")
             */

            FlinkKafkaConsumer011 kafkaconsumer = new FlinkKafkaConsumer011(params.get(KAFKA_TOPIC),new SimpleStringSchema(), properties);//"test"
            /**
             //设置kafka消费起始位置，在此模式下，上面Kafka中的已提交偏移将被忽略，不会用作起始位置。
             kafkaconsumer.setStartFromEarliest()      // start from the earliest record possible
             kafkaconsumer.setStartFromLatest()        // start from the latest record
             kafkaconsumer.setStartFromTimestamp(...)  // start from specified epoch timestamp (milliseconds)
             kafkaconsumer.setStartFromGroupOffsets()  // the default behaviour */
            kafkaconsumer.setStartFromEarliest();      // start from the earliest record possible
            /**
             //设置单独消费某个分区的起始偏移量
             val specificStartOffsets = new java.util.HashMap[KafkaTopicPartition, java.lang.Long]()
             specificStartOffsets.put(new KafkaTopicPartition("myTopic", 0), 23L)
             specificStartOffsets.put(new KafkaTopicPartition("myTopic", 1), 31L)
             specificStartOffsets.put(new KafkaTopicPartition("myTopic", 2), 43L)
             kafkaconsumer.setStartFromSpecificOffsets(specificStartOffsets)
             */

            kafkaconsumer.setCommitOffsetsOnCheckpoints(true);//提交存储在检查点状态中的偏移量,确保Kafka代理中的承诺偏移量与检查点状态中的偏移量一致
            //kafkaconsumer.assignTimestampsAndWatermarks(new CustomWatermarkEmitter())//自定义时间戳提取器/水印发射器

            stream = see.addSource(kafkaconsumer).uid("kafka-source-id");
        } else {
            System.out.println("kafka 必要参数缺省erro");
            System.out.println("Use --bootstrap.servers <servers> --kafka.topic <topic> --group.id <group>   group.id is Optional,specify the authentication info.");
            return;
        }

        DataStream<HashMap<String,Object>> doStream = stream.flatMap(new Tokenizer()).uid("transform-id1");
        //doStream.print();

        //rtidb zk point,zk path,rtidb leader path ,table name ,if hashmap table clome is time set it ,or not.
        String timeColName = "D_TXN_DATETIME";
        if (params.has(RTIDB_ZKENDPOINT) &&
                params.has(RTIDB_ZKROOTPATH) &&
                params.has(RTIDB_TABLNAME)
        ) {

            RtidbDataSink rtidbSink = new RtidbDataSink(params.get(RTIDB_ZKENDPOINT),
                    params.get(RTIDB_ZKROOTPATH),
                    params.get(RTIDB_ZKLEADERPATH,params.get(RTIDB_ZKROOTPATH)+"/leader"),
                    params.get(RTIDB_TABLNAME),
                    params.get(RTIDB_TIMECLOME,""));
            //"172.27.133.116:7181,172.27.133.117:7181,172.27.133.118:7181,172.27.133.119:7181,172.27.133.120:7181","/rtidb","/rtidb/leader","ccca_shangyue",timeColName
            doStream.addSink(rtidbSink).uid("rtidb-sink-id");

        }else {
            System.out.println("Rtidb 必要参数缺省erro");
            System.out.println("Use --rtidb.zkEndpoint <endpoint> --rtidb.zkRootPath <zkrootpath> --rtidb.zkLeaderPath <leaderpath> --rtidb.tableName <table> --rtidb.timeClome <timeClome>   rtidb.zkLeaderPath rtidb.timeClome is Optional,specify the authentication info.");
            return;
        }
        see.execute(params.get("name","kafka to Rtidb Streaming "+uuid));

    }

    private static boolean macValid(String macStr) {
        if (    macStr == null ||
                macStr.length() !=  17 ||
                macStr.charAt(2) != '-' ||
                macStr.charAt(5) != '-' ||
                macStr.charAt(8) != '-' ||
                macStr.charAt(11) != '-' ||
                macStr.charAt(14) != '-'
        ) {
            return false;
        } else {
            return true;
        }
    }

    //业务数据处理方法
    public static final class Tokenizer implements FlatMapFunction<String, HashMap<String,Object>> {
        String macColName = "C_MAC_ADDR";
        String seqColName = "C_SK_SEQ";
        String timeColName = "D_TXN_DATETIME";
        @Override
        public void flatMap(String value, Collector out) throws Exception {
            try {
                ObjectMapper mapper = new ObjectMapper();//, HashMap.class
                HashMap<String, Object> hashMap = mapper.readValue(value, HashMap.class);
                if (macValid((String) hashMap.get(macColName)) == false) {
                    hashMap.put(macColName, hashMap.get(seqColName));
                }
                String timeStr = String.valueOf(hashMap.get(timeColName));
                long ts = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss.SSS").parse(timeStr).getTime();
                hashMap.put(timeColName, String.valueOf(ts));//**这里rtidb不支持long类型的数据，所以要存为string，不然会持续不报错重试。
                out.collect(hashMap);
            }catch (Exception e){
                LOGGER.error("数据json解析化处理失败 :"+value);
                System.out.println("数据json解析化处理失败 :"+value);
                e.printStackTrace();
            }

        }
    }
}
