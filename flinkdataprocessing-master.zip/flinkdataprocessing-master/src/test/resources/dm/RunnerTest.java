package dm;

import com._4paradigm.bumblebee.runner.BatchAndStreamRunner;
import com.alibaba.fastjson.JSON;
import org.apache.orc.TypeDescription;
import org.junit.Test;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class RunnerTest {

    //@Test
    public void testSchema()  {
        String schemaValue =
                //"struct<C_MAC_ADDR:string,C_CUSTOMER_ID:string,C_MERCH_ID:string,C_CARD_NO:string,C_ACCT_ZONE:string,N_TRXCODE:string,C_DAILY_OPENBUY:string,C_INDI_OPENBUY:string,N_PHONE_NO:string,N_BOUND_PHONE_NO:string,C_ACCT_NO:string,D_TXN_DATETIME:string,N_TXN_AMT:string,C_TXN_CURR:string,C_PAY_NAME:string,C_PAYEE_ACCT:string,C_PAYEE_NAME:string,C_SK_SEQ:string,C_TXN_IP:string,C_BALANCE:string,C_ACCT_TYPE:string,C_TXN_TYPE:string,C_TXN_CHANNEL:string,C_PAYEE_BANK_NAME:string,C_SERIAL_NO:string,D_REGISTER_DATETIME:string,C_PAYEE_ACCT_ZONE:string,C_COMMONLY_PAYEE_FLAG:string,C_TRUST_PAYEE_FLAG:string,C_MEDIUM_NO:string,C_TRUST_CLIENT_FLAG:string,C_VERIFY_TYPE:string,C_PAYEE_CUSTOMER_ID:string,C_CPU_ID:string,C_MEMORY_CAPACITY:string,C_SYSTEM_VERSION:string,C_BROWSER_VERSION:string,C_BROWSER_LANG:string,C_SCREEN_RESOLUTION:string,C_APP_VERSION:string,C_FACTORY_INFO:string>";
                //"struct<C_MAC_ADDR:string,C_CUSTOMER_ID:string,C_MERCH_ID:string,C_CARD_NO:string,C_ACCT_ZONE:string,N_TRXCODE:string,C_DAILY_OPENBUY:string,C_INDI_OPENBUY:string,N_PHONE_NO:string,N_BOUND_PHONE_NO:string,C_ACCT_NO:string,D_TXN_DATETIME:string,N_TXN_AMT:string,C_TXN_CURR:string,C_PAY_NAME:string,C_PAYEE_ACCT:string,C_PAYEE_NAME:string,C_SK_SEQ:string,C_TXN_IP:string,C_BALANCE:string,C_ACCT_TYPE:string,C_TXN_TYPE:string,C_TXN_CHANNEL:string,C_PAYEE_BANK_NAME:string,C_SERIAL_NO:string,D_REGISTER_DATETIME:string,C_PAYEE_ACCT_ZONE:string,C_COMMONLY_PAYEE_FLAG:string,C_TRUST_PAYEE_FLAG:string,C_MEDIUM_NO:string,C_TRUST_CLIENT_FLAG:string>";
                "struct<o_age_bin:int,ocus_invalid_acct_cert_actl_result:string,i_adays_bin:int,icus_invalid_acct_cert_actl_result:string,c_app_version:string,ocus_cert_provi_situ_type_cd:string,c_txn_unit_price:string,c3_outareacode2_inareacode2_amt_bin:string,ocus_icbc_emply_ind:string,c_indi_openbuy:double,c3_o_city_i_city_city:string,ocus_birth_dt:string,o_lola_1:double,o_lola_2:double,i_city:string,c_payee_customer_id:string,c_hour:int,c_verify_type:string,o_adays:bigint,ip_pre_bin1:string,ip_pre_bin2:string,c_txn_puduct_type:string,icus_birth_dt:string,outcustnum:string,i_odays:bigint,ocus_asset_month_accum:string,c_acct_type:string,c_memory_capacity:double,c3_outareacode2_inareacode2_c_hour:string,c3_o_prov_o_adays_bin_i_adays_bin:string,o_adays_bin:int,icus_marriage_status_cd:string,ocus_proper_career_cd:string,c_txn_ip:string,icus_disp_situ_type_cd:string,usercerttype:int,flag:string,c2_outareacode2_inareacode2:string,ocus_career_cd:string,city:string,n_phone_no:string,icus_career_cd:string,c_trust_payee_flag:string,c_browser_version:string,n_trxcode:string,c_payee_bank_name:string,icus_dom_resdnt_ind:string,icus_adj_situ_type_cd:string,o_odays:bigint,c_acct_no:string,c2_czoneconde_outareacode2:string,c3_outareacode2_inareacode2_czoneconde:string,c_system_version:string,ocus_start_dt:string,c_factory_info:string,icus_integrality_check_result:string,c_merch_id:string,prov:string,c3_o_prov_i_prov_prov:string,ocus_career_status_cd:string,c_day:int,c_acct_zone:string,ocus_integrality_ind_cd:string,inareacode2:string,c2_czoneconde_inareacode2:string,bilabel:string,c_commonly_payee_flag:string,icus_start_dt:string,icus_proper_industry_cd:string,o_age:int,c_trx_direction_flag:string,is_tx_z:int,icus_birth_cty_cd:string,c_pay_name:string,ocus_vip_cust_ind:string,ocus_belong_corp_type_cd:string,lola_1:double,ocus_pri_econ_src_cd:string,lola_2:double,c3_o_prov_i_prov_amt_bin:string,c2_prov_o_prov:string,i_country:string,d_txn_datetime:string,ocus_ethnic_cd:string,c_mac_addr:string,logtime:string,c_card_no:string,ocus_integrality_check_result:string,country:string,icus_pri_econ_src_cd:string,ocus_disp_situ_type_cd:string,incustnum:string,out_card_pre_bin1:string,c_medium_no:string,out_card_pre_bin2:string,is_tx_abn:int,c3_o_city_o_adays_bin_i_adays_bin:string,c_sk_seq:string,icus_ethnic_cd:string,ocus_proper_industry_cd:string,c2_city_i_city:string,c2_prov_i_prov:string,icus_icbc_emply_ind:string,ocus_edu_degree_cd:string,c_payee_acct_zone:string,ts0:bigint,icus_vip_cust_ind:string,c_serial_no:string,o_country:string,c3_o_city_o_age_bin_i_age_bin:string,ocus_birth_cty_cd:string,logdate:string,inaccttype:int,c_txn_curr:string,lat:double,is_intran:string,oi_country:string,c2_o_city_i_city:string,c2_o_adays_bin_i_adays_bin:string,c2_o_prov_i_prov:string,c3_o_city_i_city_amt_bin:string,icus_belong_corp_type_cd:string,ocus_gender_cd:string,incardopendate:string,i_age_bin:int,c_txn_type:string,icus_integrality_ind_cd:string,icus_cust_sell_status_cd:string,long_0:double,c_customer_id:string,outaccttype:int,c_cpu_id:string,czoneconde:string,oi_prov:string,in_card_pre_bin2:string,ocus_identity_actl_result_type_cd:string,icus_edu_degree_cd:string,ocus_adj_situ_type_cd:string,in_card_pre_bin1:string,d_register_datetime:string,icus_identity_actl_result_type_cd:string,n_bound_phone_no:string,outcardopendate:string,c3_o_city_i_city_c_hour:string,icus_cert_provi_situ_type_cd:string,c_balance:double,i_odays_bin:int,d_txn_time:string,c_payee_name:string,c_browser_lang:string,ocus_dom_resdnt_ind:string,oi_city:string,icus_proper_career_cd:string,c_trust_client_flag:string,amt_bin:int,i_age:int,icus_gender_cd:string,o_prov:string,outareacode2:string,i_prov:string,i_lola_2:double,i_lola_1:double,c2_o_age_bin_i_age_bin:string,c_register_flag:string,ocus_marriage_status_cd:string,n_txn_amt:double,o_city:string,label:string,c_txn_count:string,c_dow:int,i_adays:bigint,incardno:string,icus_asset_month_accum:string,c2_city_o_city:string,mac_pre_bin2:string,c2_outaccttype_inaccttype:string,mac_pre_bin1:string,d_txn_date:string,c_daily_openbuy:double,c_tradflag:string,c_screen_resolution:string,o_odays_bin:int,d_txn_time_std:bigint,c_txn_channel:string,icus_career_status_cd:string,c3_o_prov_i_prov_c_hour:string,c3_o_prov_o_age_bin_i_age_bin:string,ocus_cust_sell_status_cd:string>";
        System.out.println(TypeDescription.fromString(schemaValue).getFieldNames());
        System.out.println(TypeDescription.fromString(schemaValue).getChildren());
    }


    //@Test
    public void testDate() {
        Date date = new Date();
        System.out.println(date.getTime());

        System.out.println(System.currentTimeMillis());

        SimpleDateFormat sdf  = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String current = sdf.format(System.currentTimeMillis());
        System.out.println(current);

        try{
            //1、日期转字符串
            Calendar calendar = Calendar.getInstance();
            Date date1 = calendar.getTime();
            String dateStringParse = sdf.format(date1);
            System.out.println(dateStringParse);
            //2、字符串转日期
            String dateString = "2017-12-20 14:02:08";
            Date dateParse = sdf.parse(dateString);
            System.out.println(dateParse);
        } catch (ParseException e){
            e.printStackTrace();
        }
    }


    //@Test
    public void testURL() throws UnsupportedEncodingException {
        /*String Str1 = "[{\"type\":\"kafka\",\"version\":\"0.11\",\"bootstrap.servers\":\"172.27.133.19:9092\",\"zookeeper.connect\":\"172.27.133.19:2181/kafka\",\"topic\":\"test\",\"groupId\":\"test\",\"startFrom\":\"earliest\",\"offSetsJson\":\"\",\"format\":\"json\",\"schema\":\"struct<C_MAC_ADDR:string,C_CUSTOMER_ID:string>\",\"tableName\":\"table1\"}]";
        String Str2 = "[{\"type\":\"rtidb\",\"zkEndpoint\":\"172.27.133.116:7181\",\"zkRootPath\":\"/rtidb_1340\",\"tableName\":\"test\"}]";
        String Str3 = "{\"transType\":\"stream\",\"sql\":\"select C_MAC_ADDR as string1,C_CUSTOMER_ID as string2 from table1\"}";
        System.out.println(URLEncoder.encode(Str1,"UTF-8"));
        System.out.println(URLEncoder.encode(Str2,"UTF-8"));
        System.out.println(URLEncoder.encode(Str3,"UTF-8"));*/

        String str = "{\"name\":\"fake name\",\"parallelism\":5,\"jobType\":\"stream\",\"checkPointPath\":null,\"sourceType\":\"kafka\",\"sourceProperties\":{\"version\":\"0.11\",\"zookeeper.connect\":\"172.27.133.19:2181/kafka\",\"bootstrap.servers\":\"172.27.133.19:9092\",\"topic\":\"test\",\"groupId\":\"test\",\"consumeMethod\":\"latest\",\"offSetsJson\":null,\"format\":\"json\",\"schema\":\"struct<C_MAC_ADDR:string,C_CUSTOMER_ID:string>\",\"tableName\":\"table1\"},\"operation\":{\"sql\":\"select C_MAC_ADDR as string1,C_CUSTOMER_ID as string2 from table1\",\"windowType\":\"Time-based\",\"windowSize\":\"\",\"windowSlide\":\"\"},\"sinkType\":\"rtidb\",\"sinkProperties\":{\"zkEndpoint\":\"172.27.133.116:7181\",\"zkRootPath\":\"/rtidb_1340\",\"tableName\":\"test\",\"timeColumn\":\"\",\"timeColumnFormat\":\"\"}}";
        String eesc_zz = "{\"name\":null,\"parallelism\":3,\"jobType\":\"stream\",\"checkPointPath\":null,\"sourceType\":\"kafka\",\"sourceProperties\":{\"version\":\"0.11\",\"zookeeper.connect\":null,\"bootstrap.servers\":\"172.27.133.19:9092\",\"topic\":\"trans_session_topic\",\"groupId\":\"test\",\"consumeMethod\":\"earliest\",\"offSetsJson\":null,\"format\":\"json\",\"schema\":\"struct<o_age_bin:int,ocus_invalid_acct_cert_actl_result:string,i_adays_bin:int,icus_invalid_acct_cert_actl_result:string,c_app_version:string,ocus_cert_provi_situ_type_cd:string,c_txn_unit_price:string,c3_outareacode2_inareacode2_amt_bin:string,ocus_icbc_emply_ind:string,c_indi_openbuy:double,c3_o_city_i_city_city:string,ocus_birth_dt:string,o_lola_1:double,o_lola_2:double,i_city:string,c_payee_customer_id:string,c_hour:int,c_verify_type:string,o_adays:bigint,ip_pre_bin1:string,ip_pre_bin2:string,c_txn_puduct_type:string,icus_birth_dt:string,outcustnum:string,i_odays:bigint,ocus_asset_month_accum:string,c_acct_type:string,c_memory_capacity:double,c3_outareacode2_inareacode2_c_hour:string,c3_o_prov_o_adays_bin_i_adays_bin:string,o_adays_bin:int,icus_marriage_status_cd:string,ocus_proper_career_cd:string,c_txn_ip:string,icus_disp_situ_type_cd:string,usercerttype:int,flag:string,c2_outareacode2_inareacode2:string,ocus_career_cd:string,city:string,n_phone_no:string,icus_career_cd:string,c_trust_payee_flag:string,c_browser_version:string,n_trxcode:string,c_payee_bank_name:string,icus_dom_resdnt_ind:string,icus_adj_situ_type_cd:string,o_odays:bigint,c_acct_no:string,c2_czoneconde_outareacode2:string,c3_outareacode2_inareacode2_czoneconde:string,c_system_version:string,ocus_start_dt:string,c_factory_info:string,icus_integrality_check_result:string,c_merch_id:string,prov:string,c3_o_prov_i_prov_prov:string,ocus_career_status_cd:string,c_day:int,c_acct_zone:string,ocus_integrality_ind_cd:string,inareacode2:string,c2_czoneconde_inareacode2:string,bilabel:string,c_commonly_payee_flag:string,icus_start_dt:string,icus_proper_industry_cd:string,o_age:int,c_trx_direction_flag:string,is_tx_z:int,icus_birth_cty_cd:string,c_pay_name:string,ocus_vip_cust_ind:string,ocus_belong_corp_type_cd:string,lola_1:double,ocus_pri_econ_src_cd:string,lola_2:double,c3_o_prov_i_prov_amt_bin:string,c2_prov_o_prov:string,i_country:string,d_txn_datetime:string,ocus_ethnic_cd:string,c_mac_addr:string,logtime:string,c_card_no:string,ocus_integrality_check_result:string,country:string,icus_pri_econ_src_cd:string,ocus_disp_situ_type_cd:string,incustnum:string,out_card_pre_bin1:string,c_medium_no:string,out_card_pre_bin2:string,is_tx_abn:int,c3_o_city_o_adays_bin_i_adays_bin:string,c_sk_seq:string,icus_ethnic_cd:string,ocus_proper_industry_cd:string,c2_city_i_city:string,c2_prov_i_prov:string,icus_icbc_emply_ind:string,ocus_edu_degree_cd:string,c_payee_acct_zone:string,ts0:bigint,icus_vip_cust_ind:string,c_serial_no:string,o_country:string,c3_o_city_o_age_bin_i_age_bin:string,ocus_birth_cty_cd:string,logdate:string,inaccttype:int,c_txn_curr:string,lat:double,is_intran:string,oi_country:string,c2_o_city_i_city:string,c2_o_adays_bin_i_adays_bin:string,c2_o_prov_i_prov:string,c3_o_city_i_city_amt_bin:string,icus_belong_corp_type_cd:string,ocus_gender_cd:string,incardopendate:string,i_age_bin:int,c_txn_type:string,icus_integrality_ind_cd:string,icus_cust_sell_status_cd:string,long_0:double,c_customer_id:string,outaccttype:int,c_cpu_id:string,czoneconde:string,oi_prov:string,in_card_pre_bin2:string,ocus_identity_actl_result_type_cd:string,icus_edu_degree_cd:string,ocus_adj_situ_type_cd:string,in_card_pre_bin1:string,d_register_datetime:string,icus_identity_actl_result_type_cd:string,n_bound_phone_no:string,outcardopendate:string,c3_o_city_i_city_c_hour:string,icus_cert_provi_situ_type_cd:string,c_balance:double,i_odays_bin:int,d_txn_time:string,c_payee_name:string,c_browser_lang:string,ocus_dom_resdnt_ind:string,oi_city:string,icus_proper_career_cd:string,c_trust_client_flag:string,amt_bin:int,i_age:int,icus_gender_cd:string,o_prov:string,outareacode2:string,i_prov:string,i_lola_2:double,i_lola_1:double,c2_o_age_bin_i_age_bin:string,c_register_flag:string,ocus_marriage_status_cd:string,n_txn_amt:double,o_city:string,label:string,c_txn_count:string,c_dow:int,i_adays:bigint,incardno:string,icus_asset_month_accum:string,c2_city_o_city:string,mac_pre_bin2:string,c2_outaccttype_inaccttype:string,mac_pre_bin1:string,d_txn_date:string,c_daily_openbuy:double,c_tradflag:string,c_screen_resolution:string,o_odays_bin:int,d_txn_time_std:bigint,c_txn_channel:string,icus_career_status_cd:string,c3_o_prov_i_prov_c_hour:string,c3_o_prov_o_age_bin_i_age_bin:string,ocus_cust_sell_status_cd:string>\",\"tableName\":\"table1\"},\"operation\":{\"sql\":\"select * from table1\",\"windowType\":\"\",\"windowSize\":\"\",\"windowSlide\":\"\"},\"sinkType\":\"rtidb\",\"sinkProperties\":{\"zkEndpoint\":\"172.27.133.116:7181\",\"zkRootPath\":\"/rtidb_140\",\"tableName\":\"session_table_preprocess\",\"timeColumn\":\"\",\"timeColumnFormat\":\"\"}}";
        System.out.println(URLEncoder.encode(eesc_zz,"UTF-8"));

        //--source.description  --sink.description --trans.description
        /*String Str4 = "%5B%7B%22type%22%3A%22kafka%22%2C%22bootstrapServers%22%3A%22172.27.133.19%3A9092%22%2C%22topic%22%3A%22test%22%2C%22groupId%22%3A%22test%22%2C%22zookeeperConnect%22%3Anull%2C%22version%22%3A%220.11%22%7D%5D";
        String Str5 = "%5B%7B%22type%22%3A%22rtidb%22%2C%22zkEndpoint%22%3A%22172.27.133.116%3A7181%2C172.27.133.117%3A7181%2C172.27.133.118%3A7181%2C172.27.133.119%3A7181%2C172.27.133.120%3A7181%22%2C%22zkRootPath%22%3A%22%2Frtidb_1340%22%2C%22zkLeaderPath%22%3Anull%2C%22tableName%22%3A%22ccca_shangyue%22%2C%22timeColumn%22%3A%22D_TXN_DATETIME%22%7D%5D";
        String Str6 = "%7B%22trans.type%22%3A%22stream%22%7D";
        System.out.println(URLDecoder.decode(Str4,"UTF-8"));
        System.out.println(URLDecoder.decode(Str5,"UTF-8"));
        System.out.println(URLDecoder.decode(Str6,"UTF-8"));*/
    }

    public static String kafkaArgs = null;
    public static String HiveArgs = null;
    public static String OrcArgs = null;
    public static String FileSystemArgs = null;

    @Test
    public void testArgs() throws UnsupportedEncodingException {
        //kafka
        Map<String, Object> kafkamap = new HashMap<String, Object>() {
            {
                put("version", "0.11");
                put("zookeeper.connect", null);
                put("bootstrap.servers", "172.27.133.19:9092");
                put("topic", "test");
                put("groupId", "test");
                put("consumeMethod", "latest");
                put("offSetsJson", null);
                put("format", "json");
                //put("failOnMissingField", false);
                put("schema", "struct<local_day_string:string,local_time_string:string,foo:string,bar:string>");
                put("tableName", "table1");
            }
        };

        Map<String, Object> kafkasqlmap = new HashMap<String, Object>() {
            {
                put("sql", "select *,UNIX_TIMESTAMP(SUBSTR(CONCAT(local_day_string,local_time_string,'0'),0,17),'yyyyMMddHHmmssSSS') as ts from table1");
            }
        };

        Map<String, Object> kafka2rtidbmap = new HashMap<String, Object>() {
            {
                put("zkEndpoint", "172.27.133.116:7181");
                put("zkRootPath", "/rtidb_1340");
                put("tableName", "timetest");
                put("timeColumn", "ts");
                put("timeColumnFormat", "");
            }
        };

        Map<String, Object> kafkasource = new HashMap<String, Object>() {
            {
                put("name", "shangyue_201906031208");
                put("parallelism", 5);
                put("jobType", "stream");
                put("checkPointPath", null);
                put("sourceType", "kafka");
                put("sourceProperties",kafkamap);
                put("operation", kafkasqlmap);
                put("sinkType", "rtidb");
                put("sinkProperties", kafka2rtidbmap);
            }
        };
//%7B%22sourceProperties%22%3A%7B%22schema%22%3A%22struct%3CC_MAC_ADDR%3Astring%2CC_CUSTOMER_ID%3Astring%3E%22%2C%22consumeMethod%22%3A%22latest%22%2C%22groupId%22%3A%22test%22%2C%22format%22%3A%22json%22%2C%22bootstrap.servers%22%3A%22172.27.133.19%3A9092%22%2C%22topic%22%3A%22test%22%2C%22version%22%3A%220.11%22%2C%22tableName%22%3A%22table1%22%7D%2C%22sourceType%22%3A%22kafka%22%2C%22parallelism%22%3A5%2C%22name%22%3A%22shangyue_201906031208%22%2C%22sinkType%22%3A%22rtidb%22%2C%22jobType%22%3A%22stream%22%2C%22sinkProperties%22%3A%7B%22timeColumn%22%3A%22%22%2C%22zkRootPath%22%3A%22%2Frtidb_1340%22%2C%22zkEndpoint%22%3A%22172.27.133.116%3A7181%22%2C%22timeColumnFormat%22%3A%22%22%2C%22tableName%22%3A%22test%22%7D%2C%22operation%22%3A%7B%22sql%22%3A%22select+C_MAC_ADDR+as+string1%2CC_CUSTOMER_ID+as+string2+from+table1%22%7D%7D

        //Orc
        Map<String, Object> orcmap = new HashMap<String, Object>() {
            {
                put("hdfsPath", "hdfs://hacluster/tmp/test-data-flat.orc");
                put("schema", "struct<_col1:string,_col2:string>");
                put("tableName", "OrcTable");
            }
        };

        Map<String, Object> orcsqlmap = new HashMap<String, Object>() {
            {
                put("sql", "select _col1 as string1,_col2 as string2 from OrcTable limit 10");
            }
        };

        Map<String, Object> orc2rtidbmap = new HashMap<String, Object>() {
            {
                put("zkEndpoint", "172.27.133.116:7181");
                put("zkRootPath", "/rtidb_1340");
                put("tableName", "test");
                put("timeColumn", "");
                put("timeColumnFormat", "");
            }
        };

        Map<String, Object> orcsource = new HashMap<String, Object>() {
            {
                put("name", "shangyue_201906031208");
                put("parallelism", 5);
                put("jobType", "batch");
                put("checkPointPath", null);
                put("sourceType", "orc");
                put("sourceProperties",orcmap);
                put("operation", orcsqlmap);
                put("sinkType", "rtidb");
                put("sinkProperties", orc2rtidbmap);
            }
        };
//%7B%22sourceProperties%22%3A%7B%22schema%22%3A%22struct%3C_col1%3Astring%2C_col2%3Astring%3E%22%2C%22hdfsPath%22%3A%22hdfs%3A%2F%2Fhacluster%2Ftmp%2Ftest-data-flat.orc%22%2C%22tableName%22%3A%22OrcTable%22%7D%2C%22sourceType%22%3A%22orc%22%2C%22parallelism%22%3A5%2C%22name%22%3A%22shangyue_201906031208%22%2C%22sinkType%22%3A%22rtidb%22%2C%22jobType%22%3A%22batch%22%2C%22sinkProperties%22%3A%7B%22timeColumn%22%3A%22%22%2C%22zkRootPath%22%3A%22%2Frtidb_1340%22%2C%22zkEndpoint%22%3A%22172.27.133.116%3A7181%22%2C%22timeColumnFormat%22%3A%22%22%2C%22tableName%22%3A%22test%22%7D%2C%22operation%22%3A%7B%22sql%22%3A%22select+_col1+as+string1%2C_col2+as+string2+from+OrcTable+limit+10%22%7D%7D

        //hive
        Map<String, Object> hivemap = new HashMap<String, Object>() {
            {
                put("hiveMetastoreURI", "thrift://172.27.128.141:21088");
                put("database", "default");
            }
        };

        Map<String, Object> hivesqlmap = new HashMap<String, Object>() {
            {
                put("sql", "select * from student limit 10");
            }
        };

        Map<String, Object> hive2rtidbmap = new HashMap<String, Object>() {
            {
                put("zkEndpoint", "172.27.133.116:7181");
                put("zkRootPath", "/rtidb_1340");
                put("tableName", "student");
                put("timeColumn", "");
                put("timeColumnFormat", "");
            }
        };

        Map<String, Object> hivesource = new HashMap<String, Object>() {
            {
                put("name", "shangyue_201906031208");
                put("parallelism", 5);
                put("jobType", "batch");
                put("checkPointPath", null);
                put("sourceType", "hive");
                put("sourceProperties",hivemap);
                put("operation", hivesqlmap);
                put("sinkType", "rtidb");
                put("sinkProperties", hive2rtidbmap);
            }
        };
//%7B%22sourceProperties%22%3A%7B%22database%22%3A%22default%22%2C%22hiveMetastoreURI%22%3A%22thrift%3A%2F%2F172.27.128.141%3A21088%22%7D%2C%22sourceType%22%3A%22hive%22%2C%22parallelism%22%3A5%2C%22name%22%3A%22shangyue_201906031208%22%2C%22sinkType%22%3A%22rtidb%22%2C%22jobType%22%3A%22batch%22%2C%22sinkProperties%22%3A%7B%22timeColumn%22%3A%22%22%2C%22zkRootPath%22%3A%22%2Frtidb_1340%22%2C%22zkEndpoint%22%3A%22172.27.133.116%3A7181%22%2C%22timeColumnFormat%22%3A%22%22%2C%22tableName%22%3A%22student%22%7D%2C%22operation%22%3A%7B%22sql%22%3A%22select+*+from+student+limit+10%22%7D%7D

        //fileSystem
        Map<String, Object> fileSystemmap = new HashMap<String, Object>() {
            {
                put("path",
//                        "file:///Users/shangyue/OneDrive/git/IDEA/4paradigm/flinkjobrunner/src/test/resources/data/test.csv"
                                "hdfs://hacluster/tmp/test.csv"
                );
                put("format", "csv");
                put("fieldDelimiter", ",");
                put("lineDelimiter", "\n");
                put("quoteCharacter", null);
                put("commentPrefix", null);
                put("ignoreFirstLine", true);
                put("ignoreParseErrors", false);
                put("schema", "struct<name:string,age:int,gender:string>");
                put("tableName", "sm_user");
            }
        };
        Map<String, Object> fileSystemsqlmap = new HashMap<String, Object>() {
            {
                put("sql", "select name as string1 from sm_user");
            }
        };
        Map<String, Object> fileSystem2rtidbmap = new HashMap<String, Object>() {
            {
                put("zkEndpoint", "172.27.133.116:7181");
                put("zkRootPath", "/rtidb_1340");
                put("tableName", "test");
                put("timeColumn", "");
                put("timeColumnFormat", "");
            }
        };
        Map<String, Object> fileSystemsource = new HashMap<String, Object>() {
            {
                put("name", "shangyue_201906031208");
                put("parallelism", 5);
                put("jobType", "batch");
                put("checkPointPath", null);
                put("sourceType", "FileSystem");
                put("sourceProperties",fileSystemmap);
                put("operation", fileSystemsqlmap);
                put("sinkType", "rtidb");
                put("sinkProperties", fileSystem2rtidbmap);
            }
        };


        System.out.println(JSON.toJSONString(kafkasource));
        System.out.println(JSON.toJSONString(orcsource));
        System.out.println(JSON.toJSONString(hivesource));
        System.out.println(JSON.toJSONString(fileSystemsource));

        kafkaArgs=URLEncoder.encode(JSON.toJSONString(kafkasource), "UTF-8");
        HiveArgs = URLEncoder.encode(JSON.toJSONString(hivesource), "UTF-8");
        OrcArgs = URLEncoder.encode(JSON.toJSONString(orcsource), "UTF-8");
        FileSystemArgs = URLEncoder.encode(JSON.toJSONString(fileSystemsource), "UTF-8");

        System.out.println(kafkaArgs);
        System.out.println(HiveArgs);
        System.out.println(OrcArgs);
        System.out.println(FileSystemArgs);

    }

    //@Test
    public void testSysystem (){
        String property =System.getProperty("user.dir");
        System.out.println(property);
        java.net.URL uri = this.getClass().getResource("/");
        System.out.println(uri);
        System.out.println(this.getClass().getResource("/").getPath());
    }

    //hosts 必须要配置
    @Test
    public void testKafkaRunner() throws Exception {
        //krb5认证
        //Hive2RtiDBRunnerTest.init();
        //System.setProperty("HADOOP_CONF_DIR", "/Users/shangyue/OneDrive/git/IDEA/4paradigm/flinkjobrunner/src/test/resources/bak/");

        testArgs();
        String[] arg = {kafkaArgs};
        BatchAndStreamRunner.run(arg);
    }

    @Test
    public void testHiveRunner() throws Exception {
        //krb5认证
        //Hive2RtiDBRunnerTest.init();
        //System.setProperty("HADOOP_CONF_DIR", "/Users/shangyue/OneDrive/git/IDEA/4paradigm/flinkjobrunner/src/test/resources/bak/");

        testArgs();
        String[] arg = {HiveArgs};
        BatchAndStreamRunner.run(arg);
    }

    // Caused by: java.net.UnknownHostException: hacluster  //TODO 本地调试未解决

    @Test
    public void testOrcRunner() throws Exception {
        //krb5认证
        //Hive2RtiDBRunnerTest.init();
        //System.setProperty("HADOOP_CONF_DIR", Hive2RtiDBRunnerTest.class.getResource("/").getPath()+"bak/");

        testArgs();
        String[] arg = {OrcArgs};
        BatchAndStreamRunner.run(arg);
    }

    @Test
    public void testFileSystemRunner() throws Exception {
        //krb5认证
        //Hive2RtiDBRunnerTest.init();
        //System.setProperty("HADOOP_CONF_DIR", Hive2RtiDBRunnerTest.class.getResource("/").getPath()+"bak/");

        testArgs();
        String[] arg = {FileSystemArgs};
        BatchAndStreamRunner.run(arg);
    }

}

