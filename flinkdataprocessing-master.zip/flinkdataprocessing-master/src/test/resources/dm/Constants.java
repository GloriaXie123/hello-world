package dm;

/**
 * @author akis on 2019-04-23
 */
public class Constants {
    public static final String JOB_NAME = "job.name";
    public static final String PARALLELISM = "parallelism";
    public static final String SOURCE_HIVE_METASTORE_URI = "source.hiveMetastoreURI";
    public static final String SOURCE_DATABASE = "source.database";
    public static final String OPERATION_SQL = "operation.sql";
    public static final String SINK_ZK_ENDPOINTS = "sink.zkEndpoints";
    public static final String SINK_ZK_ROOT_PATH = "sink.zkRootPath";
    public static final String SINK_RTIDB_TABLE = "sink.rtidbTable";
}
