package com._4paradigm.bumblebee.runner.demon;

import com._4paradigm.bumblebee.ritdb.RtiDBOutputFormat;
import com._4paradigm.bumblebee.ritdb.RtiDBTableSink;
import com._4paradigm.bumblebee.runner.Hive2RtiDBRunnerTest;
import org.apache.flink.orc.OrcTableSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.TableEnvironment;
import org.apache.flink.table.api.TableSchema;
import org.apache.flink.table.api.java.BatchTableEnvironment;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.orc.OrcFile;
import org.apache.orc.Reader;

import java.io.IOException;
import java.util.UUID;

public class FlinkTableOrc {

    private static final String TEST_FILE_FLAT =
             //"file:///Users/shangyue/OneDrive/git/IDEA/4paradigm/orc-flink-runner/src/main/resources/test-data-flat.orc";
            ///"hdfs://172.27.133.18:8020/tmp/test-data-flat.orc"
            "hdfs://hacluster/tmp/test-data-flat.orc";
    //schme 去匹配列,且sql中必须用到所有的schme列
    private static final String TEST_SCHEMA_FLAT = "struct<_col1:string,_col2:string>";//,_col3:string,_col4:int,_col5:string,_col6:int,_col7:int,_col8:int

    public static void main(String[] args) throws Exception {

        Hive2RtiDBRunnerTest.init();//krb5认证

        //Table 直接读 Orc  hadoop-client    resources中放配置文件 才能正确读到hdfs文件
        Configuration conf = new Configuration();
        Reader reader = null;
        try {
            reader = OrcFile.createReader(new Path(TEST_FILE_FLAT),
                    OrcFile.readerOptions(conf));
        } catch (IOException e) {
            e.printStackTrace();
        }
        String schema = reader.getSchema().toString();
        System.out.println(schema);

        StreamExecutionEnvironment sEnv = StreamExecutionEnvironment.getExecutionEnvironment();
        sEnv.setJobType(StreamExecutionEnvironment.JobType.BATCH);
        BatchTableEnvironment tEnv = TableEnvironment.getBatchTableEnvironment(sEnv);
        OrcTableSource orc = OrcTableSource.builder()
                .path(TEST_FILE_FLAT, true)
                .forOrcSchema(TEST_SCHEMA_FLAT)// schema
                .build();
        tEnv.registerTableSource("OrcTable", orc);

        String query =
                "SELECT _col1 as string1,_col2 as string2 FROM OrcTable limit 10";
        Table table = tEnv.sqlQuery(query);
        table.printSchema();
        table.print();

        TableSchema tableSchema = table.getSchema();

        RtiDBOutputFormat rtiDBOutputFormat = RtiDBOutputFormat.outputFormatBuilder()
                .setTableName("shangyuetest2")
                .setZkEndpoint("172.27.133.116:7181")
                .setZkRootPath("/rtidb_1340")
                .setTableSchema(tableSchema.getFieldNames())
                .build();

        RtiDBTableSink rtiDBTableSink = new RtiDBTableSink(rtiDBOutputFormat);
        rtiDBTableSink.configure(tableSchema.getFieldNames(), tableSchema.getFieldTypes());
        table.writeToSink(rtiDBTableSink);

        String name = "ORCRtidbRunner_" + UUID.randomUUID().toString();

        tEnv.execute(name);

    }
}
