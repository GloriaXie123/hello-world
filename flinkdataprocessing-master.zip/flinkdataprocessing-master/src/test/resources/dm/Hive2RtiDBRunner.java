package com._4paradigm.bumblebee.runner;
/**
import com._4paradigm.bumblebee.ritdb.RtiDBOutputFormat;
import com._4paradigm.bumblebee.ritdb.RtiDBTableSink;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment.JobType;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.TableEnvironment;
import org.apache.flink.table.api.TableSchema;
import org.apache.flink.table.api.java.BatchTableEnvironment;
import org.apache.flink.table.catalog.hive.HiveCatalog;


 * @author akis on 2019-04-23

@Slf4j
public class Hive2RtiDBRunner {
    private static final String CATALOG = "bumblebee";

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            log.info("please input args");
            throw new RuntimeException("please input args");
        }

        String encoded = args[0];
        String mapJson = URLDecoder.decode(encoded, "UTF-8");
        Map<String, String> params = JSON.parseObject(mapJson,
                new TypeReference<HashMap<String, String>>(){});
        log.info("input params is: {}", params);
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        if (StringUtils.isNotEmpty(params.get(Constants.PARALLELISM))) {
            env.setParallelism(Integer.parseInt(params.get(Constants.PARALLELISM)));
        }
        BatchTableEnvironment tEnv = TableEnvironment.getBatchTableEnvironment(env);

        // 1. register table
        String hiveMetastoreURI = params.get(Constants.SOURCE_HIVE_METASTORE_URI);
        String database = params.get(Constants.SOURCE_DATABASE);
        HiveCatalog catalog = new HiveCatalog(CATALOG, hiveMetastoreURI);
        tEnv.registerCatalog(CATALOG, catalog);
        tEnv.setDefaultDatabase(CATALOG, database);

        // 2. get table
        String sql = params.get(Constants.OPERATION_SQL);
        System.out.println(sql);
        Table table = tEnv.sqlQuery(sql);

        // 3. sink
        String zkEndpoints = params.get(Constants.SINK_ZK_ENDPOINTS);
        String zkRootPath = params.get(Constants.SINK_ZK_ROOT_PATH);
        String tableName = params.get(Constants.SINK_RTIDB_TABLE);

        TableSchema tableSchema = table.getSchema();
        log.info("table schema is {}", tableSchema);

        RtiDBOutputFormat rtiDBOutputFormat = RtiDBOutputFormat.outputFormatBuilder()
                .setTableName(tableName)
                .setZkEndpoint(zkEndpoints)
                .setZkRootPath(zkRootPath)
                .setTableSchema(tableSchema.getFieldNames())
                .build();

        RtiDBTableSink rtiDBTableSink = new RtiDBTableSink(rtiDBOutputFormat);
        rtiDBTableSink.configure(tableSchema.getFieldNames(), tableSchema.getFieldTypes());
        table.writeToSink(rtiDBTableSink);
        env.setJobType(JobType.BATCH);
        env.execute(params.get(Constants.JOB_NAME));

    }
}
 **/