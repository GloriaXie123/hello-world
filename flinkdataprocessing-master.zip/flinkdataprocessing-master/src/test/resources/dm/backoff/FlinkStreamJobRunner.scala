package com._4paradigm.bumblebee.backoff

import java.text.SimpleDateFormat
import java.util.HashMap

import org.apache.flink.api.common.functions.FlatMapFunction
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.ObjectMapper
import org.apache.flink.streaming.api.datastream.DataStream
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment
import org.apache.flink.streaming.api.functions.sink.SinkFunction
import org.apache.flink.streaming.api.functions.source.SourceFunction
import org.apache.flink.util.Collector
import org.slf4j.LoggerFactory

/**
  * Created by zhanglibing on 2019/3/28
  */
object FlinkStreamJobRunner extends StreamTools {
  private val LOG = LoggerFactory.getLogger(classOf[StreamTools])

  def main(args: Array[String]): Unit = {
    println("检查参数")
    LOG.info("检查参数")
    if (!validateAndInitParams(args)) {
      System.exit(0)
    }

    println("source json array :"+SourceJsonArray)
    LOG.info("source json array :"+SourceJsonArray)
    println("sink json array :"+SinkJsonArray)
    LOG.info("sink json array :"+SinkJsonArray)
    println("trans json object :"+TransJsonObject)
    LOG.info("trans json object :"+TransJsonObject)
    println("job name :"+jobName)
    LOG.info(s"Laugh flink streaming job " + jobName)

    val see = StreamExecutionEnvironment.getExecutionEnvironment
    //启用拓扑检查点容错
    see.enableCheckpointing(6000) // checkpoint every 6000 msecs
    //see.setStateBackend(new FsStateBackend("hdfs://tmp/flink/checkpoints"))
    /*see.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION)
    see.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE)
    // 创建一个执行环境
    see.getConfig().setGlobalJobParameters(parameterTool)*/

    //see.getCheckpointConfig.disableCheckpointing()

    //val tableEnvironment = TableEnvironment.getTableEnvironment(env)

    LOG.info("Step1: Define tableSource operator and params is " + createSourceDescriptions) //
    val sourceList: List[Any] = initSource(createSourceDescriptions)

    LOG.info("Step2: Define tableSink operator and params is " + createSinkDescription)
    val sinkList: List[Any] = initSink(createSinkDescription)

    LOG.info("Step3: Execute transformation SQL and transform data in flink")
    /*for (sql <- parameterTool.get("sql_list").split(";")) {
      tableEnvironment.sqlUpdate(sql)
    }*/

    for (source <- sourceList) {
      for (sink <- sinkList) {
        val sourceEach:SourceFunction[String]= source.asInstanceOf[SourceFunction[String]]
        val stream: DataStream[String] = see.addSource(sourceEach)
        val doStream:DataStream[HashMap[String,Object]] = stream.flatMap(new Tokenizer())
        //doStream.print()
        val sinkEach: SinkFunction[HashMap[String, Object]]= sink.asInstanceOf[SinkFunction[HashMap[String, Object]]]
        doStream.addSink(sinkEach)
      }
    }
    see.execute(jobName)
  }
  def macValid(macStr: String): Boolean = {
    if (macStr == null ||
      macStr.length() != 17 ||
      macStr.charAt(2) != '-' ||
      macStr.charAt(5) != '-' ||
      macStr.charAt(8) != '-' ||
      macStr.charAt(11) != '-' ||
      macStr.charAt(14) != '-'
    ) {
      false
    } else {
      true
    }
  }

  private class Tokenizer extends FlatMapFunction[String, HashMap[String,Object]] {
    val macColName = "C_MAC_ADDR"
    val seqColName = "C_SK_SEQ"
    val timeColName = "D_TXN_DATETIME"
    override def flatMap(value: String, out: Collector[HashMap[String,Object]]): Unit = {
      try {
        val mapper = new ObjectMapper()
        val hashMap: HashMap[String, Object] = mapper.readValue(value, (new java.util.HashMap[String, Object].getClass))
        if (macValid(hashMap.get(macColName).toString()) == false) {
          hashMap.put(macColName, hashMap.get(seqColName))
        }
        val timeStr = String.valueOf(hashMap.get(timeColName))
        val ts = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss.SSS").parse(timeStr).getTime()
        hashMap.put(timeColName, String.valueOf(ts)) //**这里rtidb不支持long类型的数据，所以要存为string，不然会持续不报错重试。
        out.collect(hashMap)
      }catch {
        case e:Exception =>  {
          println("数据json解析化处理失败 没有指定列空指针或者非json格式 :"+value)
          e.printStackTrace()
          LOG.error("数据json解析化处理失败 没有指定列空指针或者非json格式 :"+value)
          LOG.error(e.toString)
        }
      }
    }
  }
}
