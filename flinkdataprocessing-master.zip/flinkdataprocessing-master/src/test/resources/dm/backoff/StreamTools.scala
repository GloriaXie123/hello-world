package com._4paradigm.bumblebee.backoff

import java.util
import java.util.Properties

import com._4paradigm.bumblebee.common.Tools
import com._4paradigm.bumblebee.common.types.{TableSinkType, TableSourceType}
//import com._4paradigm.bumblebee.ritdb.RtidbDataSink
import org.apache.flink.api.common.serialization.SimpleStringSchema
import org.apache.flink.streaming.api.functions.sink.SinkFunction
import org.apache.flink.streaming.connectors.kafka._
import org.slf4j.LoggerFactory

/**
  * Created by zhanglibing on 2019/3/29
  */

trait StreamTools extends Tools {
  private val LOG = LoggerFactory.getLogger(classOf[StreamTools])

  def initSource(sourcedescriptionList: List[SourceDescription]): List[Any] = {
    var sourceList = List[Any]()
    for (sourceDescription <- sourcedescriptionList) {
      val sourceObject:util.HashMap[String,Object] = sourceDescription.description
      val source:String = sourceObject.get("type").toString
      if(source.equals(TableSourceType.KAFKA.toString)) {
        val bootstrapServers = sourceObject.get("bootstrapServers").toString
        val zookeeperConnect = sourceObject.get("zookeeperConnect").toString
        val groupId = sourceObject.get("groupId").toString
        val topic = sourceObject.get("topic").toString
        val version = sourceObject.get("version").toString

        if ( bootstrapServers !=null && topic !=null
        ) {
          val properties = new Properties()
          properties.setProperty("bootstrap.servers",bootstrapServers );//*172.27.133.19:9092
          // only required for Kafka 0.8
          if(zookeeperConnect !=null && !zookeeperConnect.equals("")){
            properties.setProperty("zookeeper.connect", zookeeperConnect)
          }
          if(groupId !=null && !groupId.equals("")){
            properties.setProperty("group.id", groupId)
          } else {
            properties.setProperty("group.id", uuid)//*group.id如果不设置就将从一个uuid组进行消费
          }
          /**
          properties.put("enable.auto.commit", "true")
             properties.put("auto.offset.reset", "earliest") //latest	earliest
             properties.put("auto.commit.interval.ms", "1000")
             properties.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer")
             properties.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer")
            */
          var kafkaconsumer :FlinkKafkaConsumerBase[String] = null
          println("Kafka Source 创建 参数:properties :"+properties +"  version:"+version+"  topic:"+topic)
          LOG.info("Kafka Source 创建 参数:properties :"+properties +"  version:"+version+"  topic:"+topic)
          if(version=="0.11"){
              kafkaconsumer = new FlinkKafkaConsumer011[String](topic,new SimpleStringSchema(), properties);
          }else if(version=="0.10"){
            kafkaconsumer = new FlinkKafkaConsumer010[String](topic,new SimpleStringSchema(), properties);
          } else if(version=="0.9"){
            kafkaconsumer = new FlinkKafkaConsumer09[String](topic,new SimpleStringSchema(), properties);
          } else {
            println("kafka 版本暂不支持 目前支持配置0.9，0.10，0.11")
            LOG.error("kafka 版本暂不支持 目前支持配置0.9，0.10，0.11")
          }
          /**
          //设置kafka消费起始位置，在此模式下，上面Kafka中的已提交偏移将被忽略，不会用作起始位置。
             kafkaconsumer.setStartFromEarliest()      // start from the earliest record possible
             kafkaconsumer.setStartFromLatest()        // start from the latest record
             kafkaconsumer.setStartFromTimestamp(...)  // start from specified epoch timestamp (milliseconds)
             kafkaconsumer.setStartFromGroupOffsets()  // the default behaviour */
          //通过kafka不同的 group.id 重头消费
          kafkaconsumer.setStartFromEarliest();      // start from the earliest record possible

          /**
          //设置单独消费某个分区的起始偏移量
             val specificStartOffsets = new java.util.HashMap[KafkaTopicPartition, java.lang.Long]()
             specificStartOffsets.put(new KafkaTopicPartition("myTopic", 0), 23L)
             specificStartOffsets.put(new KafkaTopicPartition("myTopic", 1), 31L)
             specificStartOffsets.put(new KafkaTopicPartition("myTopic", 2), 43L)
             kafkaconsumer.setStartFromSpecificOffsets(specificStartOffsets)
            */
          kafkaconsumer.setCommitOffsetsOnCheckpoints(true);//提交存储在检查点状态中的偏移量,确保Kafka代理中的承诺偏移量与检查点状态中的偏移量一致
          //kafkaconsumer.assignTimestampsAndWatermarks(new CustomWatermarkEmitter())//自定义时间戳提取器/水印发射器

          sourceList = sourceList.+:(kafkaconsumer)
        } else {
          println("kafka 必要参数缺省erro")
          println("Use: bootstrap.servers , topic")
          LOG.error("kafka 必要参数缺省erro")
          LOG.error("Use: bootstrap.servers , topic")
        }
        //TODO Table接口 描述扩展
/*
      val tableDescriptor = ExecutionEnvironment.connect(
          new Kafka()
          .version(sourceObject.getString("version")) // required: valid connector versions are "0.8", "0.9", "0.10", "0.11", and "universal"
          .topic(sourceObject.getString("kafka.topic")) // required: topic name from which the table is read
          .property("zookeeper.connect", sourceObject.getString("zookeeper.connect"))
          .property("bootstrap.servers", sourceObject.getString("bootstrap.servers"))
          .property("group.id", sourceObject.getString("group_id"))
          .startFromEarliest()
        )
        if (params.get("table_format") != None) {
          val formatType = params.getOrElse("table_format", "json")
          val formatDescription = params.getOrElse("format_content", "")
          //tableDescriptor.withFormat(getTableFormat(formatType, formatDescription))
        } else {

        }

        if (params.get("table_schema") != None) {
          val formatType = params.getOrElse("table_format", "json")
          val formatDescription = params.getOrElse("format_content", "")
          //tableDescriptor.withFormat(getTableFormat(formatType, formatDescription))
        } else {

        }
        tableDescriptor.registerTableSource(source)
        */

      } //TODO 其他资源扩展
      /*else if(source == TableSourceType.HDFS){
      }else if(source == TableSourceType.HIVE){
      }*/else {
        println("暂不支持其他格式数据源Source 目前仅支持配置kafka")
        LOG.error("暂不支持其他格式数据源Source 目前仅支持配置kafka")
      }
    }
    sourceList
  }

  def initSink(sinkDescriptionList: List[SinkDescription]): List[Any] = {
    var sinkList = List[Any]()
    for (sinkDescription <- sinkDescriptionList) {
      val sinkObject:util.HashMap[String,Object] = sinkDescription.description
      val sink:String = sinkObject.get("type").toString
      if(sink == TableSinkType.KAFKA.toString) {
        val server = sinkObject.get("bootstrap.servers").toString
        val topic = sinkObject.get("topic").toString
        val version = sinkObject.get("version").toString
        if (server != null && server!= "" &&
          topic!= null && server!= ""
        ) {
          var kafkaProducer:SinkFunction[String] = null
          if(version == "0.11"){
            kafkaProducer = new FlinkKafkaProducer011[String](server, topic, new SimpleStringSchema)
          } else if (version == "0.10") {
            kafkaProducer = new FlinkKafkaProducer010[String](server, topic, new SimpleStringSchema)
          } else if (version == "0.9") {
            kafkaProducer = new FlinkKafkaProducer09[String](server, topic, new SimpleStringSchema)
          } else {
            println("kafka 版本暂不支持 目前支持配置0.9，0.10,0.11")
            LOG.error("kafka 版本暂不支持 目前支持配置0.9，0.10,0.11")
          }
          // versions 0.10+ allow attaching the records' event timestamp when writing them to Kafka;
          // this method is not available for earlier Kafka versions
          //kafkaProducer.setWriteTimestampToKafka(true)
          sinkList = sinkList.+:(kafkaProducer)
        } else {
          println("kafka 必要参数缺省erro")
          println("Use: bootstrap.servers , topic")
          LOG.error("kafka 必要参数缺省erro")
          LOG.error("Use: bootstrap.servers , topic")
        }

        //TODO 其他sink 接口扩展
      }/*else if(sink == TableSourceType.HDFS.toString){
      }else if(sink == TableSourceType.HIVE.toString){
      }*/else if(sink == TableSourceType.RTIDB.toString){
        val zkEndpoint = sinkObject.get("zkEndpoint").toString
        val zkRootPath = sinkObject.get("zkRootPath").toString
        val tableName = sinkObject.get("tableName").toString
        if (zkEndpoint != null  && zkRootPath != null && tableName != null
        ) {
          var zkLeaderPath = sinkObject.get("zkLeaderPath").toString
          if(zkLeaderPath == null ){
            zkLeaderPath = zkRootPath+"/leader"
          }
          var timeClome = sinkObject.get("timeColumn").toString
          if (timeClome ==null){
            timeClome = ""
          }
          println("Rtidb Sink 创建 参数: zkEndpoint:"+zkEndpoint+" .zkRootPath:"+zkRootPath+" .zkLeaderPath:"+ zkLeaderPath+" .tableName:" +tableName+" .timeClome:"+timeClome)
          LOG.info("Rtidb Sink 创建 参数: zkEndpoint:"+zkEndpoint+" .zkRootPath:"+zkRootPath+" .zkLeaderPath:"+ zkLeaderPath+" .tableName:" +tableName+" .timeClome:"+timeClome)
          //val rtidbSink = new RtidbDataSink(zkEndpoint,zkRootPath, zkLeaderPath, tableName, timeClome)
          //sinkList = sinkList.+:(rtidbSink)
        } else {
          println("Rtidb 必要参数缺省erro")
          println("Use: bootstrap.servers , rtidb.zkRootPath ,rtidb.tableName")
          LOG.error("Rtidb 必要参数缺省erro")
          LOG.error("Use: bootstrap.servers , rtidb.zkRootPath ,rtidb.tableName")
        }
      }else {
        println("暂不支持其他格式数据源Sink 目前仅支持配置kafka，rtidb")
        LOG.error("暂不支持其他格式数据源Sink 目前仅支持配置kafka，rtidb")
      }
    }
    sinkList
  }
}
