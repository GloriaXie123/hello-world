package com._4paradigm.bumblebee.ritdb;

import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.apache.flink.util.Preconditions.checkNotNull;



public class RtidbDataSink extends RichSinkFunction<HashMap<String,Object>> implements CheckpointedFunction {

    protected final Logger log = LoggerFactory.getLogger(getClass());

    private List<HashMap<String, Object>> bufferedElements;
    private transient ListState<HashMap<String, Object>> checkpointedState;

    private String zkEndpoints = null; // 配置zk地址, 和集群启动配置中的zk_cluster保持⼀致
    private String zkRootPath = null;// 配置集群的zk根路径, 和集群启动配置中的zk_root_path保持⼀致
    private String tableName = null;//
    private String hashMapDateCol = null; //如果是hashMap的列名
    private String leaderPath = null;

    private RtiDBClient client;


    public RtidbDataSink(String zkEndpoints,String zkRootPath,String tableName){
        this(zkEndpoints,zkRootPath,zkRootPath + "/leader",tableName,"");
    }

    public RtidbDataSink(String zkEndpoints,String zkRootPath,String leaderPath,String tableName){
        this(zkEndpoints,zkRootPath,leaderPath,tableName,"");
    }

    //hashMapDateCol 时间列应提前将时间SimpleDateFormat处理成string类型
    public RtidbDataSink(String zkEndpoints,String zkRootPath,String leaderPath,String tableName,String hashMapDateCol){
        this.zkEndpoints=checkNotNull(zkEndpoints, "zkEndpoints is null");
        this.zkRootPath=checkNotNull(zkRootPath, "zkRootPath is null");
        this.tableName=checkNotNull(tableName, "tableName is null");
        this.leaderPath=checkNotNull(leaderPath, "tableName is null");
        this.hashMapDateCol=checkNotNull(hashMapDateCol, "hashMapDateCol is null");

        this.bufferedElements = new ArrayList<>();
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        try {
            this.client = new RtiDBClient(tableName, zkEndpoints, zkRootPath, hashMapDateCol, null);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("未正常初始化 Rtidb Source");
            log.error(e.toString());
        }
//        getRuntimeContext()
//                .getMetricGroup();
//                .gauge[Double, ScalaGauge[Double]](""MyGauge"", ScalaGauge[Double]( () => valueToExpose ) )
        super.open(parameters);
    }

    @Override
    public void invoke(HashMap<String,Object> value, Context context)  {
        bufferedElements.add(value);
        String timeStr = String.valueOf(value.get(hashMapDateCol));
        long ts = 0;
        try {
            ts = Long.parseLong(timeStr);
        } catch (Exception e) {
            ts = System.currentTimeMillis();
            log.error("Long.parseLong erro : \t"+value+"\r"+e.toString());
        }

        boolean ret = client.put(ts, value);
        if(!ret) {
            System.out.println("Rtidb put error , put result is false , HashMap: " +"\r\n\t HashMap: "+ value +"\r\n\t date: "+ts);
            log.error("Rtidb put error , put result is false , HashMap: " +"\r\n\t HashMap: "+ value +"\r\n\t date: "+ts);
        } else {
            bufferedElements.clear();
        }

    }

    @Override
    public void close() throws Exception {
        client.close();
        super.close();
    }

    //Checkpoint功能实现
    @Override
    public void snapshotState(FunctionSnapshotContext context) throws Exception {

        checkpointedState.clear();
        for (HashMap<String,Object> value:bufferedElements) {
            checkpointedState.add(value);//快照snapshot
        }
    }

    @Override
    public void initializeState(FunctionInitializationContext context) throws Exception {
        ListStateDescriptor<HashMap<String, Object>> descriptor =
                new ListStateDescriptor("buffered-elements", TypeInformation.of(new TypeHint<HashMap<String, Object>>() {}));
        checkpointedState = context.getOperatorStateStore().getListState(descriptor);
        if (context.isRestored()) {
            for (HashMap<String, Object> element : checkpointedState.get()) {
                bufferedElements.add(element);
            }
        }
    }
}
