package com._4paradigm.bumblebee.runner.demon

import com._4paradigm.bumblebee.ritdb.{RtiDBOutputFormat, RtiDBTableSink}
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment
import org.apache.flink.table.api.types.DataType
import org.apache.flink.table.api.{Table, TableEnvironment, TableSchema, Types}
import org.apache.flink.table.descriptors.{Json, Kafka, Schema}
import org.apache.flink.types.Row

object KafkaTableRtidb {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    // create a TableEnvironment for streaming queries
    val tableEnv = TableEnvironment.getTableEnvironment(env)
    tableEnv.connect(
      new Kafka()
        .version("0.11")
        .topic("test")
        .startFromLatest()
        .property("zookeeper.connect", "172.27.133.19:2181/kafka")
        .property("bootstrap.servers", "172.27.133.19:9092"))
      //必须Format
      .withFormat(
      new Json()
        .failOnMissingField(true)   // optional: flag whether to fail if a field is missing or not, false by default

        // required: define the schema either by using type information which parses numbers to corresponding types
        //.schema(Type.ROW(...))

    // or by using a JSON schema which parses to DECIMAL and TIMESTAMP
    /*.jsonSchema(
      "{" +
        "  type: 'object'," +
        "  properties: {" +
        "    lon: {" +
        "      type: 'number'" +
        "    }," +
        "    rideTime: {" +
        "      type: 'string'," +
        "      format: 'date-time'" +
        "    }" +
        "  }" +
        "}"
    )*/

      // or use the table's schema
      .deriveSchema()
    )
      //必须Schema
      .withSchema(
      new Schema()/*.from("struct<C_MAC_ADDR:string,C_CUSTOMER_ID:string>")*/
        .field("C_MAC_ADDR",Types.STRING)
        .field("C_CUSTOMER_ID",Types.STRING)
    )
      .inAppendMode()
      .registerTableSource("sm_user")

    //val stream = tableEnv.scan("sm_user")   ,C_CUSTOMER_ID as string2
    val table:Table=tableEnv.sqlQuery("select C_MAC_ADDR as string1 from sm_user")

    val dsRow = tableEnv.toAppendStream(table, classOf[Row])
    dsRow.print()
    //tableEnv.toAppendStream[Row](table).print().setParallelism(1)

    val zkEndpoints = "172.27.133.116:7181"
    val zkRootPath = "/rtidb_1340"
    val tableName = "test"

    val tableSchema : TableSchema= table.getSchema
    System.out.println("table schema is: " + tableSchema);

    val rtiDBOutputFormat = RtiDBOutputFormat.outputFormatBuilder()
      .setTableName(tableName)
      .setZkEndpoint(zkEndpoints)
      .setZkRootPath(zkRootPath)
      .setTableSchema(tableSchema.getFieldNames())
      .build();

    val rtiDBTableSink = new RtiDBTableSink(rtiDBOutputFormat);
    rtiDBTableSink.configure(tableSchema.getFieldNames, tableSchema.getFieldTypes.asInstanceOf[Array[DataType]]);
    table.writeToSink(rtiDBTableSink);

    env.execute("example")

  }
}
