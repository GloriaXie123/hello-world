package com._4paradigm.bumblebee.runner.demon

import com._4paradigm.bumblebee.ritdb.{RtiDBOutputFormat, RtiDBTableSink}
import com._4paradigm.bumblebee.runner.Hive2RtiDBRunnerTest
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment
import org.apache.flink.table.api.{Table, TableEnvironment, TableSchema, Types}
import org.apache.flink.table.descriptors.{Csv, FileSystem, Schema}

object FileSystemTableRtidb {
  def main(args: Array[String]): Unit = {
    //krb5认证
    Hive2RtiDBRunnerTest.init()

    val env = StreamExecutionEnvironment.getExecutionEnvironment
    // create a TableEnvironment for streaming queries
    val tableEnv = TableEnvironment.getBatchTableEnvironment(env)/*TableEnvironment(env)*/
    tableEnv.connect(
      new FileSystem().path(
        "file:///Users/shangyue/OneDrive/git/IDEA/4paradigm/flinkjobrunner/src/test/resources/data/test.csv"
//        "hdfs://hacluster/tmp/test.csv"
      )
      )
      //必须Format
      .withFormat(
      new Csv()
        //必需有序
        .field("name", Types.STRING)    // required: ordered format fields
        .field("age",Types.STRING)
        .field("gender",Types.STRING)
        //.field("field2", Types.SQL_TIMESTAMP)
        .fieldDelimiter(",")              // optional: string delimiter "," by default
        .lineDelimiter("\n")              // optional: string delimiter "\n" by default
        .quoteCharacter('"')              // optional: single character for string values, empty by default
        .commentPrefix("#")               // optional: string to indicate comments, empty by default
        .ignoreFirstLine()                // optional: ignore the first line, by default it is not skipped
        .ignoreParseErrors()              // optional: skip records with parse error instead of failing by default
    )
      //必须Schema
      .withSchema(
      new Schema()/*.from("struct<C_MAC_ADDR:string,C_CUSTOMER_ID:string>")*/
        .field("name",Types.STRING)
        .field("age",Types.STRING)
        .field("gender",Types.STRING)
    )
      //.inAppendMode()
      .registerTableSource("sm_user")

    //val stream = tableEnv.scan("sm_user")   ,C_CUSTOMER_ID as string2
    val table:Table=tableEnv.sqlQuery("select * from sm_user")//name as string1

    table.print()
    //val dsRow = tableEnv.toAppendStream(table, classOf[Row])
    //dsRow.print()
    //tableEnv.toAppendStream[Row](table).print().setParallelism(1)

    val zkEndpoints = "172.27.133.116:7181"
    val zkRootPath = "/rtidb_1340"
    val tableName = "test"

    val tableSchema : TableSchema= table.getSchema
    System.out.println("table schema is: " + tableSchema);

    val rtiDBOutputFormat = RtiDBOutputFormat.outputFormatBuilder()
      .setTableName(tableName)
      .setZkEndpoint(zkEndpoints)
      .setZkRootPath(zkRootPath)
      .setTableSchema(tableSchema.getFieldNames())
      .build();

    val rtiDBTableSink = new RtiDBTableSink(rtiDBOutputFormat);
    rtiDBTableSink.configure(tableSchema.getFieldNames, tableSchema.getFieldTypes.asInstanceOf[Array[DataType]]);
    table.writeToSink(rtiDBTableSink);

    env.execute("example")

  }
}
