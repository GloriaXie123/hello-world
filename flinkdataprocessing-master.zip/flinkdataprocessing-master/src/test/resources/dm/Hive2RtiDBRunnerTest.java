package dm;

import com.alibaba.fastjson.JSON;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Builder;
import lombok.Data;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment.JobType;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.TableEnvironment;
import org.apache.flink.table.api.java.BatchTableEnvironment;
import org.apache.flink.table.catalog.CatalogTable;
import org.apache.flink.table.catalog.ObjectPath;
import org.apache.flink.table.catalog.hive.HiveCatalog;
import org.apache.hadoop.security.UserGroupInformation;
import org.junit.Ignore;
import org.junit.Test;

/**
 * @author akis on 2019-04-24
 */
@Ignore
public class Hive2RtiDBRunnerTest {

    public static void init() throws IOException {
        String USER_PRINCIPAL = "prophet";
        String basePath = Hive2RtiDBRunnerTest.class.getResource("/").getPath();
        String KRB5_FILE = basePath + "bak/krb5.conf";
        String USER_KEYTAB_FILE = basePath + "bak/user.keytab";
        System.setProperty("java.security.krb5.conf", KRB5_FILE);
        org.apache.hadoop.conf.Configuration conf = new org.apache.hadoop.conf.Configuration();
        UserGroupInformation.setConfiguration(conf);
        UserGroupInformation.loginUserFromKeytab(USER_PRINCIPAL, USER_KEYTAB_FILE);
    }


    @Data
    @Builder
    public static class Config {
        private String entryClass;
        private Map<String, String> programArgs;
    }

    @Test
    public void testArgs() throws UnsupportedEncodingException {


        Map<String, String> map = new HashMap<String, String>() {
            {
                put("source.hiveMetastoreURI", "thrift://172.27.128.141:21088");
                put("source.database", "default");
                put("operation.sql", "select * from student limit 1");
                put("sink.zkEndpoints", "172.27.133.116:7181,172.27.133.117:7181,172.27.133.118:7181,172.27.133.119:7181,172.27.133.120:7181,172.27.133.121:7181");
                put("sink.zkRootPath", "/rtidb_1340");
                put("sink.rtidbTable", "student");
            }
        };
        System.out.println(JSON.toJSONString(map));
        System.out.println(URLEncoder.encode(JSON.toJSONString(map), "UTF-8"));
    }

    @Test
    public void hive2RtiDBRunnerTest() throws Exception {
        init();
        final String CATALOG = "bumblebee";
        String input = "{\"sink.rtidbTable\":\"student\",\"source.database\":\"default\",\"operation.sql\":\"select * from student\",\"source.hiveMetastoreURI\":\"thrift://172.27.128.141:21088\",\"sink.zkEndpoints\":\"172.27.133.116:7181,172.27.133.117:7181,172.27.133.118:7181,172.27.133.119:7181,172.27.133.120:7181,172.27.133.121:7181\",\"sink.zkRootPath\":\"/rtidb_1340\"}";

        Map<String, String> params = JSON.parseObject(input, HashMap.class);

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        BatchTableEnvironment tEnv = TableEnvironment.getBatchTableEnvironment(env);
        env.setJobType(JobType.BATCH);

        // 1. register table
        String hiveMetastoreURI = params.get(Constants.SOURCE_HIVE_METASTORE_URI);
        String database = params.get(Constants.SOURCE_DATABASE);
        HiveCatalog catalog = new HiveCatalog(CATALOG, hiveMetastoreURI);
        tEnv.registerCatalog(CATALOG, catalog);
        tEnv.setDefaultDatabase(CATALOG, database);

        CatalogTable catalogTable = catalog.getTable(new ObjectPath("default", "student"));

        // 2. get table
        String sql = params.get(Constants.OPERATION_SQL);
        sql = "select * from student_rcfile";
        Table table = tEnv.sqlQuery(sql);
        table.printSchema();
        table.print();

//         3. sink
//        String zkEndpoints = params.get(Constants.SINK_ZK_ENDPOINTS);
//        String zkRootPath = params.get(Constants.SINK_ZK_ROOT_PATH);
//        String tableName = params.get(Constants.SINK_RTIDB_TABLE);
//
//        TableSchema tableSchema = table.getSchema();
//        System.out.println(tableSchema);
//
//        RtiDBOutputFormat rtiDBOutputFormat = RtiDBOutputFormat.outputFormatBuilder()
//                .setTableName(tableName)
//                .setZkEndpoint(zkEndpoints)
//                .setZkRootPath(zkRootPath)
//                .setTableSchema(tableSchema.getFieldNames())
//                .build();
//
//        RtiDBTableSink rtiDBTableSink = new RtiDBTableSink(rtiDBOutputFormat);
//        rtiDBTableSink.configure(tableSchema.getFieldNames(), tableSchema.getFieldTypes());
//        table.writeToSink(rtiDBTableSink);
//
//        env.execute();
    }

    @Test
    public void registerTable() throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        BatchTableEnvironment tEnv = TableEnvironment.getBatchTableEnvironment(env);

        List<Tuple2<String, String>> data = new ArrayList<>();
        data.add(new Tuple2<>("akis", "haha"));
        data.add(new Tuple2<>("fore", "bababa"));
        data.add(new Tuple2<>("roliy", "tttt"));
        DataStream<Tuple2<String, String>> dataStream = env.fromCollection(data);

        Table t1 = tEnv.fromBoundedStream(dataStream, "name, comment");
        tEnv.registerTable("t1", t1);
        Table t2 = tEnv.sqlQuery("select * from t1");
        tEnv.registerTable("t2", t2);
        Table t3 = tEnv.sqlQuery("select * from t2");
        t3.printSchema();
        t2.print();
    }

    @Test
    public void test() {
        final String CATALOG = "bumblebee";

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        BatchTableEnvironment tEnv = TableEnvironment.getBatchTableEnvironment(env);
        env.setJobType(JobType.BATCH);

        // 1. register table
        String hiveMetastoreURI = "thrift://127.0.0.1:9083";
        String database = "default";
        HiveCatalog catalog = new HiveCatalog(CATALOG, hiveMetastoreURI);
        tEnv.registerCatalog(CATALOG, catalog);
        tEnv.setDefaultDatabase(CATALOG, database);

        // 2. get table
        String sql = "select * from all_types";
        Table table = tEnv.sqlQuery(sql);
        table.printSchema();
        table.print();
    }
}
