package com._4paradigm.bumblebee.runner;

import com._4paradigm.bumblebee.common.BatchAndStreamRunner;
import org.apache.commons.io.FileUtils;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.ObjectMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;

public class YumChinaTopicRun {
    public static final Logger LOG = LoggerFactory.getLogger(YumChinaTopicRun.class);

    public static void main(String[] args) throws IOException {
        String basepath = null;
        if(args[0].split("/").length>1 ||args[0].split("\\\\").length>1){
            basepath = args[0];
        }else{
            basepath = YumChinaTopicRun.class.getClassLoader().getResource("").getPath()+"/hadoop_conf/"+args[0];
        }

        String input = FileUtils.readFileToString(new File(basepath), "UTF-8");//内容
        ObjectMapper mapper = new ObjectMapper();
        HashMap<String,Object> jsonMap  = mapper.readValue(input, new HashMap<String,Object>().getClass());
        String jsonCopy = mapper.writeValueAsString(jsonMap);
        String encodeStr = URLEncoder.encode(jsonCopy, "UTF-8");

        String[] arg = {encodeStr};
        BatchAndStreamRunner.run(arg);
    }

    /*
    public void initKerberosEnv() throws IOException, URISyntaxException {
        String basepath = YumChinaTopicRun.class.getClassLoader().getResource("").getPath()+"hadoop_conf/";
        LOG.info("base dir:"+basepath );
        File file = new File(basepath+"env.properties");
        if(file.exists()){
            LOG.info("有 env.properties ,开始Kerberos认证");
            ParameterTool para = ParameterTool.fromPropertiesFile(basepath+"env.properties");
            GlobalConfig.setParameter(para);
            String env = GlobalConfig.getEnv();
            String user = GlobalConfig.getKeberosUser();

            LOG.info("Current path: " + System.getProperty("user.dir"));
            LOG.info("Current environment: " + env + ", Keberos user: " + user);

            String confPath = basepath + "hadoop_conf2/krb5.conf";
            String keyTabPath = basepath + user + ".keytab";

            System.setProperty("java.security.krb5.conf", confPath);
            System.setProperty("javax.security.auth.useSubjectCredsOnly","false");

            try{
                Configuration configuration = new Configuration();
                configuration.addResource(basepath + "hadoop_conf2/hdfs-site.xml");
                configuration.addResource(basepath + "hadoop_conf2/core-site.xml");
                UserGroupInformation.setConfiguration(configuration);
                UserGroupInformation.loginUserFromKeytab(user, keyTabPath);
            }catch (IOException e){
                LOG.error("failed to init Kerberos, Error msg:");
                LOG.error(ExceptionUtils.getStackTrace(e));
            }
        }else {
            LOG.info("没有 env.properties ,不需要Kerberos认证");
        }
    }

     */

/*
    public void init() throws IOException {
        String USER_PRINCIPAL = "work";
        String basePath = YumChinaTopicRun.class.getResource("/").getPath();
        String KRB5_FILE = basePath + "icbc/krb5.conf";
        String USER_KEYTAB_FILE = basePath + "icbc/user.keytab";
        System.setProperty("java.security.krb5.conf", KRB5_FILE);
        org.apache.hadoop.conf.Configuration conf = new org.apache.hadoop.conf.Configuration();
        System.out.println(basePath + "icbc/hdfs-site.xml");
        conf.addResource(basePath + "hdfs-site.xml");
        conf.addResource(basePath + "core-site.xml");
        UserGroupInformation.setConfiguration(conf);
        UserGroupInformation.loginUserFromKeytab(USER_PRINCIPAL, USER_KEYTAB_FILE);
    }
 */

}
