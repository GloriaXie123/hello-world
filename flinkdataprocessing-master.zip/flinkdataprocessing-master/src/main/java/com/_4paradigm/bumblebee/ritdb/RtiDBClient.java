package com._4paradigm.bumblebee.ritdb;

import com._4paradigm.rtidb.client.TableSyncClient;
import com._4paradigm.rtidb.client.TabletException;
import com._4paradigm.rtidb.client.ha.RTIDBClientConfig;
import com._4paradigm.rtidb.client.ha.impl.RTIDBClusterClient;
import com._4paradigm.rtidb.client.impl.TableSyncClientImpl;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.TimeZone;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 * @author akis on 2019-04-22
 */
@Slf4j
public class RtiDBClient {

    private RTIDBClusterClient clusterClient;
    private TableSyncClient tableSyncClient;

    private String tableName;
    @Getter
    private String timeColName;
    @Getter
    private SimpleDateFormat simpleDateFormat;


    public RtiDBClient(String tableName, String zkEndpoints, String zkRootPath,
            String timeColName, String timeFormat) throws IOException, TabletException {
        this.tableName = tableName;
        this.timeColName = timeColName;
        if (timeFormat != null) {
            simpleDateFormat = new SimpleDateFormat(timeFormat);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
        }
        RTIDBClientConfig config = new RTIDBClientConfig();
        config.setZkEndpoints(zkEndpoints);
        config.setZkRootPath(zkRootPath);
        // 失败重试次数
        config.setMaxRetryCnt(3);
        clusterClient = new RTIDBClusterClient(config);
        clusterClient.init();
        tableSyncClient = new TableSyncClientImpl(clusterClient);
        log.info("init rtidb client");
    }

    public boolean put(Long time, Map<String, Object> row) {
        try {
            return tableSyncClient.put(tableName, time, row);
        } catch (Exception e) {
            log.info("failed to write data to rtidb {}", tableName, e);
            return false;
        }
    }

    public void close() {
        clusterClient.close();
        log.info("close rtidb client");
    }
}
