package com._4paradigm.bumblebee.parquet;

/*
import com._4paradigm.pdms.telamon.client.TelamonClient;
import com._4paradigm.pdms.telamon.enumeration.ResourceStatus;
import com._4paradigm.pdms.telamon.enumeration.StorageFormat;
import com._4paradigm.pdms.telamon.model.CommonSchemaTerm;
import com._4paradigm.pdms.telamon.model.Table;
import com._4paradigm.pdms.telamon.v1.enumeration.PRNType;
import com._4paradigm.pdms.telamon.v1.util.PRN;
 */
import org.apache.commons.compress.utils.Lists;
import org.apache.flink.api.common.io.RichOutputFormat;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.core.fs.FileSystem;
import org.apache.flink.core.fs.Path;
import org.apache.flink.core.fs.SafetyNetWrapperFileSystem;
import org.apache.flink.core.fs.local.LocalFileSystem;
import org.apache.flink.runtime.fs.hdfs.HadoopFileSystem;
import org.apache.flink.table.api.Types;
import org.apache.flink.types.Row;
import org.apache.flink.util.Preconditions;

import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.TaskAttemptID;
import org.apache.parquet.column.ParquetProperties;
import org.apache.parquet.example.data.Group;
import org.apache.parquet.example.data.simple.SimpleGroupFactory;
import org.apache.parquet.hadoop.ParquetFileWriter;
import org.apache.parquet.hadoop.ParquetOutputFormat;
import org.apache.parquet.hadoop.ParquetWriter;
import org.apache.parquet.hadoop.example.ExampleParquetWriter;
import org.apache.parquet.hadoop.metadata.CompressionCodecName;
import org.apache.parquet.hadoop.util.ContextUtil;
import org.apache.parquet.schema.MessageType;
import org.apache.parquet.schema.MessageTypeParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;


public class ParquetBucketingOutputFormat extends RichOutputFormat<Row> {

	public static final Logger LOG = LoggerFactory.getLogger(ParquetBucketingOutputFormat.class);
	private static final int DEFAULT_BLOCK_SIZE = 128 * 1024 * 1024;
	private static final String FILE_PREFIX_NAME = "parquet-";

	private final TypeInformation<?>[] fieldTypes;
	private final String[] fieldNames;
	private final String dir;
	private int blockSize;
	private boolean enableDictionary;
	private CompressionCodecName compression;
	private String filePrefixName;
	private MessageType schema;

	private ParquetWriter<Group> realWriter;
	//private org.apache.hadoop.mapreduce.RecordWriter<Void, Row> realWriter;
	private TaskAttemptContext taskContext;
	private SimpleGroupFactory groupFactory;
	private HashMap<String,String> map ;
	private int num = 0;
	private long lastTime ;
	private long timeLength ;
	private String dir2;
	private String fileNamePrefix;

	private String groupPrn;
	private String serverUrl;
	private String accessKey;
	private int workspaceId;

	private String tableName;
	private String tableNameCopy;

	private  int taskNumber;
	private int numTasks;

	//private List<CommonSchemaTerm> lists;
	/**
	public Stream2ParquetOutputFormat(String dir, TypeInformation[] fieldTypes, String[] fieldNames) throws IOException{
		this(dir, fieldTypes, fieldNames, CompressionCodecName.UNCOMPRESSED, DEFAULT_BLOCK_SIZE, false);
	}

	public Stream2ParquetOutputFormat(String dir, TypeInformation[] fieldTypes, String[] fieldNames, CompressionCodecName compression) throws IOException{
		this(dir, fieldTypes, fieldNames, compression, DEFAULT_BLOCK_SIZE, false);
	}

	public Stream2ParquetOutputFormat(String dir, TypeInformation[] fieldTypes, String[] fieldNames, CompressionCodecName compression, int blockSize, boolean enableDictionary) throws IOException{
		this(dir, fieldTypes, fieldNames, compression, blockSize, enableDictionary, FILE_PREFIX_NAME,60*60*1000);
	}
**/
	public ParquetBucketingOutputFormat( String serverUrl,String accessKey,int workspaceId,
									   String dir, String groupPrn,TypeInformation[] fieldTypes, String[] fieldNames, CompressionCodecName compression,
									  int blockSize, boolean enableDictionary, String filePrefixName,long timeLength
	) throws IOException{
		Preconditions.checkArgument(fieldNames != null && fieldNames.length > 0);
		Preconditions.checkArgument(fieldTypes != null && fieldTypes.length == fieldNames.length);
		this.fieldNames = fieldNames;
		this.fieldTypes = fieldTypes;

		this.dir = dir;
		this.groupPrn = groupPrn;
		this.serverUrl = serverUrl;
		this.accessKey = accessKey;
		this.workspaceId = workspaceId;

		this.blockSize = blockSize;
		this.enableDictionary = enableDictionary;
		this.compression = compression;
		this.filePrefixName = filePrefixName;
		this.timeLength = timeLength;

		JobConf jobConf = new JobConf();
		// init and register file system
		Path path = new Path(dir);
		FileSystem fs = path.getFileSystem();
		if (fs instanceof SafetyNetWrapperFileSystem) {
			fs = ((SafetyNetWrapperFileSystem) fs).getWrappedDelegate();
		}
		if (fs instanceof HadoopFileSystem) {
			//jobConf.addResource(((HadoopFileSystem) fs).getConfig()); TODO
			jobConf.addResource(((HadoopFileSystem) fs).getHadoopFileSystem().getConf());
		}
		if (!(fs instanceof LocalFileSystem || fs instanceof HadoopFileSystem)) {
			throw new RuntimeException("FileSystem: " + fs.getClass().getCanonicalName() + " is not supported.");
		}
		if(fs.exists(path)){
			// clean up output file in case of failover.
			fs.delete(path, true);
			LOG.info("基础存储目录 : "+path);
		}
		//fs.mkdirs(path);
		//LOG.info("创建："+path);
		lastTime = new Date().getTime();
		LOG.info("block 块大小 ："+blockSize/1024 +"kb");
		LOG.info("timeLenght 大小 ："+timeLength/1000 +"s");
	}

	@Override
	public void configure(Configuration parameters) {
	}

	@Override
	public void open(int taskNumber, int numTasks) throws IOException {
		this.taskNumber = taskNumber;
		this.numTasks = numTasks ;
		Date now = new Date();
		tableName = "topic_"+new SimpleDateFormat("yyyy-MM-dd-HH-mm").format(now) +"_"+new SimpleDateFormat("yyyy-MM-dd-HH-mm").format(new Date(now.getTime()+timeLength));
		dir2 = new Path(new Path(dir,groupPrn.split(".table-group")[0]+"_table-group").toUri().toString() ,
				tableName+"_table")
				.toUri().toString();

		fileNamePrefix = filePrefixName + numTasks + "-" + taskNumber+ "-";
		createNew();
	}

	public void createNew() throws IOException {
		JobConf jobConf = new JobConf();
		// init and register file system
		String fileName = fileNamePrefix + num+ ".parquet";
		Path dir2Path = new Path(dir2);
		FileSystem fs = dir2Path.getFileSystem();
		if (fs instanceof SafetyNetWrapperFileSystem) {
			fs = ((SafetyNetWrapperFileSystem) fs).getWrappedDelegate();
		}

		if (fs instanceof HadoopFileSystem) {
			//jobConf.addResource(((HadoopFileSystem) fs).getConfig()); TODO
			jobConf.addResource(((HadoopFileSystem) fs).getHadoopFileSystem().getConf());
		}

		if (!(fs instanceof LocalFileSystem || fs instanceof HadoopFileSystem)) {
			throw new RuntimeException("FileSystem: " + fs.getClass().getCanonicalName() + " is not supported.");
		}
		if(!fs.exists(dir2Path)){
			fs.mkdirs(dir2Path);
			LOG.info("创建 pdms时间分区的表地址 ："+dir2Path.getPath());
		}

		Path path = new Path(dir2, fileName);
		//ParquetOutputFormat realOutputFormat = new ParquetOutputFormat(new RowWritableWriteSupport(fieldTypes));
		//LOG.info("creating new record writer..." + this);
		//RowWritableWriteSupport.setSchema(ParquetSchemaConverter.convert(fieldNames, fieldTypes), jobConf);

		try {
			// create a TaskInputOutputContext
			TaskAttemptID taskAttemptID = new TaskAttemptID();
			taskContext = ContextUtil.newTaskAttemptContext(jobConf, taskAttemptID);

			LOG.info("initialize serde with table properties.");
			initializeSerProperties(taskContext);

			LOG.info("creating real writer to write at " + dir);
			if(schema == null ){
				schema = formatSchema(fieldNames,fieldTypes);
			}

			//realWriter = realOutputFormat.getRecordWriter(taskContext, new org.apache.hadoop.fs.Path(path.toUri()));
			realWriter= ExampleParquetWriter
					.builder(new org.apache.hadoop.fs.Path(path.toUri()))
					.withWriteMode(ParquetFileWriter.Mode.OVERWRITE)
					.withWriterVersion(ParquetProperties.WriterVersion.PARQUET_1_0)
					.withCompressionCodec(compression)
					.withConf(ContextUtil.getConfiguration(taskContext))
					.withType(schema).build();

			groupFactory = new SimpleGroupFactory(schema);

			/*
			if( numTasks-1 == taskNumber){
				if(tableNameCopy == null || !tableNameCopy.equals(tableName)){
					LOG.info("{}个线程，使用最后一个线程{}线程跑注册PDMS表的工作",numTasks,taskNumber);
					pdmsTable();
					tableNameCopy = tableName;
				}
			}*/

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void pdmsTable() throws Exception {
		/*
		LOG.info("pdms 注册Table ");
		TelamonClient client = new TelamonClient(serverUrl, accessKey, workspaceId);

		Table table = new Table();
		PRN prn = PRN.builder().namespace(PRN.getNamespace(groupPrn))
				.groupName(PRN.getName(groupPrn))
				.groupType(PRN.getType(groupPrn))
				.name(tableName)
				.type(PRNType.Table)
				.buildDepGroupPRN();
		table.setPrn(prn.toString());
		table.setUrl(new Path(dir,PRN.toPath(prn.toString())).toUri().toString());



		if(lists==null){
			lists = getPDMSTableSchema();
		}
		table.setSchema(lists); // 真正的 schema
		table.setStorageFormat(StorageFormat.parquet);
		table.setResourceStatus(ResourceStatus.SUCCESS);
		table.setSize((long)blockSize*numTasks); // 大致估算 因线程丢失问题结果偏大
		table.setLineNum(500L); // TODO 先建表逻辑，无法估算行数

		client.createTable(table);
		//TODO 创建完 table 后要打个 user_data 的 tag
		 */
	}

	/*
	private List<CommonSchemaTerm>  getPDMSTableSchema(){
		List<CommonSchemaTerm> lists =  Lists.newArrayList();
		for(int i=0;i<fieldNames.length;i++) {
			lists.add(new CommonSchemaTerm(fieldNames[i],pdmsTypeTransform(fieldTypes[i])));
		}
		return lists;
	}*/

	//	private final
	private MessageType formatSchema(String[] fieldNames,TypeInformation[] fieldTypes){
		if(fieldNames.length!=fieldTypes.length){
			LOG.error("fieldNames.length!=fieldTypes.length {} {}",fieldNames.length,fieldTypes.length);
			throw  new RuntimeException("fieldNames.length!=fieldTypes.length");
		}
		/**
		String schemaStr = "message schema {"
				+ "optional int64 log_id;"
				+ "optional binary idc_id;"
				+ "optional int64 house_id;"
				+ "optional int64 src_ip_long;"
				+ "optional int64 dest_ip_long;"
				+ "optional int64 src_port;"
				+ "optional int64 dest_port;"
				+ "optional int32 protocol_type;"
				+ "optional binary url64;"
				+ "optional binary access_time;}";
		MessageType schema = MessageTypeParser.parseMessageType(schemaStr);
		 **/
		String schemaStr = "message schema {";
		map = new HashMap<>();
		for(int i=0;i<fieldNames.length;i++) {
			String parquetType = parquetTypeTransform(fieldTypes[i]);
			schemaStr = schemaStr+"optional "+parquetType+" "+fieldNames[i]+";";
			map.put(fieldNames[i],parquetType);
		}
		schemaStr += "}";
		MessageType schema = MessageTypeParser.parseMessageType(schemaStr);
		return schema;
	}

	public String parquetTypeTransform(TypeInformation typeInformation){
		/**
		BOOLEAN：1位布尔值
		INT32：32位有符号整数
		INT64：64位有符号整数
		INT96：96位有符号整数
		FLOAT：IEEE 32位浮点值
		DOUBLE：IEEE 64位浮点值
		BYTE_ARRAY：任意长字节数组
		 **/
		if (Types.STRING().equals(typeInformation)) { return "binary"; }//TODO check
		else if( Types.BOOLEAN().equals(typeInformation)){ return "boolean";}
		else if( Types.BYTE().equals(typeInformation)){ return "binary";}//
		else if( Types.SHORT().equals(typeInformation)){ return "int32";}
		else if( Types.INT().equals(typeInformation)){ return "int32";}
		else if( Types.LONG().equals(typeInformation)){ return "int64";}
		else if( Types.FLOAT().equals(typeInformation)){ return "float";}
		else if( Types.DOUBLE().equals(typeInformation)){ return "double";}
		else if( Types.DECIMAL().equals(typeInformation)){ return "double";}
		else if( Types.SQL_DATE().equals(typeInformation)){ return "int32";}
		else if( Types.SQL_TIME().equals(typeInformation)){ return "binary";}//
		else if( Types.SQL_TIMESTAMP().equals(typeInformation)){ return "int96";}// // 支持先知spark16 "int64";
		else if( Types.INTERVAL_MONTHS().equals(typeInformation)){ return "binary";}//
		else if( Types.INTERVAL_MILLIS().equals(typeInformation)){ return "binary";}//
		else {
			return "binary";
		}
	}

	public String pdmsTypeTransform(TypeInformation typeInformation){
		/**
		 return "Null";
		 return "Boolean";
		 return "SmallInt";
		 return "Int";
		 return "BigInt";
		 return "Float";
		 return "Double";
		 return "Decimal";
		 return "Timestamp";
		 return "Date";
		 return "String";
		 return "List";
		 return "Map";
		 default:
		 return "String";
		 **/
		if (Types.STRING().equals(typeInformation)) { return "String"; }//TODO check
		else if( Types.BOOLEAN().equals(typeInformation)){ return "Boolean";}
		else if( Types.BYTE().equals(typeInformation)){ return "String";}//
		else if( Types.SHORT().equals(typeInformation)){ return "SmallInt";}
		else if( Types.INT().equals(typeInformation)){ return "Int";}
		else if( Types.LONG().equals(typeInformation)){ return "BigInt";}
		else if( Types.FLOAT().equals(typeInformation)){ return "Float";}
		else if( Types.DOUBLE().equals(typeInformation)){ return "Double";}
		else if( Types.DECIMAL().equals(typeInformation)){ return "Double";}
		else if( Types.SQL_DATE().equals(typeInformation)){ return "Date";}
		else if( Types.SQL_TIME().equals(typeInformation)){ return "String";}//
		else if( Types.SQL_TIMESTAMP().equals(typeInformation)){ return "Timestamp";}//
		else if( Types.INTERVAL_MONTHS().equals(typeInformation)){ return "String";}//
		else if( Types.INTERVAL_MILLIS().equals(typeInformation)){ return "String";}//
		else {
			return "String";
		}
	}

	private void initializeSerProperties(JobContext job) {
		org.apache.hadoop.conf.Configuration conf = ContextUtil.getConfiguration(job);
		if (blockSize > 0) {
			LOG.info("get override parquet.block.size property with: {}", blockSize);
			conf.setInt(ParquetOutputFormat.BLOCK_SIZE, blockSize);

			LOG.info("get override dfs.blocksize property with: {}", blockSize);
			conf.setInt("dfs.blocksize", blockSize);
		}

		LOG.info("get override parquet.enable.dictionary property with: {}", enableDictionary);
		conf.setBoolean(
			ParquetOutputFormat.ENABLE_DICTIONARY, enableDictionary);

		if (compression != null) {
			//get override compression properties via "tblproperties" clause if it is set
			LOG.info("get override compression properties with {}", compression.name());
			conf.set(ParquetOutputFormat.COMPRESSION, compression.name());
		}
	}

	@Override
	public void writeRecord(Row record) throws IOException {
		try {
			Group group = groupFactory.newGroup();
			for(int i=0;i<fieldNames.length;i++){
				String fieldName = fieldNames[i];
				Object object= record.getField(i);
				groupAppend(fieldName,object,group);
			}
			realWriter.write(group);
		} catch (final Exception e) {
			LOG.error("Writer.write(group) error ");
			e.printStackTrace();
		}

		Date now = new Date();
		if(now.getTime() - lastTime > timeLength){
			realWriter.close();
			num+=1;
			LOG.info("这次时间："+now.getTime()+"   上次时间："+lastTime +"  时间差："+(new Date().getTime() - lastTime)+"   预设时间差："+timeLength);
			tableName = "topic_"+new SimpleDateFormat("yyyy-MM-dd-HH-mm").format(now) +"_"+new SimpleDateFormat("yyyy-MM-dd-HH-mm").format(new Date(now.getTime()+timeLength));
			dir2 = new Path(new Path(dir,groupPrn.split(".table-group")[0]+"_table-group").toUri().toString() ,
					tableName+"_table")
					.toUri().toString();
			lastTime = now.getTime();
			createNew();
		}



	}
	public void groupAppend(String fieldName,Object object,Group group){
		String parquetType = map.get(fieldName);
		//System.out.println("fieldName :"+fieldName+"	parquetType :"+parquetType+"	object :"+object);
		switch (parquetType){
			case "binary":
				group.append(fieldName,object.toString());break;
			case "boolean":
				group.append(fieldName,Boolean.parseBoolean(object.toString()));break;
			case "int32":
				group.append(fieldName,Integer.parseInt(object.toString()));break;
			case "int64":
				group.append(fieldName,Long.parseLong(object.toString()));break;
			case "float":
				group.append(fieldName,Float.parseFloat(object.toString()));break;
			case "int96":
				group.append(fieldName,Long.parseLong(object.toString()));break;
			case "double":
				group.append(fieldName,Double.parseDouble(object.toString()));break;
			default:
				group.append(fieldName,object.toString());
		}
	}

	@Override
	public void close() throws IOException {
		try {
			realWriter.close();
		} catch (final Exception e) {
			LOG.error("realWriter.close() erro");
			e.printStackTrace();
		}
	}
}
