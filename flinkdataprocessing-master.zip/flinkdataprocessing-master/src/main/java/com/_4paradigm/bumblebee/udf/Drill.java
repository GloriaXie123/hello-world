package com._4paradigm.bumblebee.udf;

import com._4paradigm.bumblebee.connector.format.OrcSchemaAnalysis;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.table.api.Types;
import org.apache.flink.table.functions.TableFunction;
import org.apache.flink.types.Row;
import org.apache.orc.TypeDescription;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Drill extends TableFunction<Row> {
    private static final Logger LOG = LoggerFactory.getLogger(Drill.class);
    private TypeInformation<Row> separator ;
    private String key ;
    private Map<String,String> map ;

    private Integer[] nubs = null;
    private int length ;

    public Drill(Map<String,String> map,String key) {
        this.map = map;
        this.key = key;
        length = key.split("#").length;
    }

    public void eval(Row[] value) {
        //long startTime = System.currentTimeMillis();
        try{
            if(value!=null && value.length>0){
                for(int j=0;j<value.length;j++){
                    //在list的每个子单元后面加上了一个int类型数字，代表这个子单元在list中所在的位置
                    Row rowOut = value[j]==null?null:addNub(value[j],j);
                    if (length==2) {
                        //long startTime = System.currentTimeMillis();
                        if (rowOut != null) {
                            collect(rowOut);
                        }
                        //long endTime = System.currentTimeMillis();
                        //System.out.println("Row[] 第二层数据抽取结束，时长：" + (endTime - startTime) + "ms");
                    }else if (length==3){
                        //long startTime = System.currentTimeMillis();
                        if(rowOut!=null){
                            if(nubs!=null){
                                Row[] row2s = (Row[])rowOut.getField(nubs[nubs.length-1]);//第二级数据
                                if(row2s!=null){
                                    for(int i=0;i<row2s.length;i++){
                                        Row row2 = row2s[i];
                                        int row2Length = row2.getArity();
                                        Row rowOut3 = new Row(row2Length+nubs.length);
                                        //拿三级数据
                                        for (int k = 0; k < row2Length; k++) {
                                            rowOut3.setField(k, row2.getField(k));
                                        }
                                        //加二级数据
                                        for(int k=0;k<nubs.length-1;k++){
                                            rowOut3.setField(row2Length+k,rowOut.getField(k));
                                        }
                                        //加二级数据的序号
                                        rowOut3.setField(row2Length+nubs.length-1,j);
                                        collect(rowOut3);
                                    }
                                }
                            }else{
                                LOG.error("请停机检查，序号集合为null 不符逻辑，数据："+value);
                            }
                        }

                        //long endTime = System.currentTimeMillis();
                        //System.out.println("Row[] 第三层list长度："+value.length+" 发出时长："+(endTime-startTime)+"ms");

                    }else{
                        LOG.error("请停机检查key，只支持2级和3级数据获取 ："+key);
                    }
                }
            }
        }catch (Exception e){
            LOG.error("Row[] 数据udf处理失败：");
            for(int j=0;j<value.length;j++){
                LOG.error("Row[] 处理失败列值散列："+value[j]);
            }
        }
       /* long endTime = System.currentTimeMillis();
        if(length==3){
            System.out.println("Row[] 第三层list长度："+value.length+" 发出时长："+(endTime-startTime)+"ms");
        }*/
    }

    /**
     * @Description 在Row最后一个字段加一个int nub
     * @author shangyue
     * @date 2019/12/30
    */
    public Row addNub(Row row,int nub) {
        int size = row.getArity();
        Row rowCopy = new Row(size+1);
        for (int i=0;i<size;i++) {
            rowCopy.setField(i,row.getField(i));
        }
        rowCopy.setField(size,nub);
        return rowCopy;
    }

    @Override
    public TypeInformation<Row> getResultType() {
        if(separator== null && key !=null){
            return getResultType2(key);
        }else if(separator!= null ){
            return separator;
        }else {
            throw new RuntimeException("逻辑非");
        }
    }


    public TypeInformation<Row> getResultType2(String word) {
        if(word!=null){
            int length = word.split("#").length;
            switch (length){
                case 2 ://第二层
                    return getTypeRow1(word);
                case 3://第三层
                    return getTypeRow2(word);
                    default:
                        throw new RuntimeException("只支持2级和3级");
            }
            /*switch (word){
                case "store_product#linkIds" ://第二层
                    return getTypeRow1(word);
                case "store_product#linkIds#linkId*itemLinkids"://第三层
                    return getTypeRow2(word);
                case "order#orderItems"://第二层
                    return getTypeRow1(word);
                case "order#orderItems#orderItemId*linkId*itemLinkIds"://第三层
                    return getTypeRow2(word);
                case "action#items"://第二层
                    return getTypeRow1(word);
                case "menu_force#itemLinkIds"://第二层
                    return getTypeRow1(word);
                default:
                    throw new RuntimeException("没有注册的表 列信息");
            }*/
        }else{
            throw new RuntimeException("word 不能为 null");
        }
    }

    //取出第2层:List<Row> 的Row类型
    public TypeInformation<Row> getTypeRow1(String word) {
        String topic = word.split("#")[0];
        String colum =  word.split("#")[1];
        TypeDescription typeDescription = TypeDescription.fromString(map.get("kafka_"+topic));
        if(typeDescription!=null){
            TypeDescription tp = getTypeRow(typeDescription,colum);
            tp.addField("indexID",TypeDescription.createInt());
            return new OrcSchemaAnalysis().getFlinkSchema(tp);
        }else {
            throw new RuntimeException("未能取到对应的表的schema，Map： "+map);
        }
    }

    //取出第3层:List<Row> 中的Row类型中 List<Row> 的Row类型
    public TypeInformation<Row> getTypeRow2(String word) {
        String topic = word.split("#")[0];
        String colum1 =  word.split("#")[1];
        String colum2 =  word.split("#")[2];
        TypeDescription typeDescription = TypeDescription.fromString(map.get("kafka_"+topic));
        if(typeDescription!=null){
            TypeDescription tp = getTypeRow(getTypeRow(typeDescription,colum1),colum2);
            tp.addField("indexID",TypeDescription.createInt());
            return new OrcSchemaAnalysis().getFlinkSchema(tp);
        }else {
            throw new RuntimeException("未能取到对应的表的schema，Map： "+map);
        }
    }

    //取出typeDescription描述 的colum列 list<Row> 的 Row的类型
    public TypeDescription getTypeRow(TypeDescription typeDescription,String colum) {
        if(colum!=null){
            String[] strs = colum.split("\\*");
            nubs = new Integer[strs.length];
            for(int j=0;j<strs.length;j++){
                nubs[j] = getNum(typeDescription,strs[j]);
            }
            TypeDescription typeChild2 = typeDescription.getChildren().get(nubs[nubs.length-1]);
            TypeDescription type2clm = null;
            if (typeChild2.getCategory().getName().equals("array")){
                type2clm = typeChild2.getChildren().get(0);
            }
            if(strs.length==1){
                return type2clm;
            }else {
                for(int j=0;j<strs.length-1;j++){
                    type2clm = type2clm.addField("N2_"+typeDescription.getFieldNames().get(nubs[j]),typeDescription.getChildren().get(nubs[j]));
                }
                return type2clm;
            }
        }else{
            throw new RuntimeException("3级结构定义方式结构错误："+colum);
        }
    }


    public int getNum(TypeDescription typeDescription,String colum){
        List<String> names = typeDescription.getFieldNames();
        Integer num = null;
        for(int i=0;i<names.size();i++){
            if(names.get(i).equalsIgnoreCase(colum)){
                num = i;
                break;
            }
        }
        if(num == null){
            throw new RuntimeException("Row 中没有此列 :"+colum);
        }
        return num;
    }

}

