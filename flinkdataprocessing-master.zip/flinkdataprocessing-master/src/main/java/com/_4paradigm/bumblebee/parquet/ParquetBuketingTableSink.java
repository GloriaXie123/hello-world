package com._4paradigm.bumblebee.parquet;

import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.typeutils.RowTypeInfo;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSink;
import org.apache.flink.table.sinks.AppendStreamTableSink;
import org.apache.flink.table.sinks.TableSink;
import org.apache.flink.table.utils.TableConnectorUtils;
import org.apache.flink.types.Row;
import org.apache.flink.util.InstantiationUtil;

import java.io.IOException;

public class ParquetBuketingTableSink  implements AppendStreamTableSink<Row>{
    private final ParquetBucketingOutputFormat outputFormat;
    private String[] fieldNames;
    private TypeInformation[] fieldTypes;


    public ParquetBuketingTableSink(ParquetBucketingOutputFormat outputFormat) {
        this.outputFormat = outputFormat;
    }

    @Override
    public void emitDataStream(DataStream<Row> dataStream) {
        consumeDataStream(dataStream);
    }

    /**
     Flink 1.9 需要实现
     */
    @Override
    public DataStreamSink<Row> consumeDataStream(DataStream<Row> dataStream) {
        return dataStream
                .addSink(new ParquetBucketingSinkFuntion(outputFormat))
                .setParallelism(dataStream.getParallelism())
                .name(TableConnectorUtils.generateRuntimeName(this.getClass(), fieldNames));
    }

    @Override
    public TypeInformation<Row> getOutputType() {
            return new RowTypeInfo(fieldTypes, fieldNames);
    }

    @Override
    public String[] getFieldNames() {
        return fieldNames;
    }

    @Override
    public TypeInformation<?>[] getFieldTypes() {
        return fieldTypes;
    }

    @Override
    public TableSink<Row> configure(String[] fieldNames, TypeInformation<?>[] fieldTypes) {
        ParquetBuketingTableSink copy;
        try {
            copy = new ParquetBuketingTableSink(InstantiationUtil.clone(outputFormat));
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        copy.fieldNames = fieldNames;
        copy.fieldTypes = fieldTypes;
        this.fieldNames = fieldNames;
        this.fieldTypes = fieldTypes;
        return copy;
    }
}
