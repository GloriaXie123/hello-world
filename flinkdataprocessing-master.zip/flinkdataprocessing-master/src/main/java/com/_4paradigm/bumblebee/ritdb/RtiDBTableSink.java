package com._4paradigm.bumblebee.ritdb;


import java.io.IOException;

import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.DataSet;
import org.apache.flink.api.java.typeutils.RowTypeInfo;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSink;
import org.apache.flink.table.sinks.AppendStreamTableSink;
import org.apache.flink.table.sinks.BatchTableSink;
import org.apache.flink.table.sinks.TableSink;
import org.apache.flink.table.utils.TableConnectorUtils;
import org.apache.flink.types.Row;
import org.apache.flink.util.InstantiationUtil;

/**
 * @author akis on 2019-04-22
 */
public class RtiDBTableSink implements BatchTableSink<Row>, AppendStreamTableSink<Row> {
    private final RtiDBOutputFormat outputFormat;
    private String[] fieldNames;
    private TypeInformation[] fieldTypes;

    public RtiDBTableSink(RtiDBOutputFormat outputFormat) {
        this.outputFormat = outputFormat;
    }

    @Override
    public void emitDataStream(DataStream<Row> dataStream) {
        consumeDataStream(dataStream);
    }

    /**
     Flink 1.9 需要实现
     */
    @Override
    public DataStreamSink<Row> consumeDataStream(DataStream<Row> dataStream) {
        return dataStream
                .addSink(new RtiDBSinkFuntion(outputFormat))
                .setParallelism(dataStream.getParallelism())
                .name(TableConnectorUtils.generateRuntimeName(this.getClass(), fieldNames));
    }

    @Override
    public void emitDataSet(DataSet<Row> dataSet) {
        dataSet.output(outputFormat);
    }


    @Override
    public TypeInformation<Row> getOutputType() {
        return new RowTypeInfo(fieldTypes, fieldNames);
    }

    @Override
    public String[] getFieldNames() {
        return fieldNames;
    }

    @Override
    public TypeInformation<?>[] getFieldTypes() {
        return fieldTypes;
    }

    @Override
    public TableSink<Row> configure(String[] strings, TypeInformation<?>[] typeInformations) {
        RtiDBTableSink copy;
        try {
            copy = new RtiDBTableSink(InstantiationUtil.clone(outputFormat));
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        copy.fieldNames = strings;
        copy.fieldTypes = typeInformations;

        this.fieldNames = strings;
        this.fieldTypes = typeInformations;

        return copy;
    }
}
