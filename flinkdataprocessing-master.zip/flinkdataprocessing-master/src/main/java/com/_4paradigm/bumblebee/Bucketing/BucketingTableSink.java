package com._4paradigm.bumblebee.Bucketing;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.typeutils.RowTypeInfo;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSink;
import org.apache.flink.streaming.connectors.fs.bucketing.BucketingSink;
import org.apache.flink.table.sinks.AppendStreamTableSink;
import org.apache.flink.table.sinks.TableSink;
import org.apache.flink.table.utils.TableConnectorUtils;
import org.apache.flink.types.Row;
import org.apache.flink.util.InstantiationUtil;

import java.io.IOException;

public class BucketingTableSink implements AppendStreamTableSink<Row> {//BatchTableSink<Row>,
    private BucketingSink Bucketingsink;
    private String[] fieldNames;
    private TypeInformation[] fieldTypes;
    private String split;

    public BucketingTableSink(BucketingSink Bucketingsink,String split) {
        this.Bucketingsink = Bucketingsink;
        this.split = split;
    }

    @Override
    public void emitDataStream(DataStream<Row> dataStream) {
        consumeDataStream(dataStream);
        //dataStream.map(new Row2String(split)).addSink(Bucketingsink).name(TableConnectorUtils.generateRuntimeName(this.getClass(), fieldNames));
    }

    /**
    Flink 1.9 需要实现
     */
    @Override
    public DataStreamSink<Row> consumeDataStream(DataStream<Row> dataStream) {
        return dataStream
                .map(new Row2String(split))//.setParallelism(10)
                .addSink(Bucketingsink)//.setParallelism(10)
                .setParallelism(dataStream.getParallelism())
                .name(TableConnectorUtils.generateRuntimeName(this.getClass(), fieldNames));
    }

    public class Row2String implements MapFunction<Row, String> {
        String splitStr ;
        public Row2String(String splitStr ){
            this.splitStr = splitStr;
        }
        @Override
        public String map(Row row) throws Exception {
            int arity = row.getArity();
            StringBuffer stringBuffer = new StringBuffer();
            for(int j=0;j<arity;j++){
                if(row.getField(j)!=null){
                    stringBuffer.append(row.getField(j));
                }
                stringBuffer.append(splitStr);
            }
            return stringBuffer.toString();
        }
    }

    @Override
    public TypeInformation<Row> getOutputType() {
        return new RowTypeInfo(fieldTypes, fieldNames);
    }

    @Override
    public String[] getFieldNames() {
        return fieldNames;
    }

    @Override
    public TypeInformation<?>[] getFieldTypes() {
        return fieldTypes;
    }

    @Override
    public TableSink<Row> configure(String[] strings, TypeInformation<?>[] typeInformations) {
        BucketingTableSink copy;
        try {
            copy = new BucketingTableSink(InstantiationUtil.clone(Bucketingsink),InstantiationUtil.clone(split));
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        copy.fieldNames = strings;
        copy.fieldTypes = typeInformations;

        this.fieldNames = strings;
        this.fieldTypes = typeInformations;
        return copy;
    }
}
