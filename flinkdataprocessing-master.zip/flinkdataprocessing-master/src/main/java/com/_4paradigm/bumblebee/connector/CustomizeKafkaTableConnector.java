package com._4paradigm.bumblebee.connector;

import com._4paradigm.bumblebee.connector.format.OrcSchemaAnalysis;
import com._4paradigm.bumblebee.connector.format.YumChinaJsonRowDeserializationSchema;
import com.google.common.base.Strings;
import org.apache.commons.net.ntp.TimeStamp;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.formats.json.JsonRowDeserializationSchema;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010;
import org.apache.flink.types.Row;
import org.apache.flink.util.Preconditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

public class CustomizeKafkaTableConnector extends KafkaTableConnector {
    /**
     * TODO 与scala 代码合并
     */
    public static final Logger LOG = LoggerFactory.getLogger(CustomizeKafkaTableConnector.class);
    String customize = "customize";//自定义，默认开启
    String version = "version";
    String bootstrapServers = "bootstrap.servers";//
    String zookeeperConnect = "zookeeper.connect";//
    String topicName = "topic";
    String groupId = "groupId";//
    String startFrom = "consumeMethod";
    String offSetsJson = "offSetsJson";
    String timestamp = "timestamp";

    String schema = "schema";
    String tableName = "tableName";


    public FlinkKafkaConsumer010<Row> getCustomizeKafkaTableSourceConnect(HashMap<String, Object> map) {
        String schemaValue = Preconditions.checkNotNull(getMapValueString(map, schema), "Customize kafka schem must not be null.");
        String tableNameValue = Preconditions.checkNotNull(getMapValueString(map, tableName), "Customize kafka topicName must not be null.");

        if (tableNameValue.equals("table")) {
            throw new RuntimeException("避免使用关键字:" + tableNameValue);
        }
        Boolean customizeBoolean = true;
        try {
            if(map.get(customize)!=null){
                customizeBoolean = (Boolean) map.get(customize);
            }
        } catch (Exception e) {
           e.printStackTrace();
        }

        LOG.info("Kafka Connect table格式化 参数   schema:" + schemaValue + "  tableName:" + tableNameValue);

        if (customizeBoolean) {
            String topicNameValue = Preconditions.checkNotNull(getMapValueString(map, topicName), "topicName must not be null.");
            String versionValue = getMapValueString(map, version); //"0.8", "0.9", "0.10", "0.11", and "universal"
            String bootstrapServersValue = Preconditions.checkNotNull(getMapValueString(map, bootstrapServers), "bootstrapServers must not be null.");
            String zookeeperConnectValue = getMapValueString(map, zookeeperConnect);
            String groupIdValue = getMapValueString(map, groupId);
            String startFromValue = getMapValueString(map, startFrom);
            String timeStampValue = getMapValueString(map, timestamp);
            Properties properties = new Properties();
            properties.setProperty("bootstrap.servers", bootstrapServersValue);
            if (Strings.isNullOrEmpty(versionValue)) {
                versionValue = "0.11";
            }
            // only required for Kafka 0.8
            if (versionValue.equals("0.8") && !Strings.isNullOrEmpty(zookeeperConnectValue)) {
                properties.setProperty("zookeeper.connect", zookeeperConnectValue);
            }
            if (!Strings.isNullOrEmpty(groupIdValue)) {
                properties.setProperty("group.id", groupIdValue);
            }
            //如果version为空则赋值为universal

            long dateParseLong = new Date().getTime();
            if(startFromValue.equals("timestamp")){
                SimpleDateFormat sdf  = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String dateString = timeStampValue;//"2017-12-20 14:02:08"
                Date dateParse = null;
                try {
                    dateParse = sdf.parse(dateString);
                    dateParseLong = dateParse.getTime();
                } catch (ParseException e) {
                    e.printStackTrace();
                    throw new RuntimeException("时间格式化错误，请检查时间格式");
                }
            }

            //去除所有预先设定的参数，剩余kafka的高级参数 加入kafka的 Properties
            getKafkaAllProperties(map, properties);
            LOG.info("Kafka Connect 连接创建 参数:properties :" + properties + "  version:" + versionValue + "  topicName:" + topicNameValue + "  startFrom:" + startFromValue + "  offSetsMap:");
            YumChinaJsonRowDeserializationSchema deserializationSchema = new YumChinaJsonRowDeserializationSchema(topicNameValue,
                    new OrcSchemaAnalysis().getFlinkSchema(schemaValue)
            );
            FlinkKafkaConsumer010<Row> kafkaSource = new FlinkKafkaConsumer010<Row>(topicNameValue, deserializationSchema, properties);

            switch (startFromValue){
                case "latest":kafkaSource.setStartFromLatest();break;
                case "earliest":kafkaSource.setStartFromEarliest();break;
                case "groupOffsets":kafkaSource.setStartFromGroupOffsets(); break;
                case "timestamp":kafkaSource.setStartFromTimestamp(dateParseLong); break;

                default:
                    LOG.error("kafka 消费参数不正确，默认从最后开始消费");
                    kafkaSource.setStartFromLatest();
            }

            return kafkaSource;
        } else {
            throw new RuntimeException("自定义kafka source代码与 原生source 融合 TODO");
        }

    }
}