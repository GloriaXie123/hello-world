package com._4paradigm.bumblebee.parquet;

import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.flink.types.Row;

public class ParquetBucketingSinkFuntion extends RichSinkFunction<Row> {
    final ParquetBucketingOutputFormat outputFormat;

    public ParquetBucketingSinkFuntion(ParquetBucketingOutputFormat outputFormat) {
        this.outputFormat = outputFormat;
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        RuntimeContext ctx = getRuntimeContext();
        outputFormat.setRuntimeContext(ctx);
        outputFormat.open(ctx.getIndexOfThisSubtask(), ctx.getNumberOfParallelSubtasks());
    }

    @Override
    public void invoke(Row value, Context context) throws Exception {
        outputFormat.writeRecord(value);
    }

    @Override
    public void close() throws Exception {
        outputFormat.close();
        super.close();
    }
}
