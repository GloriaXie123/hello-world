package com._4paradigm.bumblebee.Bucketing;

import com._4paradigm.bumblebee.connector.format.OrcSchemaAnalysis;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.typeutils.RowTypeInfo;
import org.apache.flink.core.fs.Path;
import org.apache.flink.formats.parquet.avro.ParquetAvroWriters;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSink;
import org.apache.flink.streaming.api.functions.sink.filesystem.bucketassigners.DateTimeBucketAssigner;
import org.apache.flink.streaming.connectors.fs.bucketing.BucketingSink;
import org.apache.flink.table.sinks.AppendStreamTableSink;
import org.apache.flink.table.sinks.TableSink;
import org.apache.flink.table.utils.TableConnectorUtils;
import org.apache.flink.types.Row;
import org.apache.flink.util.InstantiationUtil;
import org.apache.flink.api.common.serialization.SimpleStringEncoder;
import org.apache.flink.streaming.api.functions.sink.filesystem.StreamingFileSink;

import java.io.File;
import java.io.IOException;
import java.time.ZoneId;
import java.util.List;

public class BucketingTableSinkNew implements AppendStreamTableSink<Row> {//BatchTableSink<Row>,
    private final String row_csv = "row.csv";
    private final String row_tsv = "row.tsv";
    private final String bulk_parquet = "bulk.parquet";
    private final String bulk_orc = "bulk.orc";
    private String[] fieldNames;
    private TypeInformation[] fieldTypes;

    private String format;
    private String basePath;
    private String dateTimeFormat;
    private String zoneId;
    private String orcSchema;

    public BucketingTableSinkNew(String format,String basePath,String dateTimeFormat,String zoneId,String orcSchema) {
        this.format = format;
        this.basePath = basePath;
        this.dateTimeFormat = dateTimeFormat;
        this.zoneId = zoneId;
        this.orcSchema = orcSchema;
    }

    @Override
    public void emitDataStream(DataStream<Row> dataStream) {
        consumeDataStream(dataStream);
    }

    /**
    Flink 1.9 需要实现
     */
    @Override
    public DataStreamSink<Row> consumeDataStream(DataStream<Row> dataStream) {
        switch(format){
            case row_csv :
                StreamingFileSink rowCsvSink = StreamingFileSink
                        .forRowFormat(new Path(basePath), new SimpleStringEncoder("UTF-8"))
                        .withBucketAssigner(new DateTimeBucketAssigner<>(dateTimeFormat, ZoneId.of(zoneId)))
                        .build();
                return dataStream
                        .addSink(rowCsvSink)
                        .setParallelism(dataStream.getParallelism())
                        .name(TableConnectorUtils.generateRuntimeName(this.getClass(), fieldNames));
            case row_tsv :
                StreamingFileSink rowTsvSink = StreamingFileSink
                        .forRowFormat(new Path(basePath), new SimpleStringEncoder("UTF-8"))
                        .withBucketAssigner(new DateTimeBucketAssigner<>(dateTimeFormat, ZoneId.of(zoneId)))
                        .build();
                new BucketingSink("basePathValue");
                return dataStream
                        .map(new Row2String("\t"))//.setParallelism(10)
                        .addSink(rowTsvSink)//.setParallelism(10)
                        .setParallelism(dataStream.getParallelism())
                        .name(TableConnectorUtils.generateRuntimeName(this.getClass(), fieldNames));
            case bulk_parquet :
                Schema avroSchema = new OrcSchemaAnalysis().getAvroSchema(orcSchema);
                StreamingFileSink bulkParquetSink = StreamingFileSink
                        .forBulkFormat(new Path(basePath), ParquetAvroWriters.forGenericRecord(avroSchema))
                        .withBucketAssigner(new DateTimeBucketAssigner<>(dateTimeFormat, ZoneId.of(zoneId)))
                        .build();
                return dataStream
                        .map(new Row2GenericRecord(avroSchema.toString()))
                        .addSink(bulkParquetSink)
                        .setParallelism(dataStream.getParallelism())
                        .name(TableConnectorUtils.generateRuntimeName(this.getClass(), fieldNames));
            case bulk_orc ://TODO
                throw new RuntimeException("暂时还未支持");
            default :
                throw new RuntimeException("暂时还未支持");
        }
    }

    public class Row2String implements MapFunction<Row, String> {
        String splitStr ;
        public Row2String(String splitStr ){
            this.splitStr = splitStr;
        }
        @Override
        public String map(Row row) throws Exception {
            int arity = row.getArity();
            StringBuffer stringBuffer = new StringBuffer();
            for(int j=0;j<arity;j++){
                if(row.getField(j)!=null){
                    stringBuffer.append(row.getField(j));
                }
                if(j!=arity-1){
                    stringBuffer.append(splitStr);
                }
            }
            return stringBuffer.toString();
        }
    }

    class Row2GenericRecord implements MapFunction<Row, GenericRecord> {
        String schemaStr;
        public Row2GenericRecord(String schemaStr){
            this.schemaStr =schemaStr;
        }
        @Override
        public GenericRecord map(Row row) throws Exception {
            int arity = row.getArity();
            org.apache.avro.Schema schema = new org.apache.avro.Schema.Parser().parse(schemaStr);
            GenericRecord genericReocrd = new GenericData.Record(schema);
            List<Schema.Field> list = schema.getFields();
            for(int j=0;j<arity;j++){
                if(row.getField(j)!=null){
                    genericReocrd.put(list.get(j).name(),row.getField(j));
                }
            }
            return genericReocrd;
        }
    }


    @Override
    public TypeInformation<Row> getOutputType() {
        return new RowTypeInfo(fieldTypes, fieldNames);
    }

    @Override
    public String[] getFieldNames() {
        return fieldNames;
    }

    @Override
    public TypeInformation<?>[] getFieldTypes() {
        return fieldTypes;
    }

    @Override
    public TableSink<Row> configure(String[] strings, TypeInformation<?>[] typeInformations) {
        BucketingTableSinkNew copy;
        try {
            copy = new BucketingTableSinkNew(InstantiationUtil.clone(format),InstantiationUtil.clone(basePath),InstantiationUtil.clone(dateTimeFormat),InstantiationUtil.clone(zoneId),InstantiationUtil.clone(orcSchema));
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        copy.fieldNames = strings;
        copy.fieldTypes = typeInformations;

        this.fieldNames = strings;
        this.fieldTypes = typeInformations;
        return copy;
    }
}
