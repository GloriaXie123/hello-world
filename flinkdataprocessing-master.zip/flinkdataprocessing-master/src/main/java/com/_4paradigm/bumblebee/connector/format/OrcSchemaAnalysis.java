package com._4paradigm.bumblebee.connector.format;

import org.apache.avro.Schema;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.orc.TypeDescription;

import java.util.ArrayList;
import java.util.List;

/**
 * 目标：将Orc schema转flink table schema，转Avro schema
 */
public class OrcSchemaAnalysis {

    /**
     * 根据Orc Schema String 获得对应的Flink数据类型
     * @param orcSchema
     * @return
     */
    public TypeInformation getFlinkSchema (String orcSchema){
        TypeDescription typeDescription = TypeDescription.fromString(orcSchema);
        TypeInformation type = getFlinkSchema (typeDescription);
        return type;
    }

    /**
     * 根据ORC schme 描述获得 对应的Flink 数据类型
     * @param typeDescription
     * @return
     */
    public TypeInformation getFlinkSchema (TypeDescription typeDescription){
        String CategoryName = typeDescription.getCategory().getName();
        switch (CategoryName){
            case "boolean" : return Types.BOOLEAN;
            case "tinyint" : return Types.SHORT;
            case "smallint" : return Types.SHORT;
            case "int" : return Types.INT;
            case "bigint" : return Types.LONG;
            case "float" : return Types.FLOAT;
            case "double" : return Types.DOUBLE;
            case "string" : return Types.STRING;
            case "date" : return Types.SQL_DATE;
            case "timestamp" : return Types.SQL_TIMESTAMP;
            //case "binary" : return  Types.BINARY;
            // case "decimal" : return  Types.DECIMAL;
            case "varchar" : return Types.STRING;
            case "char" : return Types.STRING;
            case "array" :
                if (typeDescription.getChildren().size() != 1) {//TODO
                    throw new RuntimeException("list 是多种类型的列,正在支持，请使用结构体struct");
                }else {
                    if (typeDescription.getChildren().get(0).getCategory().getName().equals("struct")) {
                        return Types.OBJECT_ARRAY(getFlinkSchema(typeDescription.getChildren().get(0)));
                    } else {//TODO 更多复合复杂类型待验证 支持Types.PRIMITIVE_ARRAY()
                        return Types.LIST(getFlinkSchema(typeDescription.getChildren().get(0)));
                    }
                }
            case "map" :
                throw new RuntimeException("建议使用结构体struct") ;
            case "struct" :
                List<String> fieldNames = typeDescription.getFieldNames();
                String[] fieldNamesCopy = new String[fieldNames.size()];
                for(int i = 0; i < fieldNames.size(); i = i+1){
                    fieldNamesCopy[i] = fieldNames.get(i);
                }
                List<TypeDescription> typeChildren = typeDescription.getChildren();
                TypeInformation[] typeChildrenCopy = new TypeInformation[typeChildren.size()];
                for(int i = 0; i < typeChildren.size(); i = i+1){
                    typeChildrenCopy[i] = getFlinkSchema(typeChildren.get(i));
                }
                return Types.ROW_NAMED(fieldNamesCopy,typeChildrenCopy);
            case "uniontype" :
                throw new RuntimeException("不支持的数据类型") ;
            default :
                throw new RuntimeException("不支持的数据类型");
        }
    }

    /**
     * 根据Orc Schema String 获得对应的AvroSchema
     * @param orcSchema
     * @return
     */
    public Schema getAvroSchema (String orcSchema){
        TypeDescription typeDescription = TypeDescription.fromString(orcSchema);
        List<String> fieldNames = typeDescription.getFieldNames();
        List<TypeDescription> typeChildren = typeDescription.getChildren();

        List<org.apache.avro.Schema.Field> fields = new ArrayList<Schema.Field>();
        for(int i = 0; i < fieldNames.size(); i = i+1){
            fields.add(new org.apache.avro.Schema.Field(fieldNames.get(i), org.apache.avro.Schema.create(getAvroSchema(typeChildren.get(i))), null, null));
        }
        org.apache.avro.Schema schema = org.apache.avro.Schema.createRecord("SY_kafka_To_Parquet", null, null, false, fields);


        return schema;
    }

    /**
     * 根据ORC schme 描述获得 对应的Avro 数据类型
     * @param typeDescription
     * @return
     */
    public Schema.Type getAvroSchema (TypeDescription typeDescription){
        String CategoryName = typeDescription.getCategory().getName();
        switch (CategoryName){
            case "boolean" : return Schema.Type.BOOLEAN;
            case "tinyint" : return Schema.Type.INT;
            case "smallint" : return Schema.Type.INT;
            case "int" : return Schema.Type.INT;
            case "bigint" : return Schema.Type.LONG;
            case "float" : return Schema.Type.FLOAT;
            case "double" : return Schema.Type.DOUBLE;
            case "string" : return Schema.Type.STRING;
            case "date" : return Schema.Type.BYTES;
            case "timestamp" : return Schema.Type.BYTES;
            //case "binary" : return  Types.BINARY;
            // case "decimal" : return  Types.DECIMAL;
            case "varchar" : return Schema.Type.BYTES;
            case "char" : return Schema.Type.BYTES;
            case "array" :
                throw new RuntimeException("不支持的数据类型:"+CategoryName) ;
                /*
                if (typeDescription.getChildren().size() != 1) {//TODO
                    throw new RuntimeException("list 是多种类型的列,正在支持，请使用结构体struct");
                }else {
                    if (typeDescription.getChildren().get(0).getCategory().getName().equals("struct")) {
                        return Schema.Type.ARRAY;
                    } else {//TODO 更多复合复杂类型待验证 支持Types.PRIMITIVE_ARRAY()
                        return Schema.Type.ARRAY;
                    }
                }*/
            case "map" :
                throw new RuntimeException("不支持的数据类型:"+CategoryName) ;
                //return Schema.Type.MAP;
            case "struct" :
                throw new RuntimeException("不支持的数据类型:"+CategoryName) ;
                //return Schema.Type.RECORD;
            case "uniontype" :
                throw new RuntimeException("不支持的数据类型:"+CategoryName) ;
                //return Schema.Type.UNION;
            default :
                throw new RuntimeException("不支持的数据类型:"+CategoryName) ;
        }
    }
}
