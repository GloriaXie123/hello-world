package com._4paradigm.bumblebee.udf;

import com._4paradigm.bumblebee.connector.format.OrcSchemaAnalysis;
import org.apache.flink.api.common.typeinfo.BasicArrayTypeInfo;
import org.apache.flink.api.common.typeinfo.PrimitiveArrayTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.typeutils.ObjectArrayTypeInfo;
import org.apache.flink.api.java.typeutils.RowTypeInfo;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.JsonNode;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.flink.table.functions.TableFunction;
import org.apache.flink.types.Row;
import org.apache.orc.TypeDescription;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.lang.reflect.Array;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

public class LogAnalyzeSwitch2 extends TableFunction<Row> {
    public static final Logger LOG = LoggerFactory.getLogger(LogAnalyzeSwitch2.class);
    ObjectMapper objectMapperK = new ObjectMapper();
    TypeInformation<Row> typeInfo = null;

    public LogAnalyzeSwitch2(String schema) {
        TypeDescription typeDescription = TypeDescription.fromString(schema);
        this.typeInfo =  new OrcSchemaAnalysis().getFlinkSchema(typeDescription);
    }

    public void eval(String value,String key) {
        if(value!=null){
            String str ="{\"level\":\"info\",\"log_id\":\"1568689342760396\",\"msg\":\"[INIT:update flow config]\",\"time\":\"2019-09-17 11:02:22\"}";
            try {
                String jsonValue = value.substring(value.indexOf("{"),value.lastIndexOf("}")+1);
                if(jsonValue!=null){
                    JsonNode root = objectMapperK.readTree(jsonValue.getBytes());
                    JsonNode jnode = root.get("msg");
                    if(jnode!=null){
                        String keyIn = jnode.asText().split(":")[0].toLowerCase();
                        if(keyIn.equals(key.toLowerCase())){
                            String valueSplit = jnode.asText().substring(jnode.asText().indexOf("{"),jnode.asText().lastIndexOf("}")+1);
                            JsonNode root2 = objectMapperK.readTree(valueSplit.getBytes());
                            ObjectNode objectNode = (ObjectNode) root2;
                            if(root2.get("extraParam")!=null){
                                objectNode.put("extraParam",objectMapperK.readTree(root2.get("extraParam").asText().getBytes()));
                            }
                            //System.out.println(objectNode);
                            collect(convertRow(objectNode, (RowTypeInfo) typeInfo));
                        }
                    }
                }
            }catch (Exception err) {
                    System.out.println(key+"\t"+value);
                    //err.printStackTrace();
                    LOG.error("Not json and split fail or schema not match data or not the string"+"\t"+key+"\t"+err.toString());
            }
        }

    }

    @Override
    public TypeInformation<Row> getResultType() {
        return typeInfo;
    }

    private Row convertRow(JsonNode node, RowTypeInfo info) {
        final String[] names = info.getFieldNames();
        final TypeInformation<?>[] types = info.getFieldTypes();

        final Row row = new Row(names.length);
        for (int i = 0; i < names.length; i++) {
            final String name = names[i];
            final JsonNode subNode = node.get(name);
            if (subNode == null) {
                row.setField(i, null);
            } else {
                row.setField(i, convert(subNode, types[i]));
            }
        }
        return row;
    }

    private Object convert(JsonNode node, TypeInformation<?> info) {
        if (info == Types.VOID || node.isNull()) {
            return null;
        } else if (info == Types.BOOLEAN) {
            return node.asBoolean();
        } else if (info == Types.STRING) {
            return node.asText();
        } else if (info == Types.BIG_DEC) {
            return node.decimalValue();
        } else if (info == Types.BIG_INT) {
            return node.bigIntegerValue();
        } else if (info == Types.SQL_DATE) {
            return Date.valueOf(node.asText());
        } else if (info == Types.SQL_TIME) {
            // according to RFC 3339 every full-time must have a timezone;
            // until we have full timezone support, we only support UTC;
            // users can parse their time as string as a workaround
            final String time = node.asText();
            if (time.indexOf('Z') < 0 || time.indexOf('.') >= 0) {
                throw new IllegalStateException(
                        "Invalid time format. Only a time in UTC timezone without milliseconds is supported yet. " +
                                "Format: HH:mm:ss'Z'");
            }
            return Time.valueOf(time.substring(0, time.length() - 1));
        } else if (info == Types.SQL_TIMESTAMP) {
            // according to RFC 3339 every date-time must have a timezone;
            // until we have full timezone support, we only support UTC;
            // users can parse their time as string as a workaround
            final String timestamp = node.asText();
            if (timestamp.indexOf('Z') < 0) {
                throw new IllegalStateException(
                        "Invalid timestamp format. Only a timestamp in UTC timezone is supported yet. " +
                                "Format: yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            }
            return Timestamp.valueOf(timestamp.substring(0, timestamp.length() - 1).replace('T', ' '));
        } else if (info instanceof RowTypeInfo) {
            return convertRow(node, (RowTypeInfo) info);
        } else if (info instanceof ObjectArrayTypeInfo) {
            return convertObjectArray(node, ((ObjectArrayTypeInfo) info).getComponentInfo());
        } else if (info instanceof BasicArrayTypeInfo) {
            return convertObjectArray(node, ((BasicArrayTypeInfo) info).getComponentInfo());
        } else if (info instanceof PrimitiveArrayTypeInfo &&
                ((PrimitiveArrayTypeInfo) info).getComponentType() == Types.BYTE) {
            return convertByteArray(node);
        } else {
            // for types that were specified without JSON schema
            // e.g. POJOs
            try {
                ObjectMapper objectMapper = new ObjectMapper();
                return objectMapper.treeToValue(node, info.getTypeClass());
            } catch (JsonProcessingException e) {
                throw new IllegalStateException("Unsupported type information '" + info + "' for node: " + node);
            }
        }
    }

    private Object convertObjectArray(JsonNode node, TypeInformation<?> elementType) {
        final Object[] array = (Object[]) Array.newInstance(elementType.getTypeClass(), node.size());
        for (int i = 0; i < node.size(); i++) {
            array[i] = convert(node.get(i), elementType);
        }
        return array;
    }

    private Object convertByteArray(JsonNode node) {
        try {
            return node.binaryValue();
        } catch (IOException e) {
            throw new RuntimeException("Unable to deserialize byte array.", e);
        }
    }
}
