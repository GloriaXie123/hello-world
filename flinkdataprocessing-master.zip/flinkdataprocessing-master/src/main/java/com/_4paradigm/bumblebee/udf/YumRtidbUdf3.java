package com._4paradigm.bumblebee.udf;

import com._4paradigm.bumblebee.connector.format.OrcSchemaAnalysis;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.table.functions.TableFunction;
import org.apache.flink.types.Row;
import org.apache.orc.TypeDescription;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class YumRtidbUdf3 extends TableFunction<Row> {
    private static final Logger LOG = LoggerFactory.getLogger(Drill.class);
    private Map<String,String> map ;
    private Map<String, Integer> keyIndexMap;

    String iSalesFlag = "iSalesFlag";
    String showNameCn = "showNameCn";
    String itemLinkids = "itemLinkids";

    String linkId = "linkId";
    String round = "round";
    String price = "price";
    String itemCount = "itemCount";



    public YumRtidbUdf3(Map<String,String> map) {
        this.map = map;
        getIndex();
    }

    public Map<String,Integer> getIndex(){
        keyIndexMap = new HashMap<String,Integer>();
        String store_productSchema = "struct<storeCode:string,channel:string,date:string,linkIds:array<struct<linkId:string,systemId:string,price:int,itemcount:int,iMenuCn:string,iDescCn:string,iSalesFlag:string,validFrom:bigint,validTo:bigint,startTime:bigint,endTime:bigint,showNameCn:string,itemLinkids:array<struct<linkId:string,systemId:string,round:int,price:int,iMenuCn:string,iDescCn:string,iSalesFlag:string,validFrom:bigint,validTo:bigint,startTime:bigint,endTime:bigint,showNameCn:string,quantity:int,itemCount:string>>>>>";
        TypeDescription typeDescription = TypeDescription.fromString(store_productSchema);
        if(typeDescription!=null){
            int linkIdsIndex = getNum(typeDescription,"linkIds");
            TypeDescription typeChild2 = typeDescription.getChildren().get(linkIdsIndex).getChildren().get(0);
            keyIndexMap.put("linkId2",getNum(typeChild2,"linkId"));
            keyIndexMap.put(iSalesFlag,getNum(typeChild2,iSalesFlag));
            keyIndexMap.put(showNameCn,getNum(typeChild2,showNameCn));
            keyIndexMap.put(itemLinkids,getNum(typeChild2,itemLinkids));

            int itemLinkidsIndex = getNum(typeChild2,"itemLinkids");
            TypeDescription typeChild3 = typeChild2.getChildren().get(itemLinkidsIndex).getChildren().get(0);
            keyIndexMap.put(linkId,getNum(typeChild3,linkId));
            keyIndexMap.put(round,getNum(typeChild3,round));
            keyIndexMap.put(price,getNum(typeChild3,price));
            keyIndexMap.put(itemCount,getNum(typeChild3,itemCount));
            return  keyIndexMap;
        }else {
            throw new RuntimeException("未能取到对应的表的schema或schema取出字段index错误，Map： "+map);
        }
    }

    public void eval(Row[] value) {
        try{
            if(value!=null){
                for(int j=0;j<value.length;j++){
                    Row rowOut = value[j];
                    if (rowOut != null
                            && rowOut.getField(keyIndexMap.get(iSalesFlag)).toString().equals("Y")
                        ){
                        Row[] row3 = (Row[])rowOut.getField(keyIndexMap.get(itemLinkids));
                        String linkId2 = (String)rowOut.getField(keyIndexMap.get("linkId2"));
                            if(row3!=null && row3.length>0){
                                StringBuffer linkidStringBuffer = new StringBuffer();
                                StringBuffer roundStringBuffer = new StringBuffer();
                                StringBuffer priceStringBuffer = new StringBuffer();
                                StringBuffer itemCountStringBuffer = new StringBuffer();
                                for(int i=0;i<row3.length;i++){
                                    if(!linkidStringBuffer.toString().equals("") && !roundStringBuffer.toString().equals("")
                                            && !priceStringBuffer.toString().equals("") && !itemCountStringBuffer.toString().equals("")){
                                        linkidStringBuffer.append(",");
                                        roundStringBuffer.append(",");
                                        priceStringBuffer.append(",");
                                        itemCountStringBuffer.append(",");
                                    }
                                    linkidStringBuffer.append(row3[i].getField(keyIndexMap.get(linkId)));
                                    roundStringBuffer.append(row3[i].getField(keyIndexMap.get(round)));
                                    priceStringBuffer.append(row3[i].getField(keyIndexMap.get(price)));
                                    itemCountStringBuffer.append(row3[i].getField(keyIndexMap.get(itemCount)));
                                }
                                if(!linkidStringBuffer.toString().equals("")){
                                    Row outRow = new Row(5);
                                    outRow.setField(0,linkId2);
                                    outRow.setField(1,linkidStringBuffer.toString());
                                    outRow.setField(2,roundStringBuffer.toString());
                                    outRow.setField(3,priceStringBuffer.toString());
                                    outRow.setField(4,itemCountStringBuffer.toString());
                                    collect(outRow);
                                }
                            }
                        }
                    }

            }
        }catch (Exception e){
            LOG.error("Row[] 数据udf处理失败：");
            for(int j=0;j<value.length;j++){
                LOG.error("Row[] 处理失败列值散列："+value[j]);
            }
        }
    }

    @Override
    public TypeInformation<Row> getResultType() {
        String outSchema = "struct<itemlinkid:string,linkids:string,rounds:string,prices:string,itemcounts:string>";
        TypeDescription typeDescription = TypeDescription.fromString(outSchema);
        return new OrcSchemaAnalysis().getFlinkSchema(typeDescription);
    }

    public int getNum(TypeDescription typeDescription,String colum){
        List<String> names = typeDescription.getFieldNames();
        Integer num = null;
        for(int i=0;i<names.size();i++){
            if(names.get(i).equalsIgnoreCase(colum)){
                num = i;
                break;
            }
        }
        if(num == null){
            throw new RuntimeException("Row 中没有此列 :"+colum);
        }
        return num;
    }
}
