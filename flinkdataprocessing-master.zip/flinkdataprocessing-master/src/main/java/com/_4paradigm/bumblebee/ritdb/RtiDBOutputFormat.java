package com._4paradigm.bumblebee.ritdb;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.io.RichOutputFormat;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.types.Row;
import org.apache.flink.util.Preconditions;

/**
 * @author akis on 2019-04-22
 */
@Slf4j
public class RtiDBOutputFormat extends RichOutputFormat<Row> {

    private RtiDBClient client;

    private String tableName;
    private String zkEndpoints;
    private String zkRootPath;
    private String timeColName;
    private String timeFormat;
    /**
     * rtidb 的 table filed name, [x,y,z]
     */
    private String[] tableFiledNames;

    private RtiDBOutputFormat() {}

//    public RtiDBOutputFormat(String tableName, String zkEndpoints, String zkRootPath,
//            String timeColName, String timeFormat) throws IOException, TabletException {
//        this.client = new RtiDBClient(tableName, zkEndpoints, zkRootPath, timeColName, timeFormat);
//    }

    @Override
    public void configure(Configuration parameters) {
        // do nothing here
    }

    @Override
    public void open(int taskNumber, int numTasks) throws IOException {
        try {
            client = new RtiDBClient(tableName, zkEndpoints, zkRootPath, timeColName, timeFormat);
            log.info("rtidb client established");
        } catch (Exception e) {
            log.error("establish connection error", e);
        }
    }

    @Override
    public void writeRecord(Row record) throws IOException {
        // row 转换成 hashmap
        HashMap<String, Object> map = new HashMap<>();
        List<String> keys = Arrays.asList(tableFiledNames);

        if (keys.size() != record.getArity()) {
            throw new RuntimeException("schema not match");
        }
        for (int i = 0; i < keys.size(); i++) {
            map.put(keys.get(i), convert(record.getField(i)));
        }

        long ts = System.currentTimeMillis();

        try {
            ts = parseTime(client, map);
        } catch (Exception e) {
            log.error("parse time error, please check timeColFormat or timeColValue");
            throw new RuntimeException("parse time based data error");
        }

        boolean ok = client.put(ts, map);
        if (ok) {
            log.debug("put success");
        } else {
            log.warn("put error, record {}", map);
        }
    }

    private Object convert(Object obj) {
        if (obj instanceof Byte) {
            Byte objT = (Byte) obj;
            return objT.intValue();
        } else if (obj instanceof BigDecimal) {
            BigDecimal objT = (BigDecimal)obj;
            return objT.doubleValue();
        } else {
            return obj;
        }
    }

    public long parseTime(RtiDBClient client, Map<String, Object> map) throws ParseException {
        long ts = System.currentTimeMillis();
        String timeColName = client.getTimeColName();
        SimpleDateFormat simpleDateFormat = client.getSimpleDateFormat();

        if (!Strings.isNullOrEmpty(timeColName)) {
            Object timeColValue = map.get(timeColName);

            if(timeColValue != null){
                if (simpleDateFormat != null ) {
                    ts = simpleDateFormat.parse((String)timeColValue).getTime();
                } else {
                    ts = (Long) timeColValue;
                }
                if(ts<1000000000){//1562740099
                    log.warn("时间量级小于1000000000，小于2001年09月09日 09:46:40 ，非常可能出现Rtidb数据导入即过期，并且数据无法preview 查到");
                }
            }else{
                log.debug("timeColValue is null");
            }
        }
        return ts;
    }

    @Override
    public void close() throws IOException {
        client.close();
    }


    public static RtiDBOutputFormatBuilder outputFormatBuilder() {
        return new RtiDBOutputFormatBuilder();
    }

    public static class RtiDBOutputFormatBuilder {
        private final RtiDBOutputFormat format;

        private RtiDBOutputFormatBuilder() {
            format = new RtiDBOutputFormat();
        }

        public RtiDBOutputFormatBuilder setTableName(String tableName) {
            format.tableName = tableName;
            return this;
        }

        public RtiDBOutputFormatBuilder setZkEndpoint(String zkEndpoints) {
            format.zkEndpoints = zkEndpoints;
            return this;
        }

        public RtiDBOutputFormatBuilder setZkRootPath(String zkRootPath) {
            format.zkRootPath = zkRootPath;
            return this;
        }

        public RtiDBOutputFormatBuilder setTimeColName(String timeColName) {
            format.timeColName = timeColName;
            return this;
        }

        public RtiDBOutputFormatBuilder setTimeFormat(String timeFormat) {
            format.timeFormat = timeFormat;
            return this;
        }

        public RtiDBOutputFormatBuilder setTableSchema(String[] tableFiledNames) {
            format.tableFiledNames = tableFiledNames;
            return this;
        }

        public RtiDBOutputFormat build() {
            Preconditions.checkNotNull(format.tableName);
            Preconditions.checkNotNull(format.zkEndpoints);
            Preconditions.checkNotNull(format.zkRootPath);
            Preconditions.checkNotNull(format.tableFiledNames);
            return format;
        }
    }

}
