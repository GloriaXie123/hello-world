package com._4paradigm.bumblebee.udf;

import com._4paradigm.bumblebee.connector.format.OrcSchemaAnalysis;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.table.functions.TableFunction;
import org.apache.flink.types.Row;
import org.apache.orc.TypeDescription;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class YumRtidbUdf1 extends TableFunction<Row> {
    private static final Logger LOG = LoggerFactory.getLogger(Drill.class);
    private Map<String,String> map ;
    private Map<String, Integer> keyIndexMap;

    String linkId = "linkId";
    String price = "price";
    String iSalesFlag = "iSalesFlag";
    String showNameCn = "showNameCn";
    String itemLinkids = "itemLinkids";

    public YumRtidbUdf1(Map<String,String> map) {
        this.map = map;
        getIndex();
    }

    public Map<String,Integer> getIndex(){
        keyIndexMap = new HashMap<String,Integer>();
        String store_productSchema = "struct<storeCode:string,channel:string,date:string,linkIds:array<struct<linkId:string,systemId:string,price:int,itemcount:int,iMenuCn:string,iDescCn:string,iSalesFlag:string,validFrom:bigint,validTo:bigint,startTime:bigint,endTime:bigint,showNameCn:string,itemLinkids:array<struct<linkId:string,systemId:string,round:int,price:int,iMenuCn:string,iDescCn:string,iSalesFlag:string,validFrom:bigint,validTo:bigint,startTime:bigint,endTime:bigint,showNameCn:string,quantity:int,itemCount:string>>>>>";
        TypeDescription typeDescription = TypeDescription.fromString(store_productSchema);
        if(typeDescription!=null){
            int linkIdsIndex = getNum(typeDescription,"linkIds");
            TypeDescription typeChild2 = typeDescription.getChildren().get(linkIdsIndex).getChildren().get(0);
            keyIndexMap.put(linkId,getNum(typeChild2,linkId));
            keyIndexMap.put(price,getNum(typeChild2,price));
            keyIndexMap.put(iSalesFlag,getNum(typeChild2,iSalesFlag));
            keyIndexMap.put(showNameCn,getNum(typeChild2,showNameCn));
            keyIndexMap.put(itemLinkids,getNum(typeChild2,itemLinkids));
            return  keyIndexMap;
        }else {
            throw new RuntimeException("未能取到对应的表的schema或schema取出字段index错误，Map： "+map);
        }
    }

    public void eval(Row[] value) {
        try{
            if(value!=null){
                StringBuffer linkidStringBuffer = new StringBuffer();
                StringBuffer priceStringBuffer = new StringBuffer();
                for(int j=0;j<value.length;j++){
                    Row rowOut = value[j];
                    if (rowOut != null
                            && rowOut.getField(keyIndexMap.get(iSalesFlag)).toString().equals("Y")
                            && !(rowOut.getField(keyIndexMap.get(showNameCn)).toString().substring(1,1).equals("C"))
                        ){
                        Row[] row3 = (Row[])rowOut.getField(keyIndexMap.get(itemLinkids));
                            if(row3!=null && row3.length>0){
                                if(!linkidStringBuffer.toString().equals("") && !priceStringBuffer.toString().equals("")){
                                    linkidStringBuffer.append(",");
                                    priceStringBuffer.append(",");
                                }
                                linkidStringBuffer.append(rowOut.getField(keyIndexMap.get(linkId)));
                                priceStringBuffer.append(rowOut.getField(keyIndexMap.get(price)));
                            }
                        }
                    }
                if(!linkidStringBuffer.toString().equals("")){
                    Row outRow = new Row(2);
                    outRow.setField(0,linkidStringBuffer.toString());
                    outRow.setField(1,priceStringBuffer.toString());
                    collect(outRow);
                }
            }
        }catch (Exception e){
            LOG.error("Row[] 数据udf处理失败：");
            for(int j=0;j<value.length;j++){
                LOG.error("Row[] 处理失败列值散列："+value[j]);
            }
        }
    }

    @Override
    public TypeInformation<Row> getResultType() {
        String outSchema = "struct<linkids:string,prices:string>";
        TypeDescription typeDescription = TypeDescription.fromString(outSchema);
        return new OrcSchemaAnalysis().getFlinkSchema(typeDescription);
    }

    public int getNum(TypeDescription typeDescription,String colum){
        List<String> names = typeDescription.getFieldNames();
        Integer num = null;
        for(int i=0;i<names.size();i++){
            if(names.get(i).equalsIgnoreCase(colum)){
                num = i;
                break;
            }
        }
        if(num == null){
            throw new RuntimeException("Row 中没有此列 :"+colum);
        }
        return num;
    }
}
