package com._4paradigm.bumblebee.runner

import com._4paradigm.bumblebee.common.BatchAndStreamRunner
import org.slf4j.LoggerFactory

object JobRunner{
  private val LOG = LoggerFactory.getLogger(JobRunner.getClass)
  def main(args: Array[String]): Unit = {
    BatchAndStreamRunner.run(args);
  }
}