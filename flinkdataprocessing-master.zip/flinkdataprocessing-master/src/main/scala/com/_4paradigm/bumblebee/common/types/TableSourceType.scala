package com._4paradigm.bumblebee.common.types


/**
  * Created by zhanglibing on 2019/3/29
  */

object TableSourceType extends Enumeration {
  type TableSourceType = Value
  val KAFKA = Value("kafka")
  val HDFS = Value("hdfs")
  val HIVE = Value("hive")
  val RTIDB = Value("rtidb")
  val SDP = Value("sdp")

}
