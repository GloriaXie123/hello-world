package com._4paradigm.bumblebee.connector

import java.util
import java.util.{HashMap, Properties, UUID}

import com._4paradigm.bumblebee.connector.format.{FormatTools}
import com.google.common.base.Strings
//import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment
//import org.apache.flink.table.api.java.StreamTableEnvironment
import org.apache.flink.streaming.api.scala._
import org.apache.flink.table.api.scala.StreamTableEnvironment
import org.apache.flink.table.descriptors.Kafka
import org.apache.flink.util.{InstantiationUtil, Preconditions}
import org.slf4j.LoggerFactory

/**
  *  shangyue
  *  目前验证支持kafka的 stream source
  *   待设计验证kafka的 stream sink
  *                   batch source
  *                   batch sink
  */
class KafkaTableConnector extends FormatTools{
  private val LOG = LoggerFactory.getLogger(classOf[KafkaTableConnector])

  val customize = "customize" //自定义，默认开启
  val version = "version"
  val bootstrapServers = "bootstrap.servers"//
  val zookeeperConnect = "zookeeper.connect"//
  val topicName = "topic"
  val groupId = "groupId"//
  val startFrom = "consumeMethod"
  val offSetsJson = "offSetsJson"
  val schema = "schema"
  val tableName = "tableName"

  val uuid = UUID.randomUUID().toString

  def getKafkaTableSourceConnect(see:StreamExecutionEnvironment,tableEnv: StreamTableEnvironment, map: util.HashMap[String, Object]): Unit = {

    //TODO schema非空 空策略
    val schemaValue = getMapValueString(map,schema) //struct<_col0:int,_col1:string,_col2:string,_col3:string,_col4:int,_col5:string,_col6:int,_col7:int,_col8:int>
    var tableNameValue = getMapValueString(map,tableName)
    var customizeValue = getMapValueString(map,customize)

    //tableName为空处理，关键字处理
    if (Strings.isNullOrEmpty(tableNameValue)) {
      if(tableNameValue.equals("table")){
        throw new RuntimeException("避免使用关键字:"+tableNameValue)
      }
      tableNameValue = getMapValueString(map,topicName)
    }
    var customizeBoolean = true
    if(customizeValue!=null){
      try {
        customizeBoolean = java.lang.Boolean.parseBoolean(customizeValue)
      }catch {
        case e:Exception =>{customizeBoolean = true}
      }
    }
    LOG.info("Kafka Connect table格式化 参数   schema:"+schemaValue+"  tableName:"+tableNameValue)

   /* if(customizeBoolean){
      val deserializationSchema = new YumChinaJsonRowDeserializationSchema(
        Types.ROW_NAMED(
          getOrcSchemaName(schemaValue), getOrcSchemaType(schemaValue))//Types.PRIMITIVE_ARRAY(Types.BYTE)
      );

      val topicNameValue = Preconditions.checkNotNull(getMapValueString(map,topicName), "topicName must not be null.")
      var versionValue = getMapValueString(map,version) //"0.8", "0.9", "0.10", "0.11", and "universal"
      val bootstrapServersValue = Preconditions.checkNotNull(getMapValueString(map,bootstrapServers), "bootstrapServers must not be null.")
      val zookeeperConnectValue = getMapValueString(map,zookeeperConnect)
      val groupIdValue = getMapValueString(map,groupId)
      var startFromValue = getMapValueString(map,startFrom)
      val offSetsJsonValue = getMapValueString(map,offSetsJson)
      val properties = new Properties()
      properties.setProperty("bootstrap.servers", bootstrapServersValue);
      if (Strings.isNullOrEmpty(versionValue)) {
        versionValue = "0.11"
      }
      // only required for Kafka 0.8
      if (versionValue.equals("0.8") && !Strings.isNullOrEmpty(zookeeperConnectValue)) {
        properties.setProperty("zookeeper.connect", zookeeperConnectValue)
      }
      if (!Strings.isNullOrEmpty(groupIdValue)) {
        properties.setProperty("group.id", groupIdValue)
      } else {
        //如果groupId为空则赋值为uuid
        //todo UUID
        properties.setProperty("group.id", uuid)
      }
      //如果version为空则赋值为universal
      //startFromValue 默认 latest
      if(startFromValue == null){
        startFromValue = "latest";
      }
      var offSetsMap: java.util.HashMap[Integer, java.lang.Long] = null
      if(startFromValue.equals("specificOffsets") && !Strings.isNullOrEmpty(offSetsJsonValue)){
        offSetsMap = new java.util.HashMap[Integer, java.lang.Long]
        val hashMap: HashMap[String, java.lang.Long] = offSetsJsonValue.asInstanceOf[util.HashMap[String, java.lang.Long]]
        val it = hashMap.keySet().iterator()
        while (it.hasNext) {
          val key = it.next()
          offSetsMap.put(key.toInt, hashMap.get(key))
        }
      }
      //去除所有预先设定的参数，剩余kafka的高级参数 加入kafka的 Properties
      getKafkaAllProperties(map,properties)
      LOG.info("Kafka Connect 连接创建 参数:properties :" + properties + "  version:" + versionValue + "  topicName:" + topicNameValue  + "  startFrom:" + startFromValue + "  offSetsMap:" + offSetsMap)

      var kafkaSource:FlinkKafkaConsumer010[Row] = new FlinkKafkaConsumer010[Row](topicNameValue, deserializationSchema, properties);
      kafkaSource.setStartFromLatest();

      val stream:DataStream[Row]  = see.addSource(kafkaSource)
      //stream 转 Table
      tableEnv.registerDataStream(tableNameValue,stream);
    }else{*/
      tableEnv.connect(
        //kafka connect
        getKafkaConnect(map)
      )
        //必须Format
        .withFormat(getFormat(map)
      )
        //必须Schema
        .withSchema(getSchema(schemaValue)
      )
        .inAppendMode()
        .registerTableSource(tableNameValue)
    //}
  }

  def getKafkaConnect(map: util.HashMap[String, Object]): Kafka = {
    val topicNameValue = Preconditions.checkNotNull(getMapValueString(map,topicName), "topicName must not be null.")
    var versionValue = getMapValueString(map,version) //"0.8", "0.9", "0.10", "0.11", and "universal"
    val bootstrapServersValue = Preconditions.checkNotNull(getMapValueString(map,bootstrapServers), "bootstrapServers must not be null.")
    val zookeeperConnectValue = getMapValueString(map,zookeeperConnect)
    val groupIdValue = getMapValueString(map,groupId)
    var startFromValue = getMapValueString(map,startFrom)
    val offSetsJsonValue = getMapValueString(map,offSetsJson)

    val properties = new Properties()
    properties.setProperty("bootstrap.servers", bootstrapServersValue);
    if (Strings.isNullOrEmpty(versionValue)) {
      versionValue = "0.11"
    }
    // only required for Kafka 0.8
    if (versionValue.equals("0.8") && !Strings.isNullOrEmpty(zookeeperConnectValue)) {
      properties.setProperty("zookeeper.connect", zookeeperConnectValue)
    }
    if (!Strings.isNullOrEmpty(groupIdValue)) {
      properties.setProperty("group.id", groupIdValue)
    } else {
      //如果groupId为空则赋值为uuid
      //todo UUID
      properties.setProperty("group.id", uuid)
    }
    //如果version为空则赋值为universal

    //startFromValue 默认 latest
    if(startFromValue == null){
      startFromValue = "latest";
    }

    var offSetsMap: java.util.HashMap[Integer, java.lang.Long] = null
    if(startFromValue.equals("specificOffsets") && !Strings.isNullOrEmpty(offSetsJsonValue)){
      offSetsMap = new java.util.HashMap[Integer, java.lang.Long]
        val hashMap: HashMap[String, java.lang.Long] = offSetsJsonValue.asInstanceOf[util.HashMap[String, java.lang.Long]]
        val it = hashMap.keySet().iterator()
        while (it.hasNext) {
          val key = it.next()
          offSetsMap.put(key.toInt, hashMap.get(key))
        }
    }

    //去除所有预先设定的参数，剩余kafka的高级参数 加入kafka的 Properties
    getKafkaAllProperties(map,properties)

    LOG.info("Kafka Connect 连接创建 参数:properties :" + properties + "  version:" + versionValue + "  topicName:" + topicNameValue  + "  startFrom:" + startFromValue + "  offSetsMap:" + offSetsMap)

    var kafka = new Kafka()
      .version(versionValue) // required: valid connector versions are   "0.8", "0.9", "0.10", "0.11", and "universal"
      .topic(topicNameValue) // required: topic name from which the table is read
      .properties(properties);
    // optional: connector specific properties
    //TODO checkPoint 和 Offset机制的冲突解决
    kafka = startFromValue match {
      case "earliest" => kafka.startFromEarliest()
      case "latest" => kafka.startFromLatest()
      case "groupOffsets" => kafka.startFromGroupOffsets()
      case "specificOffsets" => kafka.startFromSpecificOffsets(offSetsMap)
      case "" => kafka
    }
    // optional: select a startup mode for Kafka offsets
    //.startFromEarliest()
    //.startFromLatest()
    //.startFromSpecificOffsets(...)

    // optional: output partitioning from Flink's partitions into Kafka's partitions
    //.sinkPartitionerFixed() // each Flink partition ends up in at-most one Kafka partition (default)
    //.sinkPartitionerRoundRobin()    // a Flink partition is distributed to Kafka partitions round-robin
    //.sinkPartitionerCustom(MyCustom.class)    // use a custom FlinkKafkaPartitioner subclass
    return kafka
  }

  def getKafkaAllProperties(map: util.HashMap[String, Object],properties:Properties): Properties = {
    val copyMap = InstantiationUtil.clone(map)
    copyMap.remove(version)
    copyMap.remove(bootstrapServers)
    copyMap.remove(zookeeperConnect)
    copyMap.remove(topicName)
    copyMap.remove(groupId)
    copyMap.remove(startFrom)
    copyMap.remove(offSetsJson)
    copyMap.remove(schema)
    copyMap.remove(tableName)
    copyMap.remove("sourceType")
    copyMap.remove(FORMATTYPE)
    copyMap.remove(FAILONMISSINGFIELD)
    //copyMap.remove(CSVSCHEMA)
    copyMap.remove(FIELDDELIMITER)
    copyMap.remove(LINEDELIMITER)
    copyMap.remove(QUOTECHARACTER)
    //copyMap.remove(COMMENTPREFIX)
    //copyMap.remove(IGNOREFIRSTLINE)
    copyMap.remove(IGNOREPARSEERRORS)
    copyMap.remove(AVROSCHEMA)
    copyMap.remove("timestamp")

    if(copyMap.size()>0){
      properties.putAll(copyMap)
    }
    properties
  }

}

