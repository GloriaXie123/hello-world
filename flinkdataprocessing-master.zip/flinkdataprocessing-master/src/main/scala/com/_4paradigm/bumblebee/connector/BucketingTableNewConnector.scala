package com._4paradigm.bumblebee.connector

import java.time.ZoneId
import java.util

import com._4paradigm.bumblebee.Bucketing.{BucketingTableSink, BucketingTableSinkNew}
import com._4paradigm.bumblebee.connector.format.FormatTools
import org.apache.flink.streaming.connectors.fs.bucketing.{BucketingSink, DateTimeBucketer}
import org.apache.flink.util.Preconditions.checkNotNull
import org.slf4j.LoggerFactory

class BucketingTableNewConnector extends FormatTools {
  private val LOG = LoggerFactory.getLogger(classOf[BucketingTableNewConnector])

  val BASEPATH = "hdfsPrefix"
  val DATETIMEBUCKETER = "dateTimeBucketer"
  val ZONEID = "zoneId"
  val BATCHSIZE = "batchSize"
  val BATCHROLLOVERINTERVAL = "batchRolloverInterval"
  val TABLENAME = "tableName"
  val SCHEMA = "schema"
  val FORMAT = "format"


  def getBucketingTableConnector(map: util.HashMap[String, Object]): BucketingTableSinkNew = {
    val basePathValue = checkNotNull(getMapValueString(map, BASEPATH), "Bucketing 参数 hdfsPrefix 为null")
    var dateTimeBucketerValue = getMapValueString(map, DATETIMEBUCKETER)
    var zoneIdValue: String = getMapValueString(map, ZONEID)

    var batchSizeValue = map.get(BATCHSIZE).asInstanceOf[java.lang.Long] //getMapValueString(map,BATCHSIZE)
    var batchRolloverIntervalValue = map.get(BATCHROLLOVERINTERVAL).asInstanceOf[java.lang.Long] //getMapValueString(map,BATCHROLLOVERINTERVAL)

    val tableNameValue = checkNotNull(getMapValueString(map, TABLENAME), "Bucketing 参数 tableName 为null")
    val orcSchemaValue = checkNotNull(getMapValueString(map, SCHEMA), "Bucketing 参数 schema 为null")

    var formatValue = map.get(FORMAT).asInstanceOf[java.lang.String]
    if (dateTimeBucketerValue == null) {
      dateTimeBucketerValue = "yyyy-MM-dd-HH";
    } //默认一小时一个bucketer
    if (zoneIdValue == null) {
      zoneIdValue = "Asia/Shanghai";
    } //默认时间上海
    if (batchSizeValue == null) {
      batchSizeValue = 1024 * 1024 * 128L
    } //128MB一个批
    if (batchRolloverIntervalValue == null) {
      batchRolloverIntervalValue = 60000L
    } //默认一分钟一个分片

    if(formatValue == null){
      formatValue = "row.tsv"//默认以row tsv类型输出
    }

    LOG.info("Bucketing Table Sink 创建连接 参数: hdfsPrefix:" + basePathValue + " .dateTimeBucketer:" + dateTimeBucketerValue + " .zoneId:" + zoneIdValue + " .batchSize:" + batchSizeValue + " .batchRolloverInterval:" + batchRolloverIntervalValue + " .tableName:" + tableNameValue + " .schema:" + orcSchemaValue)

    //删除base目录
    //val path = new Path(basePathValue);
    //val fs = path.getFileSystem();
    //fs.delete(path, true);

    val fileSystemSink = new BucketingTableSinkNew(formatValue,basePathValue,dateTimeBucketerValue,zoneIdValue,orcSchemaValue)
    fileSystemSink.configure(getOrcSchemaName(orcSchemaValue), getOrcSchemaType(orcSchemaValue));

    //暂时返回的是TableSink，未来会封装成Connector
    return fileSystemSink
  }
}
