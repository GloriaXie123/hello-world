package com._4paradigm.bumblebee.common

import java.util

import com._4paradigm.bumblebee.udf.{Drill, LogAnalyzeSwitch, LogAnalyzeSwitch2, YumRtidbUdf1, YumRtidbUdf2, YumRtidbUdf3}
import com.google.common.base.Strings
//import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
//import org.apache.flink.table.api.EnvironmentSettings;
//import org.apache.flink.table.api.java.StreamTableEnvironment;
import org.apache.flink.streaming.api.scala._
import org.apache.flink.table.api.EnvironmentSettings
import org.apache.flink.table.api.scala.StreamTableEnvironment
import org.apache.flink.runtime.state.filesystem.FsStateBackend
import org.apache.flink.streaming.api.CheckpointingMode
import org.apache.flink.streaming.api.environment.CheckpointConfig
//import org.apache.flink.table.api.java.BatchTableEnvironment
//import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
//import org.apache.flink.table.api.scala.{BatchTableEnvironment, StreamTableEnvironment}
//import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment
//import org.apache.flink.table.api.java.StreamTableEnvironment
import org.slf4j.LoggerFactory

object BatchAndStreamRunner extends BatchTools with StreamTools {
  private val LOG = LoggerFactory.getLogger(BatchAndStreamRunner.getClass)

  def run(args: Array[String]): Unit = {
    if (!validateAndInitParams(args)) {
      throw new RuntimeException("参数格式不正确")
    }

    jobType.toLowerCase match {
      case "stream" => {
        val bsEnv = StreamExecutionEnvironment.getExecutionEnvironment

        if (parallelism != null) {
          bsEnv.setParallelism(parallelism)
        }
        //see.getConfig.setGlobalJobParameters(parameterTool)

        if (!Strings.isNullOrEmpty(checkPointPath)) {
          //启用拓扑检查点容错
          bsEnv.enableCheckpointing(60000)
          bsEnv.setStateBackend(new FsStateBackend(checkPointPath))
          bsEnv.getCheckpointConfig.enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION)
          bsEnv.getCheckpointConfig.setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE)
        } else {
          //flink 1.8.0 默认关闭 已不支持关闭
          //see.getCheckpointConfig.disableCheckpointing()
          //print("如果启用了检查点，则为true，否则为false:"+see.getCheckpointConfig.isCheckpointingEnabled)
        }


        /**
          * Flink 1.9 双环境新创建方式
          * BLINK 版本在 表udf函数 出现bug不兼容，所以仍使用flink版本
          */
        val fsSettings = EnvironmentSettings.newInstance().useOldPlanner().inStreamingMode().build();
        val fsTableEnv = StreamTableEnvironment.create(bsEnv, fsSettings)

        LOG.info("Step1: Define tableSource operator and params is " + createSourceDescriptions)
        initSource(bsEnv,fsTableEnv, createSourceDescriptions())

        LOG.info("Step2: Define tableSink operator and params is " + createSinkDescription)
        initSink(bsEnv,fsTableEnv, createSinkDescription())

        //TODO
        SourceSchemaMap.put("kafka_proxylog","struct<key:string,userCode:string,systemTime:string,promiseTime:string,cityName:string,cityCode:string,storeCode:string,brand:string,transactionId:string,marketCode:string,channel:string,userId:string,bookingType:boolean,openId:string,deviceId:string,isPrime:int,canUsePrime:int,extraParam:struct<address1:string,address2:string,POI_type:string,coordinate_x:float,coordinate_y:float,deliveryTimeOfMap:int,gender:int,iLinkMan:string,deliveryCoupon:int>,shoppingCart:array<struct<linkId:string,sizeId:string,baseId:string,num:string,price:string,realPrice:string,type:string,systemId:string,itemLinkIds:array<struct<linkId:string,sizeId:string,baseId:string,num:string,price:string,addPrice:string,type:string,round:string,systemId:string>>>>>")
        SourceSchemaMap.put("kafka_fusion_proxylog","struct<key:string,userCode:string,systemTime:string,promiseTime:string,cityName:string,cityCode:string,storeCode:string,brand:string,transactionId:string,marketCode:string,channel:string,userId:string,bookingType:boolean,openId:string,deviceId:string,isPrime:int,canUsePrime:int,extraParam:struct<address1:string,address2:string,POI_type:string,coordinate_x:float,coordinate_y:float,deliveryTimeOfMap:int,gender:int,iLinkMan:string,deliveryCoupon:int>,shoppingCart:array<struct<linkId:string,sizeId:string,baseId:string,num:string,price:string,realPrice:string,type:string,systemId:string,itemLinkIds:array<struct<linkId:string,sizeId:string,baseId:string,num:string,price:string,addPrice:string,type:string,round:string,systemId:string>>>>>")

        LOG.info("Step3: udf : " + udfSMap)
        if(udfSMap!=null){
          val keysetIt = udfSMap.keySet.iterator()
          while (keysetIt.hasNext){
            val key = keysetIt.next()
            LOG.info("UDF函数注册   "+key+": "+udfSMap.get(key))
            fsTableEnv.registerFunction(key,new Drill(SourceSchemaMap,udfSMap.get(key)))
          }
        }
        //TODO
        LOG.info("UDF函数注册: LOGANALYZE_Menu:LogAnalyzeSwitch")
        fsTableEnv.registerFunction("LOGANALYZE_Menu",new LogAnalyzeSwitch("struct<key:string,userCode:string,systemTime:string,promiseTime:string,cityName:string,cityCode:string,storeCode:string,brand:string,transactionId:string,marketCode:string,channel:string,userId:string,bookingType:boolean,openId:string,deviceId:string,isPrime:int,canUsePrime:int,extraParam:struct<address1:string,address2:string,POI_type:string,coordinate_x:float,coordinate_y:float,deliveryTimeOfMap:int,gender:int,iLinkMan:string,deliveryCoupon:int>>"))
        LOG.info("UDF函数注册: LOGANALYZE_Tradeup:LogAnalyzeSwitch")
        fsTableEnv.registerFunction("LOGANALYZE_Tradeup",new LogAnalyzeSwitch("struct<key:string,userCode:string,systemTime:string,promiseTime:string,cityName:string,cityCode:string,storeCode:string,brand:string,transactionId:string,marketCode:string,channel:string,userId:string,bookingType:boolean,openId:string,deviceId:string,isPrime:int,canUsePrime:int,extraParam:struct<address1:string,address2:string,POI_type:string,coordinate_x:float,coordinate_y:float,deliveryTimeOfMap:int,gender:int,iLinkMan:string,deliveryCoupon:int>,shoppingCart:array<struct<linkId:string,sizeId:string,baseId:string,num:string,price:string,realPrice:string,type:string,systemId:string,itemLinkIds:array<struct<linkId:string,sizeId:string,baseId:string,num:string,price:string,addPrice:string,type:string,round:string,systemId:string>>>>>"))
        LOG.info("UDF函数注册: LOGANALYZE_Menu:LogAnalyzeSwitch2")
        fsTableEnv.registerFunction("LOGANALYZE2_Menu",new LogAnalyzeSwitch2("struct<key:string,userCode:string,systemTime:string,promiseTime:string,cityName:string,cityCode:string,storeCode:string,brand:string,transactionId:string,marketCode:string,channel:string,userId:string,bookingType:boolean,openId:string,deviceId:string,isPrime:int,canUsePrime:int,extraParam:struct<address1:string,address2:string,POI_type:string,coordinate_x:float,coordinate_y:float,deliveryTimeOfMap:int,gender:int,iLinkMan:string,deliveryCoupon:int>>"))
        LOG.info("UDF函数注册: LOGANALYZE_Tradeup:LogAnalyzeSwitch2")
        fsTableEnv.registerFunction("LOGANALYZE2_Tradeup",new LogAnalyzeSwitch2("struct<key:string,userCode:string,systemTime:string,promiseTime:string,cityName:string,cityCode:string,storeCode:string,brand:string,transactionId:string,marketCode:string,channel:string,userId:string,bookingType:boolean,openId:string,deviceId:string,isPrime:int,canUsePrime:int,extraParam:struct<address1:string,address2:string,POI_type:string,coordinate_x:float,coordinate_y:float,deliveryTimeOfMap:int,gender:int,iLinkMan:string,deliveryCoupon:int>,shoppingCart:array<struct<linkId:string,sizeId:string,baseId:string,num:string,price:string,realPrice:string,type:string,systemId:string,itemLinkIds:array<struct<linkId:string,sizeId:string,baseId:string,num:string,price:string,addPrice:string,type:string,round:string,systemId:string>>>>>"))

        LOG.info("UDF函数注册: RTIDBUDF1:YumRtidbUdf1")
        fsTableEnv.registerFunction("RTIDBUDF1",new YumRtidbUdf1(SourceSchemaMap))
        LOG.info("UDF函数注册: RTIDBUDF2:YumRtidbUdf2")
        fsTableEnv.registerFunction("RTIDBUDF2",new YumRtidbUdf2(SourceSchemaMap))
        LOG.info("UDF函数注册: RTIDBUDF3:YumRtidbUdf3")
        fsTableEnv.registerFunction("RTIDBUDF3",new YumRtidbUdf3(SourceSchemaMap))

        LOG.info("Step4: TransformDescription table sql is " + createTransformDescription)
        val transformObject: util.ArrayList[String] = createTransformDescription

        for( i <- 0 to transformObject.size()-1){
          fsTableEnv.sqlUpdate(transformObject.get(i))
        }

        try {
          bsEnv.execute(jobName)
        }catch {
          case e: Exception => {
            LOG.error("程序运行中出现错误")
            e.printStackTrace()
          }
        }
      }
      case "batch" => {
       /* val bEnv = ExecutionEnvironment.getExecutionEnvironment
        if (parallelism != null) {
          bEnv.setParallelism(parallelism)
        }
        //see.getConfig.setGlobalJobParameters(parameterTool)
        //see.setJobType(JobType.BATCH)

        // create a TableEnvironment for batch queries
        val tableEnv = BatchTableEnvironment.create(bEnv)

        LOG.info("Step1: Define tableSource operator and params is " + createSourceDescriptions)
        initBatchSource(tableEnv, createSourceDescriptions())

        LOG.info("Step2: TransformDescription table sql is " + createTransformDescription)
        val transformObject: TransformDescription = null
        val sql: String = transformObject.description.get("sql").toString
        val table= tableEnv.sqlQuery(sql)
        LOG.info(table.getSchema.toString)

        //table.print()

        LOG.info("Step3: Define tableSink operator and params is " + createSinkDescription)
        initBatchSink(table, createSinkDescription())
        try {
          bEnv.execute(jobName)
        }catch {
          case e: Exception => {
            LOG.error("程序运行中出现错误")
            e.printStackTrace()
          }
        }*/
      }
      case _ => {
        throw new RuntimeException("目前只支持stream，batch两种计算模式")
      }
    }
  }
}
