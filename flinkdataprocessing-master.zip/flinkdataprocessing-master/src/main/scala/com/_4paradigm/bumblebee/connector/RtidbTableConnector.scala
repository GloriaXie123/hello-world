package com._4paradigm.bumblebee.connector

import java.util

import com._4paradigm.bumblebee.connector.format.FormatTools
import com._4paradigm.bumblebee.ritdb.{RtiDBOutputFormat, RtiDBTableSink}
import org.slf4j.LoggerFactory
import org.apache.flink.util.Preconditions.checkNotNull

/**
  * shangyue
  * 目前支持rtidb的 batch,stream  sink
  *   按条插入
  * 待设计
  * 不需要 format
  *
  */
class RtidbTableConnector extends FormatTools{

  private val LOG = LoggerFactory.getLogger(classOf[RtidbTableConnector])

  val zkEndpoint = "zkEndpoint"
  val zkRootPath = "zkRootPath"
  val tableName = "tableName"
  val timeColumn = "timeColumn"
  val timeColumnFormat = "timeColumnFormat"
  val schema = "schema"


  def getRtidbTableSinkConnect(map:util.HashMap[String,Object]): RtiDBTableSink = {
    val zkEndpointValue = checkNotNull(getMapValueString(map,zkEndpoint),"Rtidb 参数 zkEndpoint 为null")
    val zkRootPathValue = checkNotNull(getMapValueString(map,zkRootPath),"Rtidb 参数 zkRootPath 为null")
    val tableNameValue = checkNotNull(getMapValueString(map,tableName),"Rtidb 参数 tableName 为null")
    var timeClomeValue:String  = getMapValueString(map,timeColumn)
    var timeClomeFormatValue:String  = getMapValueString(map,timeColumnFormat)
    val tableSchemaValue = checkNotNull(getMapValueString(map,schema),"Rtidb 参数 schema 为null")


    LOG.info("Rtidb Sink 创建连接 参数: zkEndpoint:"+zkEndpointValue+" .zkRootPath:"+zkRootPathValue+" .tableName:" +tableNameValue+" .timeColumn:" +timeClomeValue+" .timeColumnFormat:" +timeClomeFormatValue+" .tableSchemaValue:" +tableSchemaValue)

    //LOG.info("Rtidb Table Sink 参数: Name:"+getOrcSchemaName(tableSchemaValue).foreach(_ =>print(_))+" .Type:"+getOrcSchemaType(tableSchemaValue).foreach(_ =>print(_)))

    val names = getOrcSchemaName(tableSchemaValue)
    val trpes = getOrcSchemaType(tableSchemaValue)

    val rtiDBOutputFormat = RtiDBOutputFormat.outputFormatBuilder()
      .setTableName(tableNameValue)
      .setZkEndpoint(zkEndpointValue)
      .setZkRootPath(zkRootPathValue)
      .setTableSchema(names)
      .setTimeColName(timeClomeValue)
      .setTimeFormat(timeClomeFormatValue)
      .build();

    //目前是以OutputFormat描述Sink的方式
    var rtiDBTableSink = new RtiDBTableSink(rtiDBOutputFormat);
    rtiDBTableSink.configure(names,trpes)

    //暂时返回的是TableSink，未来会封装成Connector
    return rtiDBTableSink

  }

}
