package com._4paradigm.bumblebee.common

import java.util

import com._4paradigm.bumblebee.connector.{FileSystemTableConnector, HiveTableConnector, OrcFileTableConnector, RtidbTableConnector}
import org.apache.flink.table.api.java._
import org.apache.flink.table.api.{Table, TableSchema}
//import org.apache.flink.table.api.scala._
import org.slf4j.LoggerFactory

/**
  * Created by zhanglibing on 2019/3/29
  * straam 与 batch 分开主要是因为 流和批支持的source和sink不一样
  */

trait BatchTools extends Tools {

  private val LOG = LoggerFactory.getLogger(classOf[BatchTools])

  def initBatchSource(tableEnv:BatchTableEnvironment,sourcedescriptionList: List[SourceDescription]): Unit = {
    for (sourceDescription <- sourcedescriptionList) {
      val sourceObject:util.HashMap[String,Object] = sourceDescription.description
      val source:String = getMapValueString(sourceObject,SOURCETYPE).toLowerCase
      source match  {
        case "hive" => {
          //new HiveTableConnector().getHiveTableSourceConnect(tableEnv,sourceObject)
        }
        case "orc" => {
          new OrcFileTableConnector().getOrcFileTableSourceConnect(tableEnv,sourceObject)
        }
          //TODO 支持更多格式的FileSystemTable，目前只支持csv
        case "FileSystem" => {
          new FileSystemTableConnector().getFileSystemTableSourceConnect(tableEnv,sourceObject)
        }
        case _ => {
          LOG.error("batch暂不支持其他格式数据源Source 目前仅支持配置hive orc FileSystem")
        }
      }
    }
  }

  def initBatchSink(table :Table , sinkDescriptionList: List[SinkDescription]): Unit = {
    val tableSchema : TableSchema= table.getSchema
    for (sinkDescription <- sinkDescriptionList) {
      val sinkObject:util.HashMap[String,Object] = sinkDescription.description
      val sink:String = getMapValueString(sinkObject,SINKTYPE).toLowerCase
      sink match  {
        case "rtidb" => {
          val rtidbSink = new RtidbTableConnector().getRtidbTableSinkConnect(sinkObject)
          //table.writeToSink(rtidbSink);
        }
        case _ => {
          LOG.error("batch暂不支持其他格式数据源sink 目前仅支持配置rtidb")
        }
      }
    }

  }
}
