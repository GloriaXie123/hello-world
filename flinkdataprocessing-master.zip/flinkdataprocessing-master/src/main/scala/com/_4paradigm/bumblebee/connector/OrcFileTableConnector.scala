package com._4paradigm.bumblebee.connector

import java.io.IOException
import java.util

import org.apache.flink.orc.OrcTableSource
import org.apache.flink.table.api.java.BatchTableEnvironment
//import org.apache.flink.table.api.BatchTableEnvironment
import org.apache.flink.util.Preconditions
import org.slf4j.LoggerFactory
//import org.apache.hadoop.conf.Configuration
//import org.apache.hadoop.fs.Path
import org.apache.orc.OrcFile
import org.apache.orc.Reader
/**
  * shangyue
  * 目前支持orc的 batch source
  * 待设计：3类
  * 需要验证：在standlong环境配置连接集群时，能否找到系统文件
  * 不需要format
  *
  */
class OrcFileTableConnector {
  private val LOG = LoggerFactory.getLogger(classOf[OrcFileTableConnector])

  val hdfsPath = "hdfsPath"
  val schema = "schema"
  val tableName = "tableName"

  def getOrcFileTableSourceConnect(tableEnv: BatchTableEnvironment, map: util.HashMap[String, Object]): Unit = {

    val hdfsPathValue = Preconditions.checkNotNull(getMapValueString(map,hdfsPath), "ORC Path must not be null.")
    var schemaValue:String = null
    schemaValue = getMapValueString(map,schema)
    if(getMapValueString(map,schema)==null){
      //直接读取ORC文件的schema
      //val conf = new Configuration();
      var reader: Reader = null;
      try {
        //reader = OrcFile.createReader(new Path(hdfsPathValue),OrcFile.readerOptions(conf));
      } catch  {
        case e: IOException =>{e.printStackTrace()}
      }
    }
    val tableNameValue = Preconditions.checkNotNull(getMapValueString(map,tableName), "tableName must not be null.")

    LOG.info("orc Connect table格式化 参数 hdfsPathValue："+hdfsPathValue + " schemaValue:"+schemaValue)

    val orc = OrcTableSource.builder()
      .path(hdfsPathValue, true)
      .forOrcSchema(schemaValue)
      .build()

    tableEnv.registerTableSource(tableNameValue, orc);
  }

  def getMapValueString(map:util.HashMap[String,Object],key : String): String = {
    var value = map.get(key)
    if(value ==null || value.equals("")){
      null
    }else{
      value.toString
    }
  }
}
