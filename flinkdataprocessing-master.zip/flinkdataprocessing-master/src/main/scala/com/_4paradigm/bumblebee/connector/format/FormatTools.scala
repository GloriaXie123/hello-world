package com._4paradigm.bumblebee.connector.format

import java.util

import org.apache.flink.api.common.typeinfo.TypeInformation
import org.apache.flink.table.api.Types
import org.apache.flink.table.descriptors._
import org.apache.flink.util.Preconditions
import org.apache.orc.TypeDescription
//import org.apache.orc.TypeDescription
import org.slf4j.LoggerFactory

/**
  * shangyue
  * 目前 connector 支持 json csv avro
  */
class FormatTools {

  val FORMATTYPE = "format"
  val JSON = "json"
  val FAILONMISSINGFIELD = "failOnMissingField"
  val CSV = "csv"
  //val SCHEMA = "schema"
  //val DERIVESCHEMA = "deriveSchema"
  val FIELDDELIMITER = "fieldDelimiter"
  val LINEDELIMITER = "lineDelimiter"
  val QUOTECHARACTER = "quoteCharacter"
  val ALLOWCOMMENTS = "allowComments"
  val IGNOREPARSEERRORS = "ignoreParseErrors"
  val ARRAYELEMENTDELIMITER = "arrayElementDelimiter"
  val ESCAPECHARACTER = "escapeCharacter"
  val NULLLITERAL = "nullLiteral"
  val AVRO = "avro"
  val AVROSCHEMA = "avroSchema"


  private val LOG = LoggerFactory.getLogger(classOf[FormatTools])

  def getFormat(formatMap: util.HashMap[String,Object]): FormatDescriptor = {
    val formatTypeVlaue = Preconditions.checkNotNull(getMapValueString(formatMap,FORMATTYPE), "{} must not be null."+FORMATTYPE).toLowerCase
    if (formatTypeVlaue.equals(JSON)) {
      val failOnMissingFieldValue  = formatMap.get(FAILONMISSINGFIELD)
      var json = new Json()
      if(failOnMissingFieldValue != null){//ignoreParseErrorsValue.asInstanceOf[Boolean]
        json = json.failOnMissingField(failOnMissingFieldValue.asInstanceOf[Boolean]) //// optional: flag whether to fail if a field is missing or not, false by default
      }
      //3种方式，选用自动的
      // required: define the schema either by using type information which parses numbers to corresponding types
      //.schema(Type.ROW(...))

      // or by using a JSON schema which parses to DECIMAL and TIMESTAMP
      /* .jsonSchema(
         "{" +
           "  type: 'object'," +
           "  properties: {" +
           "    lon: {" +
           "      type: 'number'" +
           "    }," +
           "    rideTime: {" +
           "      type: 'string'," +
           "      format: 'date-time'" +
           "    }" +
           "  }" +
           "}"
       )*/

      // or use the table's schema
        json = json.deriveSchema()
      LOG.info("对数据源进行 Json format： " +json.toString)
      return  json

    } else if (formatTypeVlaue.equals(CSV)) {
      val fieldDelimiterValue = getMapValueString(formatMap,FIELDDELIMITER)
      val lineDelimiterValue = getMapValueString(formatMap,LINEDELIMITER)
      val quoteCharacterValue = getMapValueString(formatMap,QUOTECHARACTER)
      val allowCommentsValue = formatMap.get(ALLOWCOMMENTS)
      val ignoreParseErrorsValue = formatMap.get(IGNOREPARSEERRORS)
      val arrayElementDelimiterValue = getMapValueString(formatMap,ARRAYELEMENTDELIMITER)
      val escapeCharacterValue = getMapValueString(formatMap,ESCAPECHARACTER)
      val nullLiteralValue = getMapValueString(formatMap,NULLLITERAL)


      /**
      var csv = new OldCsv()
      csv = getSchemaCsv(csvSchemaValue,csv)
      if(fieldDelimiterValue!=null){
        csv = csv.fieldDelimiter(fieldDelimiterValue)     // optional: string delimiter "," by default
      }
      if(lineDelimiterValue!=null){
        csv = csv.lineDelimiter(lineDelimiterValue)       // optional: string delimiter "\n" by default
      }
      if(quoteCharacterValue!=null){
        csv = csv.quoteCharacter(quoteCharacterValue.charAt(0))    // optional: single character for string values, empty by default
      }
      if(commentPrefixValue!=null){
        csv = csv.commentPrefix(commentPrefixValue)        // optional: string to indicate comments, empty by default
      }
      if(ignoreFirstLineValue!=null && ignoreFirstLineValue.asInstanceOf[Boolean]){  // optional: ignore the first line, by default it is not skipped
        csv = csv.ignoreFirstLine()
      }
      if(ignoreParseErrorsValue!=null && ignoreParseErrorsValue.asInstanceOf[Boolean]){   // optional: skip records with parse error instead of failing by default
        csv = csv.ignoreParseErrors()
      }**/

      var csv = new Csv().deriveSchema()
      if(fieldDelimiterValue!=null){
        csv = csv.fieldDelimiter(fieldDelimiterValue.charAt(0))
      }
      if(lineDelimiterValue!=null){
        csv = csv.lineDelimiter(lineDelimiterValue)       // optional: string delimiter "\n" by default
      }
      if(quoteCharacterValue!=null){
        csv = csv.quoteCharacter(quoteCharacterValue.charAt(0))    // optional: single character for string values, empty by default
      }
      if(allowCommentsValue!=null && allowCommentsValue.asInstanceOf[Boolean]){
        csv = csv.allowComments()             // optional: ignores comment lines that start with '#' (disabled by default);
      }
      if(ignoreParseErrorsValue!=null && ignoreParseErrorsValue.asInstanceOf[Boolean]){
        csv = csv.ignoreParseErrors()         // optional: skip fields and rows with parse errors instead of failing;
      }
      if(arrayElementDelimiterValue!=null ){  // optional: ignore the first line, by default it is not skipped
        csv = csv.arrayElementDelimiter(arrayElementDelimiterValue)  // optional: the array element delimiter string for separating
      }
      if(escapeCharacterValue!=null ){  // optional: ignore the first line, by default it is not skipped
        csv = csv.escapeCharacter(escapeCharacterValue.charAt(0))       // optional: escape character for escaping values (disabled by default)
      }
      if(nullLiteralValue!=null ){  // optional: ignore the first line, by default it is not skipped
        csv = csv.nullLiteral(nullLiteralValue)
      }

      LOG.info("对数据源进行 Csv format： " +csv.toString)

      return  csv

    } else if(formatTypeVlaue.equals(AVRO)){
      //2种方式，舍弃recordClass获得schema的方式
      val avroSchemaValue = Preconditions.checkNotNull(getMapValueString(formatMap,AVROSCHEMA), "{} must not be null."+AVROSCHEMA)
      val avro = new Avro()
        // required: define the schema either by using an Avro specific record class
        //.recordClass(User.class)
        // or by using an Avro schema
        .avroSchema(avroSchemaValue)
      /*println("对数据源进行 Avro format： "
        +" avroSchemaValue： "+avroSchemaValue
        +" Avro："+avro.toString)*/
      LOG.info("对数据源进行 Avro format： " +avro.toString)
      return avro
    }else {
      throw new RuntimeException("不支持的Format格式 暂时支持 csv json avro 三种格式")
    }
  }

  def getMapValueString(map:util.HashMap[String,Object],key : String): String = {
    var value = map.get(key)
    if(value ==null || value.equals("")){
      null
    }else{
      value.toString
    }
  }

  //解析schema  schema格式参考orc schema格式
  //struct<_col0:int,_col1:string,_col2:string,_col3:string,_col4:int,_col5:string,_col6:int,_col7:int,_col8:int>
  def getSchemaCsv(schemaValue: String,csv:OldCsv): OldCsv = {
    val typeDescription = TypeDescription.fromString(schemaValue)
    val fieldNames = typeDescription.getFieldNames
    val types = typeDescription.getChildren
    var newCsv = csv
    for (i <- 0 to fieldNames.size() - 1) {
      newCsv = newCsv.field(fieldNames.get(i), switchType(types.get(i).toString))
    }
    return newCsv
  }

  //解析schema  schema格式参考orc schema格式
  //struct<_col0:int,_col1:string,_col2:string,_col3:string,_col4:int,_col5:string,_col6:int,_col7:int,_col8:int>
  def getSchema(schemaValue: String): Schema = {
    val typeDescription = TypeDescription.fromString(schemaValue)
    val fieldNames = typeDescription.getFieldNames
    val types = typeDescription.getChildren
    var schema = new Schema()
    for (i <- 0 to fieldNames.size() - 1) {
      schema = schema.field(fieldNames.get(i), switchType(types.get(i).toString))
    }
    return schema
  }
  //getOrcSchemaName
  def getOrcSchemaName(schemaValue: String): Array[String] = {
    val typeDescription = TypeDescription.fromString(schemaValue)
    var fieldNames:util.List[String] = typeDescription.getFieldNames();
    var fieldNamesCopy = new Array[String](fieldNames.size())
    for(i <- 0 to fieldNames.size() - 1){
      fieldNamesCopy(i) = fieldNames.get(i);
    }
    return fieldNamesCopy
  }
  //getOrcSchemaType
  def getOrcSchemaType(schemaValue: String): Array[TypeInformation[_]] = {
    val typeDescription = TypeDescription.fromString(schemaValue)
    var fieldTypes:util.List[TypeDescription] = typeDescription.getChildren();
    var fieldTypesCopy = new Array[TypeInformation[_]](fieldTypes.size())
    for(i <- 0 to fieldTypes.size() - 1){
      fieldTypesCopy(i) = switchType(fieldTypes.get(i).toString);
    }
    return fieldTypesCopy
  }


  // TODO:  ORC schema数据类型 转 flink数据类型

  def switchType(x: String): TypeInformation[_] = x match {
    case "boolean" => Types.BOOLEAN
    case "tinyint" => Types.SHORT  //TODO check
    case "smallint" => Types.SHORT
    case "int" => Types.INT
    case "bigint" => Types.LONG
    case "float" => Types.FLOAT
    case "double" => Types.DOUBLE
    case "string" => Types.STRING
    case "date" => Types.SQL_DATE
    case "timestamp" => Types.SQL_TIMESTAMP
    //case "binary" => Types.BINARY
    case "decimal" => Types.DECIMAL
    case "varchar" => Types.STRING
    case "char" => Types.STRING
    case "array" => null
    case "map" => null
    case "struct" => throw new RuntimeException("不支持的数据类型："+x)
    case "uniontype" => throw new RuntimeException("不支持的数据类型："+x)
    case _ => throw new RuntimeException("不支持的数据类型："+x)
  }


  /**
  def switchTypeflind(typeDescription: TypeDescription): TypeInformation[_] = typeDescription.getCategory().getName() match {
    case "boolean" => Types.BOOLEAN
    case "tinyint" => Types.SHORT  //TODO check
    case "smallint" => Types.SHORT
    case "int" => Types.INT
    case "bigint" => Types.LONG
    case "float" => Types.FLOAT
    case "double" => Types.DOUBLE
    case "string" => Types.STRING
    case "date" => Types.SQL_DATE
    case "timestamp" => Types.SQL_TIMESTAMP
    //case "binary" => Types.BINARY
    //case "decimal" => Types.DECIMAL
    case "varchar" => Types.STRING
    case "char" => Types.STRING
    case "array" => {
      if (typeDescription.getChildren().size() != 1) { //TODO
        throw new RuntimeException("list 是多种类型的列,正在支持，请使用结构体struct");
      } else {
        if (typeDescription.getChildren().get(0).getCategory().equals("struct")) {
          return Types.OBJECT_ARRAY(switchTypeflind(typeDescription.getChildren().get(0)));
        } else { //TODO 更多复合复杂类型待验证 支持Types.PRIMITIVE_ARRAY()
          return Types.PRIMITIVE_ARRAY(switchTypeflind(typeDescription.getChildren().get(0)));
        }
      }
    }
    case "map" => throw new RuntimeException("建议使用结构体struct")
    case "struct" => {
      var fieldNames:util.List[String] = typeDescription.getFieldNames();
      var fieldNamesCopy = new Array[String](fieldNames.size);
      for(i <- 0 to fieldNames.size() - 1){
        fieldNamesCopy(i) = fieldNames.get(i);
      }
      var typeChildren:util.List[TypeDescription] = typeDescription.getChildren();
      var typeChildrenCopy =  new Array[TypeInformation[_]](typeChildren.size)
      for(i <- 0 to fieldNames.size() - 1){
        //TypeDescription sd =
        typeChildrenCopy(i) = switchTypeflind(typeChildren.get(i));
      }//fieldNames: Array[String], types: Array[TypeInformation[_]]
      return Types.ROW_NAMED(fieldNamesCopy,Types.(typeChildrenCopy));
    }
    case "uniontype" => throw new RuntimeException("不支持的数据类型")
    case _ =>  throw new RuntimeException("不支持的数据类型")
  }
    */

}
