package com._4paradigm.bumblebee.connector

import java.util

import com._4paradigm.bumblebee.connector.format.FormatTools
import com._4paradigm.bumblebee.parquet.{ParquetBucketingOutputFormat, ParquetBucketingSinkFuntion, ParquetBuketingTableSink}
import org.slf4j.LoggerFactory
import org.apache.flink.util.Preconditions.checkNotNull
import org.apache.parquet.hadoop.metadata.CompressionCodecName

/**
  * shangyue
  * 为了解决 stram 流数据 化批 输出成parquet文件的自定义sink
  *
  */
class ParquetBucketingTableConnector extends FormatTools {

  private val LOG = LoggerFactory.getLogger(classOf[ParquetBucketingTableConnector])

  /**
    * path
    * compression: CompressionCodecName, CompressionCodecName.UNCOMPRESSED
    * blockSize: Int,  128 * 1024 * 1024
    * enableDictionary: Boolean, false
    * filePrefixName: String "parquet-"
    */
  val SERVERURL = "telamonHost"
  val ACCESSKEY = "accessKey"
  val WORKSPACEID = "workspaceId"
  val PATH = "hdfsPrefix"
  val GROUPPRN = "groupPrn"
  val TIMELENGTH = "timeLength"
  val BLOCKSIZE = "blockSize"
  val FILEPREFIXNAME = "filePrefixName"
  val ENABLEDICTIONARY= "enableDictionary"
  val COMPRESSION = "compression"
  val TABLENAME = "tableName"
  val SCHEMA = "schema"

  def getPDMSSinkConnect(map:util.HashMap[String,Object]): ParquetBuketingTableSink = {
    val serverUrlValue = checkNotNull(getMapValueString(map,SERVERURL),"pdms 参数 serverUrl 为null")
    val accessKeyValue = checkNotNull(getMapValueString(map,ACCESSKEY),"pdms 参数 accessKey 为null")
    val workspaceIdValue = Integer.parseInt(checkNotNull(getMapValueString(map,WORKSPACEID),"pdms 参数 workspaceId 为null"))
    val pathValue = checkNotNull(getMapValueString(map,PATH),"pdms 参数 path 为null")
    val groupPrnValue = checkNotNull(getMapValueString(map,GROUPPRN),"pdms 参数 groupPrn 为null")
    val blockSizeStringValue = getMapValueString(map,BLOCKSIZE)
    val tableNameValue = checkNotNull(getMapValueString(map, TABLENAME), "Bucketing 参数 tableName 为null")
    val schemaValue = checkNotNull(getMapValueString(map, SCHEMA), "Bucketing 参数 schema 为null")
    //按kb计量
    var blockSizeValue = 128 * 1024 * 1024
    if(blockSizeStringValue!=null){
      blockSizeValue =  Integer.parseInt(blockSizeStringValue) * 1024
    }
    //按秒计量
    val timeLengthStringValue = getMapValueString(map,TIMELENGTH)
    var timeLengthValue = 60*60*1000L
    if(timeLengthStringValue!=null){
      timeLengthValue = java.lang.Long.parseLong(timeLengthStringValue)*1000
    }

    var filePrefixNameaStringValue  = getMapValueString(map,FILEPREFIXNAME)
    if (filePrefixNameaStringValue == null){
      filePrefixNameaStringValue = "parquet-"
    }
    val enableDictionaryStringValue = getMapValueString(map,ENABLEDICTIONARY)
    var enableDictionaryValue =false
    if(enableDictionaryStringValue != null){
      enableDictionaryValue = java.lang.Boolean.parseBoolean(enableDictionaryStringValue)
    }
    val compressionStringValue = getMapValueString(map,COMPRESSION)
    var compressionValue = CompressionCodecName.SNAPPY
    if(compressionStringValue != null){
      compressionValue=compressionStringValue match  {
        case "UNCOMPRESSED"=> CompressionCodecName.UNCOMPRESSED
        case "SNAPPY"=>  CompressionCodecName.SNAPPY
        case "GZIP"=>  CompressionCodecName.GZIP
        case "LZO"=>  CompressionCodecName.LZO
        case "BROTLI"=>  CompressionCodecName.BROTLI
        case "LZ4"=>  CompressionCodecName.LZ4
        case "ZSTD"=>  CompressionCodecName.ZSTD
        case _=> {
          LOG.error("错误的压缩编解码器名称，使用默认SNAPPY进行编码，请使用（UNCOMPRESSED，SNAPPY，GZIP，LZO，BROTLI，LZ4，ZSTD）")
          CompressionCodecName.SNAPPY }
      }
    }

    //LOG.info("PDMS parquet Sink 创建参数: {}:{} ,{}:{} ,{}:{} {}:{} ,{}:{} ,{}:{} ,{}:{} ,{}:{} ,{}:{} ,{}:{}",
      //SERVERURL ,serverUrlValue, ACCESSKEY,accessKeyValue, WORKSPACEID,workspaceIdValue.toString,PATH,pathValue,GROUPPRN,groupPrnValue, TIMELENGTH,timeLengthStringValue,
      //BLOCKSIZE,blockSizeValue,toString, FILEPREFIXNAME,filePrefixNameaStringValue,ENABLEDICTIONARY,enableDictionaryValue.toString,COMPRESSION,compressionStringValue)

    val stream2ParquetOutputForma = new ParquetBucketingOutputFormat(serverUrlValue,accessKeyValue,workspaceIdValue,pathValue,groupPrnValue,getOrcSchemaType(schemaValue),getOrcSchemaName(schemaValue),compressionValue,blockSizeValue,enableDictionaryValue,filePrefixNameaStringValue,timeLengthValue)
    val stream2ParquetTableSink = new ParquetBuketingTableSink(stream2ParquetOutputForma);
    stream2ParquetTableSink.configure(getOrcSchemaName(schemaValue), getOrcSchemaType(schemaValue));
    return stream2ParquetTableSink

  }
}
