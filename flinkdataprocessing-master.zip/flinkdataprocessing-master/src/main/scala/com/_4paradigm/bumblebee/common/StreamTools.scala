package com._4paradigm.bumblebee.common

import java.util

import com._4paradigm.bumblebee.common.types.{TableSinkType, TableSourceType}
import com._4paradigm.bumblebee.connector.{BucketingTableConnector, BucketingTableNewConnector, CustomizeKafkaTableConnector, KafkaTableConnector, ParquetBucketingTableConnector, RtidbTableConnector}
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010
//import org.apache.flink.streaming.api.datastream.DataStream
//import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment
//import org.apache.flink.table.api.java.StreamTableEnvironment
import org.apache.flink.streaming.api.scala._
import org.apache.flink.table.api.scala.StreamTableEnvironment
import org.apache.flink.types.Row
import org.apache.flink.util.Preconditions
import org.slf4j.LoggerFactory

trait StreamTools extends Tools{
  private val LOG = LoggerFactory.getLogger(classOf[StreamTools])

  def initSource(see:StreamExecutionEnvironment,tableEnv:StreamTableEnvironment,sourcedescriptionList: List[SourceDescription]): Unit = {
    for (sourceDescription <- sourcedescriptionList) {
      val sourceObject:util.HashMap[String,Object] = sourceDescription.description
      val source:String = getMapValueString(sourceObject,SOURCETYPE).toLowerCase
      var tableNameValue = Preconditions.checkNotNull(getMapValueString(sourceObject,"tableName"), "source topicName must not be null.")
      if(source.equals(TableSourceType.KAFKA.toString)) {
        var customizeBoolean :Boolean = true
        try {
          if(sourceObject.get("customize")!=null){
            customizeBoolean = sourceObject.get("customize").asInstanceOf[Boolean];
          }
        }catch {
          case e:Exception => e.printStackTrace();
        }
        if(customizeBoolean){
          LOG.info("使用自定义的Kafka连接器")
          val kafkaSource:FlinkKafkaConsumer010[Row] = new CustomizeKafkaTableConnector().getCustomizeKafkaTableSourceConnect(sourceObject);

          val ds = see.addSource(kafkaSource)
          tableEnv.registerDataStream(tableNameValue,ds);
        }else{
          new KafkaTableConnector().getKafkaTableSourceConnect(see,tableEnv,sourceObject)
        }
      } else {
        LOG.error("暂不支持其他格式数据源Source 目前仅支持配置kafka")
      }
    }
  }

  def initSink(see:StreamExecutionEnvironment,tableEnv:StreamTableEnvironment,sinkDescriptionList: List[SinkDescription]): Unit = {
    for (sinkDescription <- sinkDescriptionList) {
      val sinkObject:util.HashMap[String,Object] = sinkDescription.description
      val sink:String = getMapValueString(sinkObject,SINKTYPE).toLowerCase
      var tableNameValue = Preconditions.checkNotNull(getMapValueString(sinkObject,"tableName"), "sink topicName must not be null.")
      if(sink == TableSinkType.RTIDB.toString){
        var rtiDBTableSink = new RtidbTableConnector().getRtidbTableSinkConnect(sinkObject)
        tableEnv.registerTableSink(tableNameValue,rtiDBTableSink);
      } else if(sink == TableSinkType.SDP.toString){
        val pdmsTableSink = new ParquetBucketingTableConnector().getPDMSSinkConnect(sinkObject)
        tableEnv.registerTableSink(tableNameValue,pdmsTableSink);
      }else if(sink == TableSinkType.BUCKET.toString){
        val bucketingTableSink = new BucketingTableConnector().getBucketingTableConnector(sinkObject)
        tableEnv.registerTableSink(tableNameValue,bucketingTableSink);
      }else {
        LOG.error("暂不支持其他格式数据源Sink 目前仅支持配置rtidb ,sdp(parquet),bucket")
      }
    }

  }

}
