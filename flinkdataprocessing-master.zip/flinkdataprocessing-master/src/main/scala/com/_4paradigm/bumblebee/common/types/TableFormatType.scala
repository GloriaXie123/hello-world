package com._4paradigm.bumblebee.common.types

/**
  * Created by zhanglibing on 2019/3/29
  */

object TableFormatType extends Enumeration {
  type TableFormatType = Value
  val JSON, AVRO, ORC = Value
}

