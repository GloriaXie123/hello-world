package com._4paradigm.bumblebee.common.types

/**
  * Created by zhanglibing on 2019/3/29
  */
object TableSinkType extends Enumeration {
  type TableSinkType = Value
  val KAFKA = Value("kafka")
  val HDFS = Value("hdfs")
  val HIVE = Value("hive")
  val RTIDB = Value("rtidb")
  val SDP = Value("sdp")
  val BUCKET = Value("bucket")
}
