package com._4paradigm.bumblebee.common


import java.util.UUID

import org.apache.flink.api.java.utils.ParameterTool
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.ObjectMapper
import org.slf4j.LoggerFactory
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util

import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.core.JsonParseException
import org.apache.flink.util.Preconditions

/**
  * Created by zhanglibing on 2019/3/28
  */

trait Tools {
  //全局变量 从全局属性中获取  -D
  var parameterTool = ParameterTool.fromSystemProperties()
  val uuid = UUID.randomUUID.toString
  val sdf  = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
  val current = sdf.format(System.currentTimeMillis());
  private val LOG = LoggerFactory.getLogger(classOf[Tools])
  //抽象描述
  case class SourceDescription(description: util.HashMap[String, Object]) extends Serializable
  case class TransformDescription(description: util.HashMap[String, Object]) extends Serializable
  case class SinkDescription(description: util.HashMap[String, Object]) extends Serializable


  val JOBNAME = "name" //输入框 null 空 格式化null， null为 Flink_Job_uuid
  val PARALLELISM = "parallelism" //输入框 限定不超过可用资源的正整数 null 空 格式化null null为使用flink系统默认并行度
  val JOBTYPE = "jobType" //下拉框 stream batch
  val CHECKPOINTPATH = "checkpointPath" //输入框 null 空 格式化null null关闭checkpoint功能

  val SOURCETYPE = "sourceType" //下拉框 kafka hive
  val SOURCE_PROPERTIES = "sourceProperties" //资源描述json

  val TRANSFORM_PROPERTIES = "operation" //处理描述json

  val SINKTYPE = "sinkType" //下拉框
  val SINK_PROPERTIES = "sinkProperties" //sink 描述json

  val UDF = "udf"

  var jobName: String = null
  var parallelism: Integer = null
  var jobType: String = null
  var checkPointPath: String = null
  var SourceJsonArray: util.ArrayList[util.HashMap[String, Object]] = null
  var TransJsonArray: util.ArrayList[Object] = null
  var SinkJsonArray: util.ArrayList[util.HashMap[String, Object]] = null

  var SourceSchemaMap :util.HashMap[String,String] = null;
  var udfSMap :util.HashMap[String,String] = null;

  //TODO 参数获取方式现以经过URL.encode 的Json，后期会因为参数过多而选择连接至后端数据库中提取
  def validateAndInitParams(args: Array[String]): Boolean = {
    LOG.info("检查参数")
    //parameterTool = ParameterTool.fromArgs(args)

    val mapper = new ObjectMapper()
    if (args.size < 1) {
      throw new RuntimeException("flink 运行缺少参数。 args :" + args.toString)
    }

    LOG.info("origin args:")
    args.foreach(arg => LOG.info("origin:\n" + arg + "\ndecode:\n" + URLDecoder.decode(arg, StandardCharsets.UTF_8.name())))
    LOG.info("end of args")
    var parameterTool: util.HashMap[String, Object] = null
    try{
        parameterTool = mapper.readValue(URLDecoder.decode(args(0), "UTF-8"), classOf[util.HashMap[String, Object]])
    } catch {
      case e: JsonParseException => {
        LOG.error("参数json化解析失败")
        e.printStackTrace()
        return false
      }
      case e: Exception => {
        LOG.error("参数URL decode  json化 解析提取失败")
        e.printStackTrace()
        return false
      }
    }

      if (getMapValueString(parameterTool,JOBNAME) != null) {
        jobName = "Flink_Job_" + getMapValueString(parameterTool,JOBNAME)
      } else {
        jobName = "Flink_Job_" + current
      }
      if(getMapValueString(parameterTool,PARALLELISM)!=null){
        parallelism = Integer.parseInt(getMapValueString(parameterTool,PARALLELISM))
      }
      jobType = Preconditions.checkNotNull(getMapValueString(parameterTool,JOBTYPE), "参数缺省 :" + JOBTYPE)
      checkPointPath = getMapValueString(parameterTool,CHECKPOINTPATH)

      val sourcePropertiesValue: Object = Preconditions.checkNotNull(parameterTool.get(SOURCE_PROPERTIES), "参数缺省 :" + SOURCE_PROPERTIES)
      val transformPropertiesValue: Object = Preconditions.checkNotNull(parameterTool.get(TRANSFORM_PROPERTIES), "参数缺省 :" + TRANSFORM_PROPERTIES)
      val sinkPropertiesValue: Object = Preconditions.checkNotNull(parameterTool.get(SINK_PROPERTIES), "参数缺省 :" + SINK_PROPERTIES)

      SourceJsonArray = sourcePropertiesValue.asInstanceOf[util.ArrayList[util.HashMap[String, Object]]]
      TransJsonArray = transformPropertiesValue.asInstanceOf[util.ArrayList[Object]]
      SinkJsonArray = sinkPropertiesValue.asInstanceOf[util.ArrayList[util.HashMap[String, Object]]]

    if(parameterTool.get(UDF)!=null){
      udfSMap =parameterTool.get(UDF).asInstanceOf[util.HashMap[String, String]]
    }


      LOG.info("jobName : " + jobName)
      LOG.info("parallelism : " + parallelism)
      LOG.info("jobType : " + jobType)
      LOG.info("checkPointPath  :  " + checkPointPath)
      LOG.info("source json array : "+SourceJsonArray)
      LOG.info("trans json object : "+TransJsonArray)
      LOG.info("sink json array : "+SinkJsonArray)

      return true
  }

  //创建资源描述
  def createSourceDescriptions(): List[SourceDescription] = {
    var sourceDescriptionList: List[SourceDescription] = List[SourceDescription]()
    SourceSchemaMap = new util.HashMap[String,String]();
    try {
      if (SourceJsonArray.size != 0 && SourceJsonArray != null) {
        val iterator = SourceJsonArray.iterator
        while (iterator.hasNext) {
          val value: util.HashMap[String, Object] = iterator.next
          //获取schema map集合
          SourceSchemaMap.put(value.get("tableName").asInstanceOf[String],value.get("schema").asInstanceOf[String])
          sourceDescriptionList = sourceDescriptionList.+:(SourceDescription(value))
        }
      }
    } catch {
      case e: Exception => {
        LOG.error("source资源添加List erro")
        e.printStackTrace()
      }
    }
    sourceDescriptionList
  }

  def createSinkDescription(): List[SinkDescription] = {
    var sinkDescriptionList: List[SinkDescription] = List[SinkDescription]()
    try {
      if (SinkJsonArray.size != 0 && SinkJsonArray != null) {
        val iterator = SinkJsonArray.iterator
        while (iterator.hasNext) {
          val value: util.HashMap[String, Object] = iterator.next
          sinkDescriptionList = sinkDescriptionList.+:(SinkDescription(value))
        }
      }
    } catch {
      case e: Exception => {
        LOG.error("sink资源添加List erro")
        e.printStackTrace()
      }
    }
    sinkDescriptionList
  }

  def createTransformDescription():  util.ArrayList[String] = {
    TransJsonArray.asInstanceOf[util.ArrayList[String]]
  }

  //TODO 多数据源支持 参数妥协
 /* def stringToMapToArray(obj: Object): util.ArrayList[util.HashMap[String, Object]] = {
    var arrayList = new util.ArrayList[util.HashMap[String, Object]]
    var map: util.HashMap[String, Object] = obj.asInstanceOf[util.HashMap[String, Object]]
    map.put(key, value)
    arrayList.add(map)
    return arrayList
  }*/

  def getMapValueString(map:util.HashMap[String,Object],key : String): String = {
    var value = map.get(key)
    if(value ==null || value.equals("")){
      null
    }else{
      value.toString
    }
  }
}
