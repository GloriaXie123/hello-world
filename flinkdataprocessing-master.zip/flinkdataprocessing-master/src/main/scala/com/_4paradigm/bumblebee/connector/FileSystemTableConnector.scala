package com._4paradigm.bumblebee.connector

import java.util

import com._4paradigm.bumblebee.connector.format.FormatTools
import org.apache.flink.table.api.java.BatchTableEnvironment
//import org.apache.flink.table.api.BatchTableEnvironment
import org.apache.flink.table.descriptors.FileSystem
import org.apache.flink.util.Preconditions
import org.slf4j.LoggerFactory

/**
  * shanyue
  * flink 1.7 格式暂时仅限CSV
  * 目前验证了 FileSystem 的csv格式  source
  *
  */
class FileSystemTableConnector extends FormatTools{
  private val LOG = LoggerFactory.getLogger(classOf[OrcFileTableConnector])

  val path = "path"
  val schema = "schema"
  val tableName = "tableName"

  def getFileSystemTableSourceConnect(tableEnv: BatchTableEnvironment, map: util.HashMap[String, Object]): Unit = {

    val pathValue = Preconditions.checkNotNull(getMapValueString(map,path), "hdfsPath must not be null.")
    val schemaValue = Preconditions.checkNotNull(getMapValueString(map,schema) , "schema must not be null.")
    val tableNameValue = Preconditions.checkNotNull(getMapValueString(map,tableName), "tableName must not be null.")

    LOG.info("fileSystem Connect table格式化 参数 pathValue："+pathValue + " schemaValue:"+schemaValue+ " tableNameValue:"+tableNameValue)

    tableEnv.connect(
      //kafka connect
      new FileSystem().path(pathValue)
    )
      //必须Format
      .withFormat(getFormat(map)
    )
      //必须Schema
      .withSchema(getSchema(schemaValue)
    )
      .registerTableSource(tableNameValue)

  }

}
