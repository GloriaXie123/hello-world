package com._4paradigm.bumblebee.connector

/**
import java.util
import org.apache.flink.table.api.scala.BatchTableEnvironment
import org.apache.flink.table.catalog.hive.HiveCatalog
import org.apache.flink.util.Preconditions
import org.slf4j.LoggerFactory
**/

/**
  *  shangyue
  *  目前只支持Hive的 batch source
  *  不需要format
  */
class HiveTableConnector {
  /**
  private val LOG = LoggerFactory.getLogger(classOf[HiveTableConnector])

  val metastoreURI = "hiveMetastoreURI"
  val database = "database"

  def getHiveTableSourceConnect(tableEnv: BatchTableEnvironment, map: util.HashMap[String, Object]): Unit = {

    val metastoreURIValue = Preconditions.checkNotNull(getMapValueString(map,metastoreURI), "hiveMetastoreURI must not be null.")
    val databaseValue = Preconditions.checkNotNull(getMapValueString(map,database), "database must not be null.")

    LOG.info("hive Connect table格式化 参数 metastoreURIValue："+metastoreURIValue + " database:"+database)

    val CATALOG = "bumblebee";
    val catalog = new HiveCatalog(CATALOG, metastoreURIValue);
    //tableEnv.registerCatalog(CATALOG, catalog);
    //tableEnv.setDefaultDatabase(CATALOG, databaseValue);
  }

  def getMapValueString(map:util.HashMap[String,Object],key : String): String = {
    var value = map.get(key)
    if(value ==null || value.equals("")){
      null
    }else{
      value.toString
    }
  }
    **/
}
