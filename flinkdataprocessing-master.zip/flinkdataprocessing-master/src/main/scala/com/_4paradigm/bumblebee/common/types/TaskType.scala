package com._4paradigm.bumblebee.common.types

/**
  * Created by zhanglibing on 2019/3/29
  */
object TaskType extends Enumeration {
  type TaskType = Value
  val BATCH = Value("batch")
  val STREAM = Value("stream")
}
