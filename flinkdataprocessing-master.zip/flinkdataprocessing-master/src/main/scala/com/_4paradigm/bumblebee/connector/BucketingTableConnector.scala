package com._4paradigm.bumblebee.connector

import java.time.ZoneId
import java.util

import com._4paradigm.bumblebee.Bucketing.BucketingTableSink
import com._4paradigm.bumblebee.connector.format.FormatTools
import org.slf4j.LoggerFactory
import org.apache.flink.util.Preconditions.checkNotNull
import org.apache.flink.core.fs.Path
import org.apache.flink.core.fs.FileSystem
import org.apache.flink.streaming.connectors.fs.bucketing.BucketingSink
import org.apache.flink.streaming.connectors.fs.bucketing.DateTimeBucketer

class BucketingTableConnector extends FormatTools {
  private val LOG = LoggerFactory.getLogger(classOf[BucketingTableConnector])

  val BASEPATH = "hdfsPrefix"
  val DATETIMEBUCKETER = "dateTimeBucketer"
  val ZONEID = "zoneId"
  val BATCHSIZE = "batchSize"
  val BATCHROLLOVERINTERVAL = "batchRolloverInterval"
  val TABLENAME = "tableName"
  val SCHEMA = "schema"


  def getBucketingTableConnector(map: util.HashMap[String, Object]): BucketingTableSink = {
    val basePathValue = checkNotNull(getMapValueString(map, BASEPATH), "Bucketing 参数 hdfsPrefix 为null")
    var dateTimeBucketerValue = getMapValueString(map, DATETIMEBUCKETER)
    var zoneIdValue: String = getMapValueString(map, ZONEID)
    var batchSizeValue = map.get(BATCHSIZE).asInstanceOf[java.lang.Long] //getMapValueString(map,BATCHSIZE)
    var batchRolloverIntervalValue = map.get(BATCHROLLOVERINTERVAL).asInstanceOf[java.lang.Long] //getMapValueString(map,BATCHROLLOVERINTERVAL)
    val tableNameValue = checkNotNull(getMapValueString(map, TABLENAME), "Bucketing 参数 tableName 为null")
    val schemaValue = checkNotNull(getMapValueString(map, SCHEMA), "Bucketing 参数 schema 为null")

    if (dateTimeBucketerValue == null) {
      dateTimeBucketerValue = "yyyy-MM-dd-HH";
    } //默认一小时一个bucketer
    if (zoneIdValue == null) {
      zoneIdValue = "Asia/Shanghai";
    } //默认时间上海
    if (batchSizeValue == null) {
      batchSizeValue = 1024 * 1024 * 128L
    } //128MB一个批
    if (batchRolloverIntervalValue == null) {
      batchRolloverIntervalValue = 60000L
    } //默认一分钟一个分片

    LOG.info("Bucketing Table Sink 创建连接 参数: hdfsPrefix:" + basePathValue + " .dateTimeBucketer:" + dateTimeBucketerValue + " .zoneId:" + zoneIdValue + " .batchSize:" + batchSizeValue + " .batchRolloverInterval:" + batchRolloverIntervalValue + " .tableName:" + tableNameValue + " .schema:" + schemaValue)

    val names = getOrcSchemaName(schemaValue)
    val trpes = getOrcSchemaType(schemaValue)

    //删除base目录
    //val path = new Path(basePathValue);
    //val fs = path.getFileSystem();
    //fs.delete(path, true);

    /*
    val sink: StreamingFileSink[String] = StreamingFileSink
      .forRowFormat(new Path(""), new SimpleStringEncoder[String]("UTF-8"))
      .build()*/


    val hdfsSink = new BucketingSink(basePathValue)
    hdfsSink.setBucketer(new DateTimeBucketer(dateTimeBucketerValue, ZoneId.of(zoneIdValue)));
    hdfsSink.setBatchSize(batchSizeValue);
    hdfsSink.setBatchRolloverInterval(batchRolloverIntervalValue);
    //      SimpleDateFormat df = new SimpleDateFormat("-yyyy-MM-dd-HH-mm");//设置日期格式
    //      sink.setPartSuffix(df.format(new Date()));//设置后缀为系统时间
    hdfsSink.setPendingPrefix("");
    hdfsSink.setPendingSuffix(".tsv");
    //hdfsSink.setValidLengthPrefix("")
    hdfsSink.setUseTruncate(false);

    val bucketingTableSink = new BucketingTableSink(hdfsSink,"\t");
    bucketingTableSink.configure(getOrcSchemaName(schemaValue), getOrcSchemaType(schemaValue));

    //暂时返回的是TableSink，未来会封装成Connector
    return bucketingTableSink
  }
}
