#!/usr/bin/env bash
mvn clean package -DskipTests

rm -rf dist && mkdir dist
cp target/flink-job-runner* dist/
echo "generate jar at dist directory"