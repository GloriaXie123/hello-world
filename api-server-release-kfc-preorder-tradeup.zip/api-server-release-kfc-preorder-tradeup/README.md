# API Server

在线模型应用的业务中间件。

## Overview

![API Server overview](docs/images/API%20Server%20Overview.png)

##

- Policy Loader 子模块
    - 负责将 Policy 对应的脚本家在加载到程序中
- Recall 子模块
    - User 和 Item 按照并行的方式处理
    - Recall Item
- Prediction 子模块
- Logging 子模块

## 调优

参考：https://github.com/fabric8io-images/run-java-sh/blob/master/TUNING.md

- Adjust the JIT compiler thread count with the -XX:CICompilerCount option according to the CPU limits,
- Deactivate the C2 JIT compiler with the -XX:TieredStopAtLevel=1 option when the memory limits are lower than 300MB,
- Adjust the heap size ratio from 50% to 30% when the memory limits are lower than 300MB, maybe with a threshold to preserve a least 110MB of available non-heap memory,
- While setting -Xms enables fail-fast behaviour, it may not be wise for cloud native apps, but setting the -XX:MinHeapFreeRatio=20 and -XX:MaxHeapFreeRatio=40 options may be beneficial to instruct the heap to shrink aggressively and to grow conservatively.


JVM 参数：

```
-XX:CICompilerCount=CPU 数量
-XX:TieredStopAtLevel=1 
```