public class sy_test {
    public static void main(String[] args) {
String aa ="version:string,storeCode:string,itemlinkId:string,linkId:string,systemId:string,round:int,price:int,iMenuCn:string,iDescCn:string,iSalesFlag:string,validFrom:bigint,validTo:bigint,startTime:int,endTime:int,showNameCn:string,quantity:int,itemCount:int";


        String dd=aa.replaceAll(":"," ");
        String[] bb= dd.split(",");

        for (String bbb:bb) {
            String bbbb=bbb.split(" ")[0];
            System.out.println("`"+bbbb+"`"+" "+bbb.split(" ")[1]+",");
        }


    }
}
