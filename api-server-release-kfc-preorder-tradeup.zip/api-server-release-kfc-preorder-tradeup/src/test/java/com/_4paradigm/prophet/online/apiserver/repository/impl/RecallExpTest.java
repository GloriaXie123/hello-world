package com._4paradigm.prophet.online.apiserver.repository.impl;

import com._4paradigm.prophet.online.apiserver.repository.rtidb.RtiDBTable;
import com.googlecode.aviator.AviatorEvaluator;
import com.googlecode.aviator.runtime.function.AbstractFunction;
import com.googlecode.aviator.runtime.function.FunctionUtils;
import com.googlecode.aviator.runtime.type.AviatorObject;
import com.googlecode.aviator.runtime.type.AviatorString;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@RunWith(SpringRunner.class)
@SpringBootTest
@Configuration
public class RecallExpTest {

    @Autowired
    private RtiDBTable rtiDBTable;

    @Test
    public void exprRecallTest() {
        AviatorEvaluator.addFunction(new TableFuncion());
        System.out.println(AviatorEvaluator.execute("Table('SHOUREN_ITEM_DATA', '3')"));
    }

    public class TableFuncion extends AbstractFunction {

        private String tablePrimaryKey = "itemId";

        private String tableDataKey = "TitleWords";

        public String getName() {
            return "Table";
        }

        @Override
        public AviatorObject call(Map<String, Object> env, AviatorObject arg0, AviatorObject arg1) {
            String tableName = FunctionUtils.getStringValue(arg0, env);
            String indexName= FunctionUtils.getStringValue(arg1, env);
            RtiDBTable table = RecallExpTest.this.rtiDBTable.getTable(tableName);
            Map<String, Object> row = table.getRow("itemId", indexName);
            return new AviatorString(row.get(tableDataKey).toString());
        }
    }

    @Test
    public void emtptyStrTest() {
        String test = "";
        String[] ret = test.split(",");
        for (String s: ret) {
            System.out.println("===");
            System.out.println(s);
        }
    }

    @Test
    public void unionStrTest() {
        String left = "1,2,3";
        String right = "3,4,5";
        Set<String> leftSet = new HashSet<>(Arrays.asList(left.split(",")));
        Set<String> rightSet = new HashSet<>(Arrays.asList(right.split(",")));
        leftSet.addAll(rightSet);
        System.out.println(String.join(",", leftSet));
    }
}
