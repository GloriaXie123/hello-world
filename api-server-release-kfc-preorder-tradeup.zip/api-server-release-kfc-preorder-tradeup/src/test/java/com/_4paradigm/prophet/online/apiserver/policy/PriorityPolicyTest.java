package com._4paradigm.prophet.online.apiserver.policy;

import com._4paradigm.prophet.online.apiserver.yumc.tradeup.rerank.TradeupPriorityRerankPolicy;
import java.util.HashMap;
import java.util.Map;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author akis on 2019-07-24
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class PriorityPolicyTest {


    @Autowired
    TradeupPriorityRerankPolicy policy;


    @Test
    public void testPriority() {
        double delta = 0.00001;
        Map<String, Object> item = new HashMap<>();
        item.put("predictScore", 10.0);
        item.put("sell_code", "830350");

        double val = policy.calculate(item);

        Assert.assertEquals(20.0, val, delta);

        Map<String, Double> priorityMap = new HashMap<String, Double>(){
            {
                put("830350", 2.5);
                put("830351", 3.0);
            }
        };

        policy.setPriorityMap(priorityMap);
        val = policy.calculate(item);
        Assert.assertEquals(25.0, val, delta);


        priorityMap = new HashMap<String, Double>(){
            {
                put("830351", 3.0);
            }
        };
        policy.setPriorityMap(priorityMap);
        val = policy.calculate(item);
        Assert.assertEquals(10.0, val, delta);


        priorityMap = new HashMap<String, Double>(){
            {
                put("default", 1.5);
                put("830351", 3.0);
            }
        };
        policy.setPriorityMap(priorityMap);
        val = policy.calculate(item);
        Assert.assertEquals(15.0, val, delta);
    }


}
