package com._4paradigm.prophet.online.apiserver.policy;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import org.junit.Test;

public class PolicyTest {
    @Test
    public void process() {
        Context context = new Context();
        try {
            Class<?> c = Class.forName("com._4paradigm.prophet.online.apiserver.policy.impl.FakePreRecallPolicy");
            Policy prePolicy = (Policy) c.getDeclaredConstructor().newInstance();
            prePolicy.process(context);

            c = Class.forName("com._4paradigm.prophet.online.apiserver.policy.impl.FakePostPolicy");
            Policy postPolicy = (Policy) c.getConstructor().newInstance();
            postPolicy.process(context);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}