package com._4paradigm.prophet.online.apiserver.policy;


import com._4paradigm.prophet.online.apiserver.yumc.tradeup.rerank.TradeupRerankPolicy;
import com._4paradigm.prophet.online.apiserver.yumc.tradeup.rerank.TradeupRerankPolicy.PeriodExp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author akis on 2019-07-22
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class TradeupRerankPolicyTest {

    @Autowired
    TradeupRerankPolicy rerankPolicy;

    @Test
    public void testExpression() {
        String expression = "14:00~17:00,2|default,1";
        rerankPolicy.setPeriodExpList(getList(expression));

        Map<String, Object> item = new HashMap<>();
        item.put("predictScore", 10.0);
        item.put("price", 4.0);

        String time = "16:00";
        double val = rerankPolicy.calculate(item, time);
        Assert.assertEquals(0, Double.compare(160.0, val));


        time = "10:00";
        val = rerankPolicy.calculate(item, time);
        Assert.assertEquals(0, Double.compare(40.0, val));

        expression = "14:00~17:00,git1";
        rerankPolicy.setPeriodExpList(getList(expression));

        time = "10:15";
        val = rerankPolicy.calculate(item, time);
        Assert.assertEquals(0, Double.compare(10.0, val));

        time = "17:00";
        val = rerankPolicy.calculate(item, time);
        Assert.assertEquals(0, Double.compare(10.0, val));

        expression = "default,1|14:00~17:00,2";
        rerankPolicy.setPeriodExpList(getList(expression));

        time = "17:00";
        val = rerankPolicy.calculate(item, time);
        Assert.assertEquals(0, Double.compare(40.0, val));

        time = "15:00";
        val = rerankPolicy.calculate(item, time);
        Assert.assertEquals(0, Double.compare(160.0, val));
    }


    private List<PeriodExp> getList(String expression) {
        List<PeriodExp> periodExpList;
        if (StringUtils.isNotEmpty(expression)) {
            String[] slices = StringUtils.split(expression, "|");
            periodExpList = Arrays.stream(slices)
                    .map(PeriodExp::getInstance)
                    .collect(Collectors.toList());
        } else {
            periodExpList = new ArrayList<>(0);
        }
        return periodExpList;
    }
}
