package com._4paradigm.prophet.online.apiserver.service;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PredictionServiceTest {
    @Autowired
    PredictionService predictionService;

    @Test
    public void process() {
        HashMap<String, Object> testMap = new HashMap<>();
        System.out.println(testMap.get(null));
    }
}