package com._4paradigm.prophet.online.apiserver.repository.impl;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@Slf4j
public class FakeUserRepositoryTest {
    @Autowired
    @Qualifier("FakeUser")
    UserRepository userRepository;

    @Test
    public void test() {
        Context ctx = new Context();
        log.info(userRepository.getUser(ctx).toString());
    }
}