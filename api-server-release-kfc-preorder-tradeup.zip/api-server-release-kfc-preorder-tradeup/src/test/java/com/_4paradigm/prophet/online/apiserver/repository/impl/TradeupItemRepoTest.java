package com._4paradigm.prophet.online.apiserver.repository.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

/**
 * @author akis on 2019-08-09
 */

public class TradeupItemRepoTest {

    @Test
    public void filterCertainItem() {
        Map<String, String> map = new HashMap<>();

        map.put("Icecream", "839123|846567");
        map.put("Coffee", "456789");

        map = map.entrySet().stream()
                .collect(Collectors.toMap(entry -> StringUtils.lowerCase(entry.getKey()), Entry::getValue));
        System.out.println(map);
        Set<String> set = new HashSet<>();
        set.add("icecream");
        set.add("coffee");

        Set<String> res = set.stream()
                .map(map::get)
                .filter(StringUtils::isNotEmpty)
                .flatMap(itemList -> Arrays.stream(itemList.split("\\|")))
                .collect(Collectors.toSet());
        System.out.println(res);
    }


}
