package com._4paradigm.prophet.online.apiserver.repository.impl;

import com._4paradigm.prophet.online.apiserver.repository.rtidb.RtiDBTable;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@Configuration
public class RtiDBRtiDBTableTest {

    @Autowired
    private RtiDBTable rtiDBTable;

    @Value("${itemData.RtiDBItems.tableName}")
    private String itemTableName;

    @Value("${itemData.primaryKey}")
    private String itemTablePK;

    @Test
    public void previewTableTest() {
        System.out.println("====== Test case for previewing RtiDB rtiDBTable ======");
        RtiDBTable itemRtiDBTable = rtiDBTable.getTable(itemTableName);
        System.out.println(itemRtiDBTable.preview(itemTablePK, 10));
    }
}
