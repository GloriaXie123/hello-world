package com._4paradigm.prophet.online.apiserver;

import com._4paradigm.prophet.online.apiserver.util.FileUtils;
import com._4paradigm.prophet.online.apiserver.util.JsonUtils;
import com.alibaba.fastjson.JSON;
import org.junit.Test;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class JsonTest {

    @Test
    public void testJson() {

        String TALimit_json="{\"0-40\":2,\"40-99999\" :4}";

        Map<String, Integer> TALimit= (Map<String, Integer>) JSON.parse(TALimit_json);
        Integer itemLimit=10;
        int cartAmount=20;

        for (Map.Entry<String, Integer> entry : TALimit.entrySet()) {

            String amount = entry.getKey();
            Integer ta_limit = entry.getValue();

            int min = Integer.parseInt(amount.split("-")[0]);
            int max = Integer.parseInt(amount.split("-")[1]);

            if (cartAmount >= min && cartAmount < max) {
                itemLimit=ta_limit;
            }
        }
        System.out.println(itemLimit);
    }

}
