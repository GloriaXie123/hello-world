package com._4paradigm.prophet.online.apiserver.repository.impl;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespDTO;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@Slf4j
public class FallbackRespParamMapperTest {

    @Autowired
    private FallbackRespParamMapper mapper;

    @Test
    public void testMapper() {
        Context context = new Context();
        context.setExperimentId("exp_3");
        PredictRespDTO resp = mapper.process(context);
        System.out.println(resp.toString());

        System.out.println(context.getExtraData().get("itemLog"));
    }

}