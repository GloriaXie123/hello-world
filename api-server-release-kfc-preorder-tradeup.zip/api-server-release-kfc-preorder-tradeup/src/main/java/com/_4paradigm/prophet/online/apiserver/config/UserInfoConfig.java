package com._4paradigm.prophet.online.apiserver.config;

import com._4paradigm.prophet.online.apiserver.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class UserInfoConfig {
    @Autowired
    private ApplicationContext context;

    @Bean("userRepositoryAlias")
    public UserRepository userRepositoryAlias(@Value("${userInfo.ImplType}") String qualifier) {
        return (UserRepository) context.getBean(qualifier);
    }
}
