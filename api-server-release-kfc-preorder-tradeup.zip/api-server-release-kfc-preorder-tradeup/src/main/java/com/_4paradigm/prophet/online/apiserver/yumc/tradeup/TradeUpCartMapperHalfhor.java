package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;

/**
 * @author akis on 2019-06-28
 */
@Lazy
@Repository("TradeUpCartMapperHalfhor")
@Slf4j
class TradeUpCartMapperHalfhor extends AbstractTradeUpCartMapper {

    @Override
    public String getCityRecallDaypart(LocalDateTime localDateTime){

        int hour = localDateTime.getHour();
        int minute = localDateTime.getMinute();

        return String.valueOf(2 * hour + (minute < 30 ? 0 : 1));

    }



}
