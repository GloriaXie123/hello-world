package com._4paradigm.prophet.online.apiserver.config;

import com._4paradigm.prophet.online.apiserver.policy.ConversionCostPolicy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ConversionCostConfig {

    @Autowired
    private ApplicationContext context;

    @Bean("conversionCostPolicyAlias")
    public ConversionCostPolicy conversionCostPolicyAlias(@Value("${conversionCost.ImplType}") String qualifier) {
        return (ConversionCostPolicy) context.getBean(qualifier);
    }
}
