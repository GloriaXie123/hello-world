package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespDTO;
import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
@Builder
public class SimplifiedContext {
    private Map<String, Object> common;
    private Map<String, Object> extraData;
    private List<Map<String, Object>> items;
    private PredictRespDTO response;
}
