package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;

@Slf4j
public class Utils {
    public static ObjectMapper mapper = new ObjectMapper();
    public static <T> Object copyAsObject(T source) {
        try {
            return mapper.readValue( mapper.writeValueAsBytes(source), Object.class);
        } catch (IOException e) {
            log.error("cannot parse Object[{}]", source, e);
        }
        return null;
    }
}
