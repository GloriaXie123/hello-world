package com._4paradigm.prophet.online.apiserver.service;

import com._4paradigm.prophet.online.apiserver.exception.ApiServerException;
import com._4paradigm.prophet.online.apiserver.exception.RetCode;
import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.model.context.ContextLogger;
import com._4paradigm.prophet.online.apiserver.model.context.ReqParamMapper;
import com._4paradigm.prophet.online.apiserver.model.context.RespParamMapper;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.req.predictReqDTO;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespDTO;
import com._4paradigm.prophet.online.apiserver.model.dto.predictor_client.req.PredictCliReqDTO;
import com._4paradigm.prophet.online.apiserver.model.dto.predictor_client.resp.PredictCliRespDTO;
import com._4paradigm.prophet.online.apiserver.model.dto.predictor_client.resp.PredictCliRespInstance;
import com._4paradigm.prophet.online.apiserver.policy.ConversionCostPolicy;
import com._4paradigm.prophet.online.apiserver.policy.FiltrationSoldOutPolicy;
import com._4paradigm.prophet.online.apiserver.policy.Policy;
import com._4paradigm.prophet.online.apiserver.repository.ItemRepository;
import com._4paradigm.prophet.online.apiserver.repository.UserRepository;
import com.google.common.collect.Maps;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import javax.annotation.PostConstruct;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

@Slf4j
@Service
public class PredictionService {

    @Autowired
    MeterRegistry registry;
    @Autowired
    RestTemplate restTemplate;
    @Value("${management.metrics.timed-annotation.enabled}")
    private Boolean enableTimer;
    @Value("${itemData.primaryKey}")
    private String PRED_ID;
    @Value("${predictor.score_column_name}")
    private String PRED_SCORE;
    @Value("${predictor.accessURL}")
    private String SAGE_URL;
    @Value("${predictor.batchSize}")
    private int BATCH_SIZE;
    @Value("${predictor.accessToken:mib}")
    private String predictorAccessToken;
    @Value("${predictor.threadPoolSize:10}")
    private int threadPoolSize;
    private ExecutorService es;

    @Value("${conversion.cost.switch}")
    private String conversionCostSwitch;

    private ReqParamMapper reqParamMapper;
    private RespParamMapper respParamMapper;
    private ContextLogger contextLogger;


    private Policy reRankingPolicy;
    private Policy preRecallPolicy;
    private Policy prePredictPolicy;
    private ConversionCostPolicy conversionCostPolicy;
    private FiltrationSoldOutPolicy filtrationSoldOutPolicy;

    private UserRepository userRepository;
    private ItemRepository itemRepository;

    public PredictionService(
            @Qualifier("contextLoggerAlias") ContextLogger contextLogger,

            @Qualifier("requestDTOMapperAlias") ReqParamMapper reqParamMap,
            @Qualifier("userRepositoryAlias") UserRepository userRepo,
            @Qualifier("preRecallPolicyAlias") Policy preRecallPolicy,
            @Qualifier("itemRepositoryAlias") ItemRepository itemRepo,
            @Qualifier("prePredictPolicyAlias") Policy prePredictPolicy,
            @Qualifier("reRankingPolicyAlias") Policy reRankingPolicy,
            @Qualifier("responseDTOMapperAlias") RespParamMapper respParamMap,
            @Qualifier("conversionCostPolicyAlias") ConversionCostPolicy conversionCostPo,
            @Qualifier("filtrationSoldOutPolicyAlias") FiltrationSoldOutPolicy filtrationSoldOutPo
    ) {
        this.reqParamMapper = reqParamMap;
        this.respParamMapper = respParamMap;
        this.contextLogger = contextLogger;

        this.preRecallPolicy = preRecallPolicy;
        this.prePredictPolicy = prePredictPolicy;
        this.reRankingPolicy = reRankingPolicy;

        this.itemRepository = itemRepo;
        this.userRepository = userRepo;
        this.conversionCostPolicy = conversionCostPo;
        this.filtrationSoldOutPolicy = filtrationSoldOutPo;
    }

    @PostConstruct
    private void postConstruct() {
        this.es = Executors.newFixedThreadPool(this.threadPoolSize);
    }

    public Context makePrediction(Context context) throws ApiServerException {
        Map<String, Object> commonFeatures = Maps.newHashMapWithExpectedSize(
                context.getCommon() == null ? 8 : context.getCommon().size());
        if (context.getCommon() != null) {
            commonFeatures.putAll(context.getCommon());
        }

        List<Map<String, Object>> items = context.getItems();

        if (items == null || items.isEmpty()) {
            log.warn("items is null or empty");
            return context;
        }

        log.debug("candidate size: {}", items.size());

        List<Future<PredictCliRespDTO>> futures = new ArrayList<>();
        for (int i = 0; i < items.size(); i += BATCH_SIZE) {
            List<Map<String, Object>> batch = generateBatch(items, i, BATCH_SIZE);
            String requestId = context.getUniqueId();
            PredictCliReqDTO req = wrapRequest(commonFeatures, batch, requestId);

            futures.add(es.submit(() -> callPredictorSvc(SAGE_URL, req)));
        }

        List<PredictCliRespDTO> resps = new ArrayList<>();
        try {
            for (Future<PredictCliRespDTO> future : futures) {
                PredictCliRespDTO resp = future.get();
                resps.add(resp);
            }
        } catch (Exception e) {
            throw new ApiServerException(RetCode.prediction_failed, "failed to predict", e);
        }
        log.debug("responses size: {}", resps.size());

        List<Map<String, Object>> tableWithScore = new ArrayList<>();
        for (int i = 0; i < items.size(); i += BATCH_SIZE) {
            List<Map<String, Object>> batch = generateBatch(items, i, BATCH_SIZE);
            batch = respMerge(resps.get(i / BATCH_SIZE), batch);
            tableWithScore.addAll(batch);
        }
        log.debug("tableWithScore size: {}", tableWithScore.size());

        context.setItems(tableWithScore);
        return context;
    }

    // generateBatch可以和wrap函数合并为一个函数
    private List<Map<String, Object>> generateBatch(List<Map<String, Object>> table, int index,
                                                    int batchSize) {
        List<Map<String, Object>> batch = new ArrayList<>();

        int size = table.size();
        if (index < 0 || index >= size || batchSize <= 0) {
            return batch;
        }

        int tail;
        if (index + batchSize < size) {
            tail = index + batchSize;
        } else {
            tail = size;
        }

        for (int i = index; i < tail; i++) {
            batch.add(table.get(i));
        }
        return batch;
    }

    private PredictCliReqDTO wrapRequest(Map<String, Object> commonFeatures,
                                         List<Map<String, Object>> batch, String requestId) {
        PredictCliReqDTO req = new PredictCliReqDTO();
        req.setResultLimit(batch.size());
        req.setCommonFeatures(commonFeatures);
        req.setAccessToken(predictorAccessToken);
        req.setRequestId(requestId);

        List<Map<String, Object>> rawInstances = new ArrayList<>();
        for (Map<String, Object> sample : batch) {
            Map<String, Object> rawInstance = Maps.newHashMapWithExpectedSize(2);
            rawInstance.put("id", sample.get(PRED_ID));

            Map<String, Object> map = new HashMap<>();
            Iterator<Map.Entry<String, Object>> i = sample.entrySet().iterator();
            while (i.hasNext()) {
                Map.Entry<String, Object> entry = i.next();
                if(null==TRANSITIONMAP.get(entry.getKey())){
                    map.put(entry.getKey(),entry.getValue());
                    continue;
                }
                map.put(TRANSITIONMAP.get(entry.getKey()),entry.getValue());
            }
            rawInstance.put("rawFeatures", map);

            rawInstances.add(rawInstance);
        }
        req.setRawInstances(rawInstances);
        req.setDebug(false);
        req.setWarmupRequest(false);

        return req;
    }

    private PredictCliRespDTO callPredictorSvc(String url, PredictCliReqDTO req) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        HttpEntity<PredictCliReqDTO> httpEntity = new HttpEntity<>(req, headers);
        ResponseEntity<PredictCliRespDTO> resp = restTemplate
                .postForEntity(url, httpEntity, PredictCliRespDTO.class);
        if (resp.getStatusCode() != HttpStatus.OK) {
            return null;
        } else {
            return resp.getBody();
        }
    }

    private List<Map<String, Object>> respMerge(PredictCliRespDTO resp,
                                                List<Map<String, Object>> batch) {
        if (resp.getInstances().size() != batch.size()) {
            log.info("request batch {} does not match response instances size {}", batch.size(),
                    resp.getInstances().size());
            return null;
        }

        List<PredictCliRespInstance> instances = resp.getInstances();
        HashMap<String, PredictCliRespInstance> instanceMap = Maps.newHashMapWithExpectedSize(instances.size());
        for (PredictCliRespInstance instance : instances) {
            instanceMap.put(instance.getId(), instance);
        }
        for (Map<String, Object> sample : batch) {
            PredictCliRespInstance instance = instanceMap.get(sample.get(PRED_ID));
            if (instance == null) {
                sample.put(PRED_SCORE, 0);
                continue;
            }
            sample.put(PRED_SCORE, instance.getScores().get(0));
        }
        return batch;
    }

    @Async("asyncTaskExecutor")
    public Future<PredictRespDTO> predictAsync(predictReqDTO req) throws ApiServerException {
        try {
            return new AsyncResult<>(predict(req));
        } catch (Exception e) {
            RetCode retCode = RetCode.unknown;
            if (e instanceof ApiServerException) {
                retCode = ((ApiServerException) e).getRetCode();
            }
            log.error("api server exception, retCode={}, message={}, request={}", retCode.code(), e.getMessage(), req, e);
            PredictRespDTO resp = new PredictRespDTO();
            resp.setRetCode(retCode.code());
            resp.setMessage(e.getMessage());
            return new AsyncResult<>(resp);
        }
    }

    public PredictRespDTO predict(predictReqDTO req) throws ApiServerException {

        Timer.Sample sample;
        // Debug Log
        log.debug("request: {}", req.toString());

        long start =0l;
        long end =0l;

        //TODO: conversion cost
        long conversionCost = 0;
        if("on".equals(conversionCostSwitch)){
            start = System.currentTimeMillis();
            if (enableTimer) {
                sample = Timer.start(registry);
                this.conversionCostPolicy.process(req);
                sample.stop(registry.timer("apiServer.timer.conversionCost"));
            } else {
                this.conversionCostPolicy.process(req);
            }
            end = System.currentTimeMillis();
            conversionCost = end - start;
        }

        Context context = new Context();
        context.setIsDebug(req.getContext().isDebug());
        context.setExperimentId(req.getContext().getExperimentId());
        // todo: configurable map size
        context.setCommon(Maps.newHashMapWithExpectedSize(330));
        context.setExtraData(new HashMap<>());

        // Mapping raw request body data to context.reqParam
        start = System.currentTimeMillis();
        Map<String, Object> reqParam;
        if (enableTimer) {
            sample = Timer.start(registry);
            reqParam = this.reqParamMapper.process(req, context);
            sample.stop(registry.timer("apiServer.timer.reqParamMapper"));
        } else {
            reqParam = this.reqParamMapper.process(req, context);
        }
        end = System.currentTimeMillis();
        long reqMapperLatency = end - start;
        log.debug("reqParam: {}", reqParam.toString());
        context.setReqParam(reqParam);
        context.getCommon().putAll(reqParam);

        // Fetch user data
        start = System.currentTimeMillis();
        Map<String, Object> userData;
        if (enableTimer) {
            sample = Timer.start(registry);
            userData = this.userRepository.getUser(context);
            sample.stop(registry.timer("apiServer.timer.userRepository"));
        } else {
            userData = this.userRepository.getUser(context);
        }
        end = System.currentTimeMillis();
        long userLatency = end - start;
        log.debug("userData: {}", userData.toString());
        context.setUser(userData);
        context.getCommon().putAll(userData);

        // PreRecall Policy
        start = System.currentTimeMillis();
        if (enableTimer) {
            sample = Timer.start(registry);
            this.preRecallPolicy.process(context);
            sample.stop(registry.timer("apiServer.timer.preRecallPolicy"));
        } else {
            this.preRecallPolicy.process(context);
        }
        end = System.currentTimeMillis();
        long preRecallLatency = end - start;
        context.setUniqueId(context.genUniqueId());

        // Recall item with itemRepository
        start = System.currentTimeMillis();
        List<Map<String, Object>> itemData;
        if (enableTimer) {
            sample = Timer.start(registry);
            itemData = this.itemRepository.getItems(context);
            sample.stop(registry.timer("apiServer.timer.itemRepository"));
        } else {
            itemData = this.itemRepository.getItems(context);
        }
        end = System.currentTimeMillis();
        long itemLatency = end - start;
        context.setItems(itemData);

        // TODO: PrePredict Policy
        start = System.currentTimeMillis();
        if (enableTimer) {
            sample = Timer.start(registry);
            this.prePredictPolicy.process(context);
            sample.stop(registry.timer("apiServer.timer.prePredictPolicy"));
        } else {
            this.prePredictPolicy.process(context);
        }
        end = System.currentTimeMillis();
        long prePredictLatency = end - start;

        //new features
        //context.setCommon(newFeatures(context.getCommon()));

        //wrap context
        //context = wrapContext(context);

        //TODO: filtration sold out
        long filtrationSoldOut = 0;
        start = System.currentTimeMillis();
        if (enableTimer) {
            sample = Timer.start(registry);
            this.filtrationSoldOutPolicy.process(context);
            sample.stop(registry.timer("apiServer.timer.filtrationSoldOut"));
        } else {
            this.filtrationSoldOutPolicy.process(context);
        }
        end = System.currentTimeMillis();
        filtrationSoldOut = end - start;

        // Calling Predictor
        start = System.currentTimeMillis();
        if (enableTimer) {
            sample = Timer.start(registry);
            this.makePrediction(context);
            sample.stop(registry.timer("apiServer.timer.makePrediction"));
        } else {
            this.makePrediction(context);
        }
        end = System.currentTimeMillis();
        long predictLatency = end - start;

        // ReRanking Stage
        start = System.currentTimeMillis();
        if (enableTimer) {
            sample = Timer.start(registry);
            this.reRankingPolicy.process(context);
            sample.stop(registry.timer("apiServer.timer.reRankingPolicy"));
        } else {
            this.reRankingPolicy.process(context);
        }
        end = System.currentTimeMillis();
        long reRankLatency = end - start;

        // Response Mapper
        start = System.currentTimeMillis();
        PredictRespDTO resp;
        if (enableTimer) {
            sample = Timer.start(registry);
            resp = this.respParamMapper.process(context);
            sample.stop(registry.timer("apiServer.timer.respParamMapper"));
        } else {
            resp = this.respParamMapper.process(context);
        }
        end = System.currentTimeMillis();
        long respMapperLatency = end - start;

        Map<String, Long> latencyMap = Maps.newHashMapWithExpectedSize(10);
        latencyMap.put("reqParamMapper", reqMapperLatency);
        latencyMap.put("userRepository", userLatency);
        latencyMap.put("preRecallPolicy", preRecallLatency);
        latencyMap.put("itemRepository", itemLatency);
        latencyMap.put("prePredictPolicy", prePredictLatency);
        latencyMap.put("conversionCost", conversionCost);
        latencyMap.put("predictor", predictLatency);
        latencyMap.put("reRankingPolicy", reRankLatency);
        latencyMap.put("respParamMapper", respMapperLatency);
        latencyMap.put("filtrationSoldOut", filtrationSoldOut);
        context.getExtraData().put("Latency", latencyMap);
        context.setResponse(resp);
        if (enableTimer) {
            sample = Timer.start(registry);
            this.contextLogger.write(context);
            sample.stop(registry.timer("apiServer.timer.contextLogger"));
        } else {
            this.contextLogger.write(context);
        }

        return resp;
    }

    public Context wrapContext(Context context) {
        List<Map<String, Object>> items = context.getItems();
        List<Map<String, Object>> it = new ArrayList<>();

        if (items == null || items.isEmpty()) {
            log.warn("items is null or empty");
            return context;
        }

        log.debug("candidate size: {}", items.size());

        for (Map<String, Object> itemsDetail : items) {
            Map<String, Object> map = new HashMap<>();
            Iterator<Map.Entry<String, Object>> idMap = itemsDetail.entrySet().iterator();
            while (idMap.hasNext()) {
                Map.Entry<String, Object> entry = idMap.next();
                if (null == TRANSITIONMAP.get(entry.getKey())) {
                    map.put(entry.getKey(), entry.getValue());
                    continue;
                }
                map.put(TRANSITIONMAP.get(entry.getKey()), entry.getValue());
            }
            it.add(map);
        }
        context.setItems(it);
        return context;
    }

    //transition
    public final static Map<String, String> TRANSITIONMAP = new HashMap<String, String>() {
        {
            put("cart_burger_sold","x1");
            put("cart_burger_sold_null_indicator","x2");
            put("cart_chickensnack_sold","x3");
            put("cart_chickensnack_sold_null_indicator","x4");
            put("cart_cob_sold","x5");
            put("cart_cob_sold_null_indicator","x6");
            put("cart_coffee_sold","x7");
            put("cart_coffee_sold_null_indicator","x8");
            put("cart_combo_croissant_sold","x9");
            put("cart_combo_croissant_sold_null_indicator","x10");
            put("cart_combo_csd_sold","x11");
            put("cart_combo_csd_sold_null_indicator","x12");
            put("cart_combo_dabing_sold","x13");
            put("cart_combo_dabing_sold_null_indicator","x14");
            put("cart_combo_eggtart_sold","x15");
            put("cart_combo_eggtart_sold_null_indicator","x16");
            put("cart_combo_icecream_sold","x17");
            put("cart_combo_icecream_sold_null_indicator","x18");
            put("cart_combo_juice_sold","x19");
            put("cart_combo_juice_sold_null_indicator","x20");
            put("cart_combo_lto_sold","x21");
            put("cart_combo_lto_sold_null_indicator","x22");
            put("cart_combo_nonfood_sold","x23");
            put("cart_combo_nonfood_sold_null_indicator","x24");
            put("cart_combo_nutrition_sold","x25");
            put("cart_combo_nutrition_sold_null_indicator","x26");
            put("cart_combo_panini_sold","x27");
            put("cart_combo_panini_sold_null_indicator","x28");
            put("cart_combo_pie_sold","x29");
            put("cart_combo_pie_sold_null_indicator","x30");
            put("cart_combo_rice_sold","x31");
            put("cart_combo_rice_sold_null_indicator","x32");
            put("cart_combo_sell_price","x33");
            put("cart_combo_sell_price_null_indicator","x34");
            put("cart_combo_sidefrenchfries_sold","x35");
            put("cart_combo_sidefrenchfries_sold_null_indicator","x36");
            put("cart_combo_sideothers_sold","x37");
            put("cart_combo_sideothers_sold_null_indicator","x38");
            put("cart_combo_tea_sold","x39");
            put("cart_combo_tea_sold_null_indicator","x40");
            put("cart_combo_twister_sold","x41");
            put("cart_combo_twister_sold_null_indicator","x42");
            put("cart_combo_unit_sold","x43");
            put("cart_combo_unit_sold_null_indicator","x44");
            put("cart_combo_waffle_sold","x45");
            put("cart_combo_waffle_sold_null_indicator","x46");
            put("cart_combo_wing_sold","x47");
            put("cart_combo_wing_sold_null_indicator","x48");
            put("cart_conge_sold","x49");
            put("cart_conge_sold_null_indicator","x50");
            put("cart_croissant_sold","x51");
            put("cart_croissant_sold_null_indicator","x52");
            put("cart_csd_sold","x53");
            put("cart_csd_sold_null_indicator","x54");
            put("cart_dabing_sold","x55");
            put("cart_dabing_sold_null_indicator","x56");
            put("cart_eggtart_sold","x57");
            put("cart_eggtart_sold_null_indicator","x58");
            put("cart_icecream_sold","x59");
            put("cart_icecream_sold_null_indicator","x60");
            put("cart_juice_sold","x61");
            put("cart_juice_sold_null_indicator","x62");
            put("cart_kidstoyflag","x63");
            put("cart_kidstoyflag_null_indicator","x64");
            put("cart_lto_sold","x65");
            put("cart_lto_sold_null_indicator","x66");
            put("cart_nonfood_sold","x67");
            put("cart_nonfood_sold_null_indicator","x68");
            put("cart_nutrition_sold","x69");
            put("cart_nutrition_sold_null_indicator","x70");
            put("cart_panini_sold","x71");
            put("cart_panini_sold_null_indicator","x72");
            put("cart_pie_sold","x73");
            put("cart_pie_sold_null_indicator","x74");
            put("cart_promo_burger_sold","x75");
            put("cart_promo_burger_sold_null_indicator","x76");
            put("cart_promo_chickensnack_sold","x77");
            put("cart_promo_chickensnack_sold_null_indicator","x78");
            put("cart_promo_cob_sold","x79");
            put("cart_promo_cob_sold_null_indicator","x80");
            put("cart_promo_coffee_sold","x81");
            put("cart_promo_coffee_sold_null_indicator","x82");
            put("cart_promo_eggtart_sold","x83");
            put("cart_promo_eggtart_sold_null_indicator","x84");
            put("cart_promo_icecream_sold","x85");
            put("cart_promo_icecream_sold_null_indicator","x86");
            put("cart_promo_juice_sold","x87");
            put("cart_promo_juice_sold_null_indicator","x88");
            put("cart_promo_lto_sold","x89");
            put("cart_promo_lto_sold_null_indicator","x90");
            put("cart_promo_nonfood_sold","x91");
            put("cart_promo_nonfood_sold_null_indicator","x92");
            put("cart_promo_nutrition_sold","x93");
            put("cart_promo_nutrition_sold_null_indicator","x94");
            put("cart_promo_panini_sold","x95");
            put("cart_promo_panini_sold_null_indicator","x96");
            put("cart_promo_pie_sold","x97");
            put("cart_promo_pie_sold_null_indicator","x98");
            put("cart_promo_riceroll_sold","x99");
            put("cart_promo_riceroll_sold_null_indicator","x100");
            put("cart_promo_sell_price","x101");
            put("cart_promo_sell_price_null_indicator","x102");
            put("cart_promo_side_sold","x103");
            put("cart_promo_side_sold_null_indicator","x104");
            put("cart_promo_sidefrenchfries_sold","x105");
            put("cart_promo_sidefrenchfries_sold_null_indicator","x106");
            put("cart_promo_sideothers_sold","x107");
            put("cart_promo_sideothers_sold_null_indicator","x108");
            put("cart_promo_tea_sold","x109");
            put("cart_promo_tea_sold_null_indicator","x110");
            put("cart_promo_twister_sold","x111");
            put("cart_promo_twister_sold_null_indicator","x112");
            put("cart_promo_unit_sold","x113");
            put("cart_promo_unit_sold_null_indicator","x114");
            put("cart_promo_waffle_sold","x115");
            put("cart_promo_waffle_sold_null_indicator","x116");
            put("cart_promo_wing_sold","x117");
            put("cart_promo_wing_sold_null_indicator","x118");
            put("cart_rice_sold","x119");
            put("cart_rice_sold_null_indicator","x120");
            put("cart_riceroll_sold","x121");
            put("cart_riceroll_sold_null_indicator","x122");
            put("cart_sidefrenchfries_sold","x123");
            put("cart_sidefrenchfries_sold_null_indicator","x124");
            put("cart_sideothers_sold","x125");
            put("cart_sideothers_sold_null_indicator","x126");
            put("cart_single_sell_price","x127");
            put("cart_single_sell_price_null_indicator","x128");
            put("cart_single_unit_sold","x129");
            put("cart_single_unit_sold_null_indicator","x130");
            put("cart_tea_sold","x131");
            put("cart_tea_sold_null_indicator","x132");
            put("cart_total_unit_sold","x133");
            put("cart_total_unit_sold_null_indicator","x134");
            put("cart_twister_sold","x135");
            put("cart_twister_sold_null_indicator","x136");
            put("cart_waffle_sold","x137");
            put("cart_waffle_sold_null_indicator","x138");
            put("cart_wing_sold","x139");
            put("cart_wing_sold_null_indicator","x140");
            put("category_sold_ratio","x141");
            put("category_sold_ratio_null_indicator","x142");
            put("cob_flag","x143");
            put("cob_flag_null_indicator","x144");
            put("coffee_flag","x145");
            put("coffee_flag_null_indicator","x146");
            put("conge_flag","x147");
            put("conge_flag_null_indicator","x148");
            put("croissant_flag","x149");
            put("croissant_flag_null_indicator","x150");
            put("csd_flag","x151");
            put("csd_flag_null_indicator","x152");
            put("dabing_flag","x153");
            put("dabing_flag_null_indicator","x154");
            put("daypart_sold_ratio","x155");
            put("daypart_sold_ratio_null_indicator","x156");
            put("eggtart_flag","x157");
            put("eggtart_flag_null_indicator","x158");
            put("icecream_flag","x159");
            put("icecream_flag_null_indicator","x160");
            put("itemRank","x161");
            put("itemRank_null_indicator","x162");
            put("item_alc_price","x163");
            put("item_alc_price_null_indicator","x164");
            put("item_sell_price","x165");
            put("item_sell_price_null_indicator","x166");
            put("juice_flag","x167");
            put("juice_flag_null_indicator","x168");
            put("kidstoyflag","x169");
            put("kidstoyflag_null_indicator","x170");
            put("lto_flag","x171");
            put("lto_flag_null_indicator","x172");
            put("newproduct_flag","x173");
            put("newproduct_flag_null_indicator","x174");
            put("nonfood_flag","x175");
            put("nonfood_flag_null_indicator","x176");
            put("nutrition_flag","x177");
            put("nutrition_flag_null_indicator","x178");
            put("panini_flag","x179");
            put("panini_flag_null_indicator","x180");
            put("pie_flag","x181");
            put("pie_flag_null_indicator","x182");
            put("price","x183");
            put("price_null_indicator","x184");
            put("rank","x185");
            put("rank_null_indicator","x186");
            put("rice_flag","x187");
            put("rice_flag_null_indicator","x188");
            put("riceroll_flag","x189");
            put("riceroll_flag_null_indicator","x190");
            put("s_afternoon_avgpartysize","x191");
            put("s_afternoon_avgpartysize_null_indicator","x192");
            put("s_afternoon_avgta","x193");
            put("s_afternoon_avgta_null_indicator","x194");
            put("s_afternoon_tc_ratio","x195");
            put("s_afternoon_tc_ratio_null_indicator","x196");
            put("s_avg_ta","x197");
            put("s_avg_ta_null_indicator","x198");
            put("s_breakfast_avgpartysize","x199");
            put("s_breakfast_avgpartysize_null_indicator","x200");
            put("s_breakfast_avgta","x201");
            put("s_breakfast_avgta_null_indicator","x202");
            put("s_breakfast_tc_ratio","x203");
            put("s_breakfast_tc_ratio_null_indicator","x204");
            put("s_burger_sold_ratio","x205");
            put("s_burger_sold_ratio_null_indicator","x206");
            put("s_chickensnack_sold_ratio","x207");
            put("s_chickensnack_sold_ratio_null_indicator","x208");
            put("s_cob_sold_ratio","x209");
            put("s_cob_sold_ratio_null_indicator","x210");
            put("s_coffee_sold_ratio","x211");
            put("s_coffee_sold_ratio_null_indicator","x212");
            put("s_congee_sold_ratio","x213");
            put("s_congee_sold_ratio_null_indicator","x214");
            put("s_croissant_sold_ratio","x215");
            put("s_croissant_sold_ratio_null_indicator","x216");
            put("s_csd_sold_ratio","x217");
            put("s_csd_sold_ratio_null_indicator","x218");
            put("s_dabing_sold_ratio","x219");
            put("s_dabing_sold_ratio_null_indicator","x220");
            put("s_dinner_avgpartysize","x221");
            put("s_dinner_avgpartysize_null_indicator","x222");
            put("s_dinner_avgta","x223");
            put("s_dinner_avgta_null_indicator","x224");
            put("s_dinner_tc_ratio","x225");
            put("s_dinner_tc_ratio_null_indicator","x226");
            put("s_eggtart_sold_ratio","x227");
            put("s_eggtart_sold_ratio_null_indicator","x228");
            put("s_icecream_sold_ratio","x229");
            put("s_icecream_sold_ratio_null_indicator","x230");
            put("s_juice_sold_ratio","x231");
            put("s_juice_sold_ratio_null_indicator","x232");
            put("s_latenight_avgpartysize","x233");
            put("s_latenight_avgpartysize_null_indicator","x234");
            put("s_latenight_avgta","x235");
            put("s_latenight_avgta_null_indicator","x236");
            put("s_latenight_tc_ratio","x237");
            put("s_latenight_tc_ratio_null_indicator","x238");
            put("s_lto_sold_ratio","x239");
            put("s_lto_sold_ratio_null_indicator","x240");
            put("s_lunch_avgpartysize","x241");
            put("s_lunch_avgpartysize_null_indicator","x242");
            put("s_lunch_avgta","x243");
            put("s_lunch_avgta_null_indicator","x244");
            put("s_lunch_tc_ratio","x245");
            put("s_lunch_tc_ratio_null_indicator","x246");
            put("s_morning_avgpartysize","x247");
            put("s_morning_avgpartysize_null_indicator","x248");
            put("s_morning_avgta","x249");
            put("s_morning_avgta_null_indicator","x250");
            put("s_morning_tc_ratio","x251");
            put("s_morning_tc_ratio_null_indicator","x252");
            put("s_nonfood_sold_ratio","x253");
            put("s_nonfood_sold_ratio_null_indicator","x254");
            put("s_nutrition_sold_ratio","x255");
            put("s_nutrition_sold_ratio_null_indicator","x256");
            put("s_panini_sold_ratio","x257");
            put("s_panini_sold_ratio_null_indicator","x258");
            put("s_pie_sold_ratio","x259");
            put("s_pie_sold_ratio_null_indicator","x260");
            put("s_rice_sold_ratio","x261");
            put("s_rice_sold_ratio_null_indicator","x262");
            put("s_riceroll_sold_ratio","x263");
            put("s_riceroll_sold_ratio_null_indicator","x264");
            put("s_side_sold_ratio","x265");
            put("s_side_sold_ratio_null_indicator","x266");
            put("s_sidefrenchfries_sold_ratio","x267");
            put("s_sidefrenchfries_sold_ratio_null_indicator","x268");
            put("s_sideothers_sold_ratio","x269");
            put("s_sideothers_sold_ratio_null_indicator","x270");
            put("s_sumta","x271");
            put("s_sumta_null_indicator","x272");
            put("s_sumtc","x273");
            put("s_sumtc_null_indicator","x274");
            put("s_tea_sold_ratio","x275");
            put("s_tea_sold_ratio_null_indicator","x276");
            put("s_transport","x277");
            put("s_transport_null_indicator","x278");
            put("s_twister_sold_ratio","x279");
            put("s_twister_sold_ratio_null_indicator","x280");
            put("s_typea","x281");
            put("s_typea_null_indicator","x282");
            put("s_typeapt","x283");
            put("s_typeapt_null_indicator","x284");
            put("s_typeb","x285");
            put("s_typeb_null_indicator","x286");
            put("s_typebs","x287");
            put("s_typebs_null_indicator","x288");
            put("s_typec","x289");
            put("s_typec_null_indicator","x290");
            put("s_typed","x291");
            put("s_typed_null_indicator","x292");
            put("s_typehp","x293");
            put("s_typehp_null_indicator","x294");
            put("s_typehw","x295");
            put("s_typehw_null_indicator","x296");
            put("s_typem","x297");
            put("s_typem_null_indicator","x298");
            put("s_typeo","x299");
            put("s_typeo_null_indicator","x300");
            put("s_typeot","x301");
            put("s_typeot_null_indicator","x302");
            put("s_typer","x303");
            put("s_typer_null_indicator","x304");
            put("s_types","x305");
            put("s_types_null_indicator","x306");
            put("s_typesm","x307");
            put("s_typesm_null_indicator","x308");
            put("s_typet","x309");
            put("s_typet_null_indicator","x310");
            put("s_typetpc","x311");
            put("s_typetpc_null_indicator","x312");
            put("s_typeu","x313");
            put("s_typeu_null_indicator","x314");
            put("s_typewm","x315");
            put("s_typewm_null_indicator","x316");
            put("s_typex","x317");
            put("s_typex_null_indicator","x318");
            put("s_typez","x319");
            put("s_typez_null_indicator","x320");
            put("s_waffle_sold_ratio","x321");
            put("s_waffle_sold_ratio_null_indicator","x322");
            put("s_wing_sold_ratio","x323");
            put("s_wing_sold_ratio_null_indicator","x324");
            put("side_flag","x325");
            put("side_flag_null_indicator","x326");
            put("sidefrenchfries_flag","x327");
            put("sidefrenchfries_flag_null_indicator","x328");
            put("sideothers_flag","x329");
            put("sideothers_flag_null_indicator","x330");
            put("ta","x331");
            put("ta_null_indicator","x332");
            put("tea_flag","x333");
            put("tea_flag_null_indicator","x334");
            put("twister_flag","x335");
            put("twister_flag_null_indicator","x336");
            put("u_afternoon_avgta","x337");
            put("u_afternoon_avgta_null_indicator","x338");
            put("u_afternoon_maxta","x339");
            put("u_afternoon_maxta_null_indicator","x340");
            put("u_afternoon_minta","x341");
            put("u_afternoon_minta_null_indicator","x342");
            put("u_afternoon_std_ta","x343");
            put("u_afternoon_std_ta_null_indicator","x344");
            put("u_afternoon_sumta","x345");
            put("u_afternoon_sumta_null_indicator","x346");
            put("u_afternoon_tc","x347");
            put("u_afternoon_tc_null_indicator","x348");
            put("u_avg_city_tier","x349");
            put("u_avg_city_tier_null_indicator","x350");
            put("u_avg_delivery_party_size","x351");
            put("u_avg_delivery_party_size_null_indicator","x352");
            put("u_avg_discount","x353");
            put("u_avg_discount_null_indicator","x354");
            put("u_avg_party_size","x355");
            put("u_avg_party_size_null_indicator","x356");
            put("u_avg_preorder_party_size","x357");
            put("u_avg_preorder_party_size_null_indicator","x358");
            put("u_avg_preorder_party_size_null_indicator","x358");
            put("u_avg_ta_by_ps","x359");
            put("u_avg_ta_by_ps_null_indicator","x360");
            put("u_breakfast_avgta","x361");
            put("u_breakfast_avgta_null_indicator","x362");
            put("u_breakfast_maxta","x363");
            put("u_breakfast_maxta_null_indicator","x364");
            put("u_breakfast_minta","x365");
            put("u_breakfast_minta_null_indicator","x366");
            put("u_breakfast_std_ta","x367");
            put("u_breakfast_std_ta_null_indicator","x368");
            put("u_breakfast_sumta","x369");
            put("u_breakfast_sumta_null_indicator","x370");
            put("u_breakfast_tc","x371");
            put("u_breakfast_tc_null_indicator","x372");
            put("u_breakfastcard_flag","x373");
            put("u_breakfastcard_flag_null_indicator","x374");
            put("u_burger_sell_price","x375");
            put("u_burger_sell_price_null_indicator","x376");
            put("u_burger_sold","x377");
            put("u_burger_sold_null_indicator","x378");
            put("u_chicken_burger_soldratio_crusty","x379");
            put("u_chicken_burger_soldratio_crusty_null_indicator","x380");
            put("u_chicken_burger_soldratio_orlean","x381");
            put("u_chicken_burger_soldratio_orlean_null_indicator","x382");
            put("u_chicken_burger_soldratio_spicy","x383");
            put("u_chicken_burger_soldratio_spicy_null_indicator","x384");
            put("u_chickensnack_sell_price","x385");
            put("u_chickensnack_sell_price_null_indicator","x386");
            put("u_chickensnack_sold","x387");
            put("u_chickensnack_sold_null_indicator","x388");
            put("u_cob_sell_price","x389");
            put("u_cob_sell_price_null_indicator","x390");
            put("u_cob_sold","x391");
            put("u_cob_sold_null_indicator","x392");
            put("u_coffee_sell_price","x393");
            put("u_coffee_sell_price_null_indicator","x394");
            put("u_coffee_sold","x395");
            put("u_coffee_sold_null_indicator","x396");
            put("u_coffeecard_flag","x397");
            put("u_coffeecard_flag_null_indicator","x398");
            put("u_combo_product_number","x399");
            put("u_combo_product_number_null_indicator","x400");
            put("u_congee_sell_price","x401");
            put("u_congee_sell_price_null_indicator","x402");
            put("u_congee_sold","x403");
            put("u_congee_sold_null_indicator","x404");
            put("u_cor_ta_da","x405");
            put("u_cor_ta_da_null_indicator","x406");
            put("u_croissant_sell_price","x407");
            put("u_croissant_sell_price_null_indicator","x408");
            put("u_croissant_sold","x409");
            put("u_croissant_sold_null_indicator","x410");
            put("u_csd_sell_price","x411");
            put("u_csd_sell_price_null_indicator","x412");
            put("u_csd_sold","x413");
            put("u_csd_sold_null_indicator","x414");
            put("u_dabing_sell_price","x415");
            put("u_dabing_sell_price_null_indicator","x416");
            put("u_dabing_sold","x417");
            put("u_dabing_sold_null_indicator","x418");
            put("u_dashencard_flag","x419");
            put("u_dashencard_flag_null_indicator","x420");
            put("u_delivery_ta","x421");
            put("u_delivery_ta_null_indicator","x422");
            put("u_delivery_tc","x423");
            put("u_delivery_tc_null_indicator","x424");
            put("u_deliverycard_flag","x425");
            put("u_deliverycard_flag_null_indicator","x426");
            put("u_dinner_avgta","x427");
            put("u_dinner_avgta_null_indicator","x428");
            put("u_dinner_maxta","x429");
            put("u_dinner_maxta_null_indicator","x430");
            put("u_dinner_minta","x431");
            put("u_dinner_minta_null_indicator","x432");
            put("u_dinner_std_ta","x433");
            put("u_dinner_std_ta_null_indicator","x434");
            put("u_dinner_sumta","x435");
            put("u_dinner_sumta_null_indicator","x436");
            put("u_dinner_tc","x437");
            put("u_dinner_tc_null_indicator","x438");
            put("u_distinct_city","x439");
            put("u_distinct_city_null_indicator","x440");
            put("u_distinct_daypart","x441");
            put("u_distinct_daypart_null_indicator","x442");
            put("u_distinct_store","x443");
            put("u_distinct_store_null_indicator","x444");
            put("u_distinct_work_day","x445");
            put("u_distinct_work_day_null_indicator","x446");
            put("u_eggtart_sell_price","x447");
            put("u_eggtart_sell_price_null_indicator","x448");
            put("u_eggtart_sold","x449");
            put("u_eggtart_sold_null_indicator","x450");
            put("u_fri_avgta","x451");
            put("u_fri_avgta_null_indicator","x452");
            put("u_fri_maxta","x453");
            put("u_fri_maxta_null_indicator","x454");
            put("u_fri_minta","x455");
            put("u_fri_minta_null_indicator","x456");
            put("u_fri_std_ta","x457");
            put("u_fri_std_ta_null_indicator","x458");
            put("u_fri_sumta","x459");
            put("u_fri_sumta_null_indicator","x460");
            put("u_fri_tc","x461");
            put("u_fri_tc_null_indicator","x462");
            put("u_icecream_sell_price","x463");
            put("u_icecream_sell_price_null_indicator","x464");
            put("u_icecream_sold","x465");
            put("u_icecream_sold_null_indicator","x466");
            put("u_juice_sell_price","x467");
            put("u_juice_sell_price_null_indicator","x468");
            put("u_juice_sold","x469");
            put("u_juice_sold_null_indicator","x470");
            put("u_kids_meal_toy_num","x471");
            put("u_kids_meal_toy_num_null_indicator","x472");
            put("u_lasttrans_b_city_tier","x473");
            put("u_lasttrans_b_city_tier_null_indicator","x474");
            put("u_lasttrans_b_ta","x475");
            put("u_lasttrans_b_ta_null_indicator","x476");
            put("u_lasttrans_nb_city_tier","x477");
            put("u_lasttrans_nb_city_tier_null_indicator","x478");
            put("u_lasttrans_nb_ta","x479");
            put("u_lasttrans_nb_ta_null_indicator","x480");
            put("u_latenight_avgta","x481");
            put("u_latenight_avgta_null_indicator","x482");
            put("u_latenight_maxta","x483");
            put("u_latenight_maxta_null_indicator","x484");
            put("u_latenight_minta","x485");
            put("u_latenight_minta_null_indicator","x486");
            put("u_latenight_std_ta","x487");
            put("u_latenight_std_ta_null_indicator","x488");
            put("u_latenight_sumta","x489");
            put("u_latenight_sumta_null_indicator","x490");
            put("u_latenight_tc","x491");
            put("u_latenight_tc_null_indicator","x492");
            put("u_lto_sell_price","x493");
            put("u_lto_sell_price_null_indicator","x494");
            put("u_lto_sold","x495");
            put("u_lto_sold_null_indicator","x496");
            put("u_lunch_avgta","x497");
            put("u_lunch_avgta_null_indicator","x498");
            put("u_lunch_maxta","x499");
            put("u_lunch_maxta_null_indicator","x500");
            put("u_lunch_minta","x501");
            put("u_lunch_minta_null_indicator","x502");
            put("u_lunch_std_ta","x503");
            put("u_lunch_std_ta_null_indicator","x504");
            put("u_lunch_sumta","x505");
            put("u_lunch_sumta_null_indicator","x506");
            put("u_lunch_tc","x507");
            put("u_lunch_tc_null_indicator","x508");
            put("u_max_city_tier","x509");
            put("u_max_city_tier_null_indicator","x510");
            put("u_max_delivery_party_size","x511");
            put("u_max_delivery_party_size_null_indicator","x512");
            put("u_max_discount","x513");
            put("u_max_discount_null_indicator","x514");
            put("u_max_party_size","x515");
            put("u_max_party_size_null_indicator","x516");
            put("u_max_preorder_party_size","x517");
            put("u_max_preorder_party_size_null_indicator","x518");
            put("u_min_city_tier","x519");
            put("u_min_city_tier_null_indicator","x520");
            put("u_min_delivery_party_size","x521");
            put("u_min_delivery_party_size_null_indicator","x522");
            put("u_min_discount","x523");
            put("u_min_discount_null_indicator","x524");
            put("u_min_party_size","x525");
            put("u_min_party_size_null_indicator","x526");
            put("u_min_preorder_party_size","x527");
            put("u_min_preorder_party_size_null_indicator","x528");
            put("u_mon_avgta","x529");
            put("u_mon_avgta_null_indicator","x530");
            put("u_mon_maxta","x531");
            put("u_mon_maxta_null_indicator","x532");
            put("u_mon_minta","x533");
            put("u_mon_minta_null_indicator","x534");
            put("u_mon_std_ta","x535");
            put("u_mon_std_ta_null_indicator","x536");
            put("u_mon_sumta","x537");
            put("u_mon_sumta_null_indicator","x538");
            put("u_mon_tc","x539");
            put("u_mon_tc_null_indicator","x540");
            put("u_morning_avgta","x541");
            put("u_morning_avgta_null_indicator","x542");
            put("u_morning_maxta","x543");
            put("u_morning_maxta_null_indicator","x544");
            put("u_morning_minta","x545");
            put("u_morning_minta_null_indicator","x546");
            put("u_morning_std_ta","x547");
            put("u_morning_std_ta_null_indicator","x548");
            put("u_morning_sumta","x549");
            put("u_morning_sumta_null_indicator","x550");
            put("u_morning_tc","x551");
            put("u_morning_tc_null_indicator","x552");
            put("u_nonbreakfast_avgta","x553");
            put("u_nonbreakfast_avgta_null_indicator","x554");
            put("u_nonbreakfast_maxta","x555");
            put("u_nonbreakfast_maxta_null_indicator","x556");
            put("u_nonbreakfast_minta","x557");
            put("u_nonbreakfast_minta_null_indicator","x558");
            put("u_nonbreakfast_std_ta","x559");
            put("u_nonbreakfast_std_ta_null_indicator","x560");
            put("u_nonbreakfast_sumta","x561");
            put("u_nonbreakfast_sumta_null_indicator","x562");
            put("u_nonbreakfast_tc","x563");
            put("u_nonbreakfast_tc_null_indicator","x564");
            put("u_nonfood_sell_price","x565");
            put("u_nonfood_sell_price_null_indicator","x566");
            put("u_nonfood_sold","x567");
            put("u_nonfood_sold_null_indicator","x568");
            put("u_nutrition_sell_price","x569");
            put("u_nutrition_sell_price_null_indicator","x570");
            put("u_nutrition_sold","x571");
            put("u_nutrition_sold_null_indicator","x572");
            put("u_panini_sell_price","x573");
            put("u_panini_sell_price_null_indicator","x574");
            put("u_panini_sold","x575");
            put("u_panini_sold_null_indicator","x576");
            put("u_pie_sell_price","x577");
            put("u_pie_sell_price_null_indicator","x578");
            put("u_pie_sold","x579");
            put("u_pie_sold_null_indicator","x580");
            put("u_preorder_ta","x581");
            put("u_preorder_ta_null_indicator","x582");
            put("u_preorder_tc","x583");
            put("u_preorder_tc_null_indicator","x584");
            put("u_rice_sell_price","x585");
            put("u_rice_sell_price_null_indicator","x586");
            put("u_rice_sold","x587");
            put("u_rice_sold_null_indicator","x588");
            put("u_riceroll_sell_price","x589");
            put("u_riceroll_sell_price_null_indicator","x590");
            put("u_riceroll_sold","x591");
            put("u_riceroll_sold_null_indicator","x592");
            put("u_sat_avgta","x593");
            put("u_sat_avgta_null_indicator","x594");
            put("u_sat_maxta","x595");
            put("u_sat_maxta_null_indicator","x596");
            put("u_sat_minta","x597");
            put("u_sat_minta_null_indicator","x598");
            put("u_sat_std_ta","x599");
            put("u_sat_std_ta_null_indicator","x600");
            put("u_sat_sumta","x601");
            put("u_sat_sumta_null_indicator","x602");
            put("u_sat_tc","x603");
            put("u_sat_tc_null_indicator","x604");
            put("u_side_sell_price","x605");
            put("u_side_sell_price_null_indicator","x606");
            put("u_side_sold","x607");
            put("u_side_sold_null_indicator","x608");
            put("u_sidefrenchfries_sell_price","x609");
            put("u_sidefrenchfries_sell_price_null_indicator","x610");
            put("u_sidefrenchfries_sold","x611");
            put("u_sidefrenchfries_sold_null_indicator","x612");
            put("u_sideothers_sell_price","x613");
            put("u_sideothers_sell_price_null_indicator","x614");
            put("u_sideothers_sold","x615");
            put("u_sideothers_sold_null_indicator","x616");
            put("u_single_product_number","x617");
            put("u_single_product_number_null_indicator","x618");
            put("u_std_city_tier","x619");
            put("u_std_city_tier_null_indicator","x620");
            put("u_std_delivery_party_size","x621");
            put("u_std_delivery_party_size_null_indicator","x622");
            put("u_std_discount","x623");
            put("u_std_discount_null_indicator","x624");
            put("u_std_party_size","x625");
            put("u_std_party_size_null_indicator","x626");
            put("u_std_preorder_party_size","x627");
            put("u_std_preorder_party_size_null_indicator","x628");
            put("u_std_ta_by_ps","x629");
            put("u_std_ta_by_ps_null_indicator","x630");
            put("u_sum_discount","x631");
            put("u_sum_discount_null_indicator","x632");
            put("u_sun_avgta","x633");
            put("u_sun_avgta_null_indicator","x634");
            put("u_sun_maxta","x635");
            put("u_sun_maxta_null_indicator","x636");
            put("u_sun_minta","x637");
            put("u_sun_minta_null_indicator","x638");
            put("u_sun_std_ta","x639");
            put("u_sun_std_ta_null_indicator","x640");
            put("u_sun_sumta","x641");
            put("u_sun_sumta_null_indicator","x642");
            put("u_sun_tc","x643");
            put("u_sun_tc_null_indicator","x644");
            put("u_ta","x645");
            put("u_ta_null_indicator","x646");
            put("u_tc","x647");
            put("u_tc_null_indicator","x648");
            put("u_tea_sell_price","x649");
            put("u_tea_sell_price_null_indicator","x650");
            put("u_tea_sold","x651");
            put("u_tea_sold_null_indicator","x652");
            put("u_thu_avgta","x653");
            put("u_thu_avgta_null_indicator","x654");
            put("u_thu_maxta","x655");
            put("u_thu_maxta_null_indicator","x656");
            put("u_thu_minta","x657");
            put("u_thu_minta_null_indicator","x658");
            put("u_thu_std_ta","x659");
            put("u_thu_std_ta_null_indicator","x660");
            put("u_thu_sumta","x661");
            put("u_thu_sumta_null_indicator","x662");
            put("u_thu_tc","x663");
            put("u_thu_tc_null_indicator","x664");
            put("u_tier1_tc","x665");
            put("u_tier1_tc_null_indicator","x666");
            put("u_tier2_tc","x667");
            put("u_tier2_tc_null_indicator","x668");
            put("u_tier3_tc","x669");
            put("u_tier3_tc_null_indicator","x670");
            put("u_tier4_tc","x671");
            put("u_tier4_tc_null_indicator","x672");
            put("u_tier5_tc","x673");
            put("u_tier5_tc_null_indicator","x674");
            put("u_tier6_tc","x675");
            put("u_tier6_tc_null_indicator","x676");
            put("u_trade_up_num","x677");
            put("u_trade_up_num_null_indicator","x678");
            put("u_tue_avgta","x679");
            put("u_tue_avgta_null_indicator","x680");
            put("u_tue_maxta","x681");
            put("u_tue_maxta_null_indicator","x682");
            put("u_tue_minta","x683");
            put("u_tue_minta_null_indicator","x684");
            put("u_tue_std_ta","x685");
            put("u_tue_std_ta_null_indicator","x686");
            put("u_tue_sumta","x687");
            put("u_tue_sumta_null_indicator","x688");
            put("u_tue_tc","x689");
            put("u_tue_tc_null_indicator","x690");
            put("u_twister_sell_price","x691");
            put("u_twister_sell_price_null_indicator","x692");
            put("u_twister_sold","x693");
            put("u_twister_sold_null_indicator","x694");
            put("u_waffle_sell_price","x695");
            put("u_waffle_sell_price_null_indicator","x696");
            put("u_waffle_sold","x697");
            put("u_waffle_sold_null_indicator","x698");
            put("u_wen_avgta","x699");
            put("u_wen_avgta_null_indicator","x700");
            put("u_wen_maxta","x701");
            put("u_wen_maxta_null_indicator","x702");
            put("u_wen_minta","x703");
            put("u_wen_minta_null_indicator","x704");
            put("u_wen_std_ta","x705");
            put("u_wen_std_ta_null_indicator","x706");
            put("u_wen_sumta","x707");
            put("u_wen_sumta_null_indicator","x708");
            put("u_wen_tc","x709");
            put("u_wen_tc_null_indicator","x710");
            put("u_wing_sell_price","x711");
            put("u_wing_sell_price_null_indicator","x712");
            put("u_wing_sold","x713");
            put("u_wing_sold_null_indicator","x714");
            put("val","x715");
            put("val_null_indicator","x716");
            put("waffle_flag","x717");
            put("waffle_flag_null_indicator","x718");
            put("wing_flag","x719");
            put("wing_flag_null_indicator","x720");
            put("cart_drink_deprecate","x721");
            put("cart_drink_deprecate_null_indicator","x722");
            put("cart_main_deprecate","x723");
            put("cart_main_deprecate_null_indicator","x724");
            put("cart_party_size","x725");
            put("cart_party_size_null_indicator","x726");
            put("cart_promo_recommendation_diff","x727");
            put("cart_promo_recommendation_diff_null_indicator","x728");
            put("cart_promo_recommendation_overlap","x729");
            put("cart_promo_recommendation_overlap_null_indicator","x730");
            put("cart_side_deprecate","x731");
            put("cart_side_deprecate_null_indicator","x732");
            put("cart_sweet_deprecate","x733");
            put("cart_sweet_deprecate_null_indicator","x734");
            put("dayofweek","x735");
            put("dayofweek_null_indicator","x736");
            put("cart_combo_burger_sold","x737");
            put("cart_combo_riceroll_sold","x738");
            put("cart_promo_rice_sold","x739");
            put("burger_flag","x740");
            put("chickensnack_flag","x741");
            put("cart_promo_conge_sold","x742");
            put("cart_promo_croissant_sold","x743");
            put("cart_promo_csd_sold","x744");
            put("cart_promo_dabing_sold","x745");
        }
    };


    public final static Map<String, Object> DEFAULTMAP = new HashMap<String, Object>() {
        {
            put("x1","0");
            put("x2","0");
            put("x3","0");
            put("x4","0");
            put("x5","0");
            put("x6","0");
            put("x7","0");
            put("x8","0");
            put("x9","0");
            put("x10","0");
            put("x11","0");
            put("x12","0");
            put("x13","0");
            put("x14","0");
            put("x15","0");
            put("x16","0");
            put("x17","0");
            put("x18","0");
            put("x19","0");
            put("x20","0");
            put("x21","0");
            put("x22","0");
            put("x23","0");
            put("x24","0");
            put("x25","0");
            put("x26","0");
            put("x27","0");
            put("x28","0");
            put("x29","0");
            put("x30","0");
            put("x31","0");
            put("x32","0");
            put("x33","0");
            put("x34","0");
            put("x35","0");
            put("x36","0");
            put("x37","0");
            put("x38","0");
            put("x39","0");
            put("x40","0");
            put("x41","0");
            put("x42","0");
            put("x43","0");
            put("x44","0");
            put("x45","0");
            put("x46","0");
            put("x47","0");
            put("x48","0");
            put("x49","0");
            put("x50","0");
            put("x51","0");
            put("x52","0");
            put("x53","0");
            put("x54","0");
            put("x55","0");
            put("x56","0");
            put("x57","0");
            put("x58","0");
            put("x59","0");
            put("x60","0");
            put("x61","0");
            put("x62","0");
            put("x63","0");
            put("x64","0");
            put("x65","0");
            put("x66","0");
            put("x67","0");
            put("x68","0");
            put("x69","0");
            put("x70","0");
            put("x71","0");
            put("x72","0");
            put("x73","0");
            put("x74","0");
            put("x75","0");
            put("x76","0");
            put("x77","0");
            put("x78","0");
            put("x79","0");
            put("x80","0");
            put("x81","0");
            put("x82","0");
            put("x83","0");
            put("x84","0");
            put("x85","0");
            put("x86","0");
            put("x87","0");
            put("x88","0");
            put("x89","0");
            put("x90","0");
            put("x91","0");
            put("x92","0");
            put("x93","0");
            put("x94","0");
            put("x95","0");
            put("x96","0");
            put("x97","0");
            put("x98","0");
            put("x99","0");
            put("x100","0");
            put("x101","0");
            put("x102","0");
            put("x103","0");
            put("x104","0");
            put("x105","0");
            put("x106","0");
            put("x107","0");
            put("x108","0");
            put("x109","0");
            put("x110","0");
            put("x111","0");
            put("x112","0");
            put("x113","0");
            put("x114","0");
            put("x115","0");
            put("x116","0");
            put("x117","0");
            put("x118","0");
            put("x119","0");
            put("x120","0");
            put("x121","0");
            put("x122","0");
            put("x123","0");
            put("x124","0");
            put("x125","0");
            put("x126","0");
            put("x127","0");
            put("x128","0");
            put("x129","0");
            put("x130","0");
            put("x131","0");
            put("x132","0");
            put("x133","0");
            put("x134","0");
            put("x135","0");
            put("x136","0");
            put("x137","0");
            put("x138","0");
            put("x139","0");
            put("x140","0");
            put("x141","0");
            put("x142","0");
            put("x143","0");
            put("x144","0");
            put("x145","0");
            put("x146","0");
            put("x147","0");
            put("x148","0");
            put("x149","0");
            put("x150","0");
            put("x151","0");
            put("x152","0");
            put("x153","0");
            put("x154","0");
            put("x155","0");
            put("x156","0");
            put("x157","0");
            put("x158","0");
            put("x159","0");
            put("x160","0");
            put("x161","0");
            put("x162","0");
            put("x163","0");
            put("x164","0");
            put("x165","0");
            put("x166","0");
            put("x167","0");
            put("x168","0");
            put("x169","0");
            put("x170","0");
            put("x171","0");
            put("x172","0");
            put("x173","0");
            put("x174","0");
            put("x175","0");
            put("x176","0");
            put("x177","0");
            put("x178","0");
            put("x179","0");
            put("x180","0");
            put("x181","0");
            put("x182","0");
            put("x183","0");
            put("x184","0");
            put("x185","0");
            put("x186","0");
            put("x187","0");
            put("x188","0");
            put("x189","0");
            put("x190","0");
            put("x191","0");
            put("x192","0");
            put("x193","0");
            put("x194","0");
            put("x195","0");
            put("x196","0");
            put("x197","0");
            put("x198","0");
            put("x199","0");
            put("x200","0");
            put("x201","0");
            put("x202","0");
            put("x203","0");
            put("x204","0");
            put("x205","0");
            put("x206","0");
            put("x207","0");
            put("x208","0");
            put("x209","0");
            put("x210","0");
            put("x211","0");
            put("x212","0");
            put("x213","0");
            put("x214","0");
            put("x215","0");
            put("x216","0");
            put("x217","0");
            put("x218","0");
            put("x219","0");
            put("x220","0");
            put("x221","0");
            put("x222","0");
            put("x223","0");
            put("x224","0");
            put("x225","0");
            put("x226","0");
            put("x227","0");
            put("x228","0");
            put("x229","0");
            put("x230","0");
            put("x231","0");
            put("x232","0");
            put("x233","0");
            put("x234","0");
            put("x235","0");
            put("x236","0");
            put("x237","0");
            put("x238","0");
            put("x239","0");
            put("x240","0");
            put("x241","0");
            put("x242","0");
            put("x243","0");
            put("x244","0");
            put("x245","0");
            put("x246","0");
            put("x247","0");
            put("x248","0");
            put("x249","0");
            put("x250","0");
            put("x251","0");
            put("x252","0");
            put("x253","0");
            put("x254","0");
            put("x255","0");
            put("x256","0");
            put("x257","0");
            put("x258","0");
            put("x259","0");
            put("x260","0");
            put("x261","0");
            put("x262","0");
            put("x263","0");
            put("x264","0");
            put("x265","0");
            put("x266","0");
            put("x267","0");
            put("x268","0");
            put("x269","0");
            put("x270","0");
            put("x271","0");
            put("x272","0");
            put("x273","0");
            put("x274","0");
            put("x275","0");
            put("x276","0");
            put("x277","0");
            put("x278","0");
            put("x279","0");
            put("x280","0");
            put("x281","0");
            put("x282","0");
            put("x283","0");
            put("x284","0");
            put("x285","0");
            put("x286","0");
            put("x287","0");
            put("x288","0");
            put("x289","0");
            put("x290","0");
            put("x291","0");
            put("x292","0");
            put("x293","0");
            put("x294","0");
            put("x295","0");
            put("x296","0");
            put("x297","0");
            put("x298","0");
            put("x299","0");
            put("x300","0");
            put("x301","0");
            put("x302","0");
            put("x303","0");
            put("x304","0");
            put("x305","0");
            put("x306","0");
            put("x307","0");
            put("x308","0");
            put("x309","0");
            put("x310","0");
            put("x311","0");
            put("x312","0");
            put("x313","0");
            put("x314","0");
            put("x315","0");
            put("x316","0");
            put("x317","0");
            put("x318","0");
            put("x319","0");
            put("x320","0");
            put("x321","0");
            put("x322","0");
            put("x323","0");
            put("x324","0");
            put("x325","0");
            put("x326","0");
            put("x327","0");
            put("x328","0");
            put("x329","0");
            put("x330","0");
            put("x331","0");
            put("x332","0");
            put("x333","0");
            put("x334","0");
            put("x335","0");
            put("x336","0");
            put("x337","0");
            put("x338","0");
            put("x339","0");
            put("x340","0");
            put("x341","0");
            put("x342","0");
            put("x343","0");
            put("x344","0");
            put("x345","0");
            put("x346","0");
            put("x347","0");
            put("x348","0");
            put("x349","0");
            put("x350","0");
            put("x351","0");
            put("x352","0");
            put("x353","0");
            put("x354","0");
            put("x355","0");
            put("x356","0");
            put("x357","0");
            put("x358","0");
            put("x358","0");
            put("x359","0");
            put("x360","0");
            put("x361","0");
            put("x362","0");
            put("x363","0");
            put("x364","0");
            put("x365","0");
            put("x366","0");
            put("x367","0");
            put("x368","0");
            put("x369","0");
            put("x370","0");
            put("x371","0");
            put("x372","0");
            put("x373","0");
            put("x374","0");
            put("x375","0");
            put("x376","0");
            put("x377","0");
            put("x378","0");
            put("x379","0");
            put("x380","0");
            put("x381","0");
            put("x382","0");
            put("x383","0");
            put("x384","0");
            put("x385","0");
            put("x386","0");
            put("x387","0");
            put("x388","0");
            put("x389","0");
            put("x390","0");
            put("x391","0");
            put("x392","0");
            put("x393","0");
            put("x394","0");
            put("x395","0");
            put("x396","0");
            put("x397","0");
            put("x398","0");
            put("x399","0");
            put("x400","0");
            put("x401","0");
            put("x402","0");
            put("x403","0");
            put("x404","0");
            put("x405","0");
            put("x406","0");
            put("x407","0");
            put("x408","0");
            put("x409","0");
            put("x410","0");
            put("x411","0");
            put("x412","0");
            put("x413","0");
            put("x414","0");
            put("x415","0");
            put("x416","0");
            put("x417","0");
            put("x418","0");
            put("x419","0");
            put("x420","0");
            put("x421","0");
            put("x422","0");
            put("x423","0");
            put("x424","0");
            put("x425","0");
            put("x426","0");
            put("x427","0");
            put("x428","0");
            put("x429","0");
            put("x430","0");
            put("x431","0");
            put("x432","0");
            put("x433","0");
            put("x434","0");
            put("x435","0");
            put("x436","0");
            put("x437","0");
            put("x438","0");
            put("x439","0");
            put("x440","0");
            put("x441","0");
            put("x442","0");
            put("x443","0");
            put("x444","0");
            put("x445","0");
            put("x446","0");
            put("x447","0");
            put("x448","0");
            put("x449","0");
            put("x450","0");
            put("x451","0");
            put("x452","0");
            put("x453","0");
            put("x454","0");
            put("x455","0");
            put("x456","0");
            put("x457","0");
            put("x458","0");
            put("x459","0");
            put("x460","0");
            put("x461","0");
            put("x462","0");
            put("x463","0");
            put("x464","0");
            put("x465","0");
            put("x466","0");
            put("x467","0");
            put("x468","0");
            put("x469","0");
            put("x470","0");
            put("x471","0");
            put("x472","0");
            put("x473","0");
            put("x474","0");
            put("x475","0");
            put("x476","0");
            put("x477","0");
            put("x478","0");
            put("x479","0");
            put("x480","0");
            put("x481","0");
            put("x482","0");
            put("x483","0");
            put("x484","0");
            put("x485","0");
            put("x486","0");
            put("x487","0");
            put("x488","0");
            put("x489","0");
            put("x490","0");
            put("x491","0");
            put("x492","0");
            put("x493","0");
            put("x494","0");
            put("x495","0");
            put("x496","0");
            put("x497","0");
            put("x498","0");
            put("x499","0");
            put("x500","0");
            put("x501","0");
            put("x502","0");
            put("x503","0");
            put("x504","0");
            put("x505","0");
            put("x506","0");
            put("x507","0");
            put("x508","0");
            put("x509","0");
            put("x510","0");
            put("x511","0");
            put("x512","0");
            put("x513","0");
            put("x514","0");
            put("x515","0");
            put("x516","0");
            put("x517","0");
            put("x518","0");
            put("x519","0");
            put("x520","0");
            put("x521","0");
            put("x522","0");
            put("x523","0");
            put("x524","0");
            put("x525","0");
            put("x526","0");
            put("x527","0");
            put("x528","0");
            put("x529","0");
            put("x530","0");
            put("x531","0");
            put("x532","0");
            put("x533","0");
            put("x534","0");
            put("x535","0");
            put("x536","0");
            put("x537","0");
            put("x538","0");
            put("x539","0");
            put("x540","0");
            put("x541","0");
            put("x542","0");
            put("x543","0");
            put("x544","0");
            put("x545","0");
            put("x546","0");
            put("x547","0");
            put("x548","0");
            put("x549","0");
            put("x550","0");
            put("x551","0");
            put("x552","0");
            put("x553","0");
            put("x554","0");
            put("x555","0");
            put("x556","0");
            put("x557","0");
            put("x558","0");
            put("x559","0");
            put("x560","0");
            put("x561","0");
            put("x562","0");
            put("x563","0");
            put("x564","0");
            put("x565","0");
            put("x566","0");
            put("x567","0");
            put("x568","0");
            put("x569","0");
            put("x570","0");
            put("x571","0");
            put("x572","0");
            put("x573","0");
            put("x574","0");
            put("x575","0");
            put("x576","0");
            put("x577","0");
            put("x578","0");
            put("x579","0");
            put("x580","0");
            put("x581","0");
            put("x582","0");
            put("x583","0");
            put("x584","0");
            put("x585","0");
            put("x586","0");
            put("x587","0");
            put("x588","0");
            put("x589","0");
            put("x590","0");
            put("x591","0");
            put("x592","0");
            put("x593","0");
            put("x594","0");
            put("x595","0");
            put("x596","0");
            put("x597","0");
            put("x598","0");
            put("x599","0");
            put("x600","0");
            put("x601","0");
            put("x602","0");
            put("x603","0");
            put("x604","0");
            put("x605","0");
            put("x606","0");
            put("x607","0");
            put("x608","0");
            put("x609","0");
            put("x610","0");
            put("x611","0");
            put("x612","0");
            put("x613","0");
            put("x614","0");
            put("x615","0");
            put("x616","0");
            put("x617","0");
            put("x618","0");
            put("x619","0");
            put("x620","0");
            put("x621","0");
            put("x622","0");
            put("x623","0");
            put("x624","0");
            put("x625","0");
            put("x626","0");
            put("x627","0");
            put("x628","0");
            put("x629","0");
            put("x630","0");
            put("x631","0");
            put("x632","0");
            put("x633","0");
            put("x634","0");
            put("x635","0");
            put("x636","0");
            put("x637","0");
            put("x638","0");
            put("x639","0");
            put("x640","0");
            put("x641","0");
            put("x642","0");
            put("x643","0");
            put("x644","0");
            put("x645","0");
            put("x646","0");
            put("x647","0");
            put("x648","0");
            put("x649","0");
            put("x650","0");
            put("x651","0");
            put("x652","0");
            put("x653","0");
            put("x654","0");
            put("x655","0");
            put("x656","0");
            put("x657","0");
            put("x658","0");
            put("x659","0");
            put("x660","0");
            put("x661","0");
            put("x662","0");
            put("x663","0");
            put("x664","0");
            put("x665","0");
            put("x666","0");
            put("x667","0");
            put("x668","0");
            put("x669","0");
            put("x670","0");
            put("x671","0");
            put("x672","0");
            put("x673","0");
            put("x674","0");
            put("x675","0");
            put("x676","0");
            put("x677","0");
            put("x678","0");
            put("x679","0");
            put("x680","0");
            put("x681","0");
            put("x682","0");
            put("x683","0");
            put("x684","0");
            put("x685","0");
            put("x686","0");
            put("x687","0");
            put("x688","0");
            put("x689","0");
            put("x690","0");
            put("x691","0");
            put("x692","0");
            put("x693","0");
            put("x694","0");
            put("x695","0");
            put("x696","0");
            put("x697","0");
            put("x698","0");
            put("x699","0");
            put("x700","0");
            put("x701","0");
            put("x702","0");
            put("x703","0");
            put("x704","0");
            put("x705","0");
            put("x706","0");
            put("x707","0");
            put("x708","0");
            put("x709","0");
            put("x710","0");
            put("x711","0");
            put("x712","0");
            put("x713","0");
            put("x714","0");
            put("x715","0");
            put("x716","0");
            put("x717","0");
            put("x718","0");
            put("x719","0");
            put("x720","0");
            put("x721","0");
            put("x722","0");
            put("x723","0");
            put("x724","0");
            put("x725","0");
            put("x726","0");
            put("x727","0");
            put("x728","0");
            put("x729","0");
            put("x730","0");
            put("x731","0");
            put("x732","0");
            put("x733","0");
            put("x734","0");
            //计算出来的
            Calendar c=Calendar.getInstance();
            c.setTime(new Date());
            int i = c.get(Calendar.DAY_OF_WEEK);
            put("x735",i-1);
            put("x736",i-1);
            //不存在的
            put("x737","0");
            put("x738","0");
            put("x739","0");
            put("x740","0");
            put("x741","0");
            put("x742","0");
            put("x743","0");
            put("x744","0");
            put("x745","0");
        }
    };

    public static Map<String, Object> newFeatures(Map<String, Object> rawFeatures) {
        Map<String, Object> map = new HashMap<>();
        map.putAll(DEFAULTMAP);

        //先取commet 数据取出来
        Iterator<Map.Entry<String, Object>> it = rawFeatures.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Object> entry = it.next();
            if(null==TRANSITIONMAP.get(entry.getKey())){
                map.put(entry.getKey(),entry.getValue());
                continue;
            }
            map.put(TRANSITIONMAP.get(entry.getKey()),entry.getValue());
        }

        //添加默认值 前端传递就覆盖
        map.put("x731",Double.parseDouble(map.get(TRANSITIONMAP.get("cart_burger_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_rice_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_riceroll_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_twister_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_chickensnack_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_cob_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_wing_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_sidefrenchfries_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_sideothers_sold")).toString()));

        map.put("x725",Double.parseDouble(map.get(TRANSITIONMAP.get("cart_burger_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_rice_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_riceroll_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_twister_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_combo_burger_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_combo_rice_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_combo_twister_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_combo_riceroll_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_burger_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_rice_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_twister_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_riceroll_sold")).toString()));

        map.put("x727",Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_burger_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("burger_flag")).toString())*20
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_chickensnack_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("chickensnack_flag")).toString())*15
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_cob_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("cob_flag")).toString())*12.5
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_coffee_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("coffee_flag")).toString())*15
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_conge_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("conge_flag")).toString())*15
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_croissant_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("croissant_flag")).toString())*9
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_csd_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("csd_flag")).toString())*15
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_dabing_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("dabing_flag")).toString())*15
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_eggtart_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("eggtart_flag")).toString())*8.5
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_icecream_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("icecream_flag")).toString())*8
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_juice_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("juice_flag")).toString())*8
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_lto_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("lto_flag")).toString())*18
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_nonfood_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("nonfood_flag")).toString())*18
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_nutrition_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("nutrition_flag")).toString())*12
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_panini_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("panini_flag")).toString())*15
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_pie_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("pie_flag")).toString())*10
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_rice_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("rice_flag")).toString())*20
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_riceroll_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("riceroll_flag")).toString())*14
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_side_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("side_flag")).toString())*7
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_sidefrenchfries_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("sidefrenchfries_flag")).toString())*7
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_sideothers_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("sideothers_flag")).toString())*7
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_tea_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("tea_flag")).toString())*12
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_twister_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("twister_flag")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_waffle_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("waffle_flag")).toString())*9
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_wing_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("wing_flag")).toString())*9);

        map.put("x729",Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_burger_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("burger_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_chickensnack_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("chickensnack_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_cob_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("cob_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_coffee_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("coffee_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_conge_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("conge_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_croissant_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("croissant_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_csd_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("csd_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_dabing_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("dabing_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_eggtart_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("eggtart_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_icecream_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("icecream_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_juice_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("juice_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_lto_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("lto_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_nonfood_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("nonfood_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_nutrition_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("nutrition_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_panini_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("panini_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_pie_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("pie_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_rice_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("rice_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_riceroll_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("riceroll_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_side_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("side_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_sidefrenchfries_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("sidefrenchfries_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_sideothers_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("sideothers_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_tea_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("tea_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_twister_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("twister_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_waffle_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("waffle_flag")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_promo_wing_sold")).toString())
                *Double.parseDouble(map.get(TRANSITIONMAP.get("wing_flag")).toString()));

        map.put("x721",Double.parseDouble(map.get(TRANSITIONMAP.get("cart_burger_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_rice_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_riceroll_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_twister_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_coffee_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_tea_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_juice_sold")).toString()));

        map.put("x733",Double.parseDouble(map.get(TRANSITIONMAP.get("cart_coffee_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_tea_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_juice_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_burger_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_rice_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_riceroll_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_twister_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_eggtart_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_icecream_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_pie_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_waffle_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_eggtart_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_icecream_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_pie_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_waffle_sold")).toString()));

        map.put("x723",Double.parseDouble(map.get(TRANSITIONMAP.get("cart_chickensnack_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_cob_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_wing_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_sidefrenchfries_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_sideothers_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_coffee_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_tea_sold")).toString())
                +Double.parseDouble(map.get(TRANSITIONMAP.get("cart_juice_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_burger_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_rice_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_riceroll_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_twister_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_burger_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_rice_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_riceroll_sold")).toString())
                -Double.parseDouble(map.get(TRANSITIONMAP.get("cart_twister_sold")).toString()));

        return map;
    }

}
