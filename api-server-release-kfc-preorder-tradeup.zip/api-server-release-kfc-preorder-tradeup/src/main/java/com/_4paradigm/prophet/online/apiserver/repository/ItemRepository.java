package com._4paradigm.prophet.online.apiserver.repository;

import com._4paradigm.prophet.online.apiserver.model.context.Context;

import java.util.List;
import java.util.Map;

public interface ItemRepository {
    List<Map<String, Object>> getItems(Context context);
}
