package com._4paradigm.prophet.online.apiserver.repository.impl;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.policy.Policy;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

@Lazy
@Configuration("DefaultPrePredictPolicy")
public class DefaultPrePredictPolicy implements Policy {
    @Override
    public Context process(Context context) {
        return context;
    }
}
