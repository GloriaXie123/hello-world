package com._4paradigm.prophet.online.apiserver.yumc.tradeup.rerank;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.policy.Policy;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author akis on 2019-07-22
 */
@Lazy
@Component("tradeupRerankPolicy")
public class TradeupRerankPolicy implements Policy {

    @Value("${tradeup.rerank.expression:}")
    private String expression;

    @Value("${predictor.score_column_name:predictScore}")
    private String predictScore;

    @Value("${tradeup.item.price:price}")
    private String sellPrice;

    @Value("${tradeup.rerank.timePattern:HH:mm}")
    private String timePattern;

    @Value("${tradeup.timezone:+08:00}")
    private String timezone;

    @Setter
    private List<PeriodExp> periodExpList;

    private DateTimeFormatter TIME_FORMATTER;

    /**
     * expression: 11:30~13:30,1.3|default,1
     */
    @PostConstruct
    public void init() {

        TIME_FORMATTER = DateTimeFormatter.ofPattern(timePattern);

        if (StringUtils.isNotEmpty(expression)) {
            String[] slices = StringUtils.split(expression, "|");
            periodExpList = Arrays.stream(slices)
                    .map(PeriodExp::getInstance)
                    .collect(Collectors.toList());
        } else {
            periodExpList = new ArrayList<>(0);
        }
    }

    @Override
    public Context process(Context context) {
        String systemTime=(String)context.getReqParam().get("systemTime");
        Instant instant = Instant.ofEpochSecond(Integer.parseInt(systemTime));
        LocalDateTime localDateTime = instant.atZone(ZoneOffset.of(timezone)).toLocalDateTime();
        String time = TIME_FORMATTER.format(localDateTime);

        List<Map<String, Object>> tableWithScore = context.getItems();

        tableWithScore.sort((item1, item2) ->
                -Double.compare(calculate(item1, time), calculate(item2, time)));
        return context;
    }


    public double calculate(Map<String, Object> item, String time) {
        double score = (Double) item.get(predictScore);
        double price = 1;
        if (item.get(sellPrice) != null) {
            price = (Double) item.get(sellPrice);
        }

        double exp = 0;
        if (periodExpList != null && periodExpList.size() != 0) {
            for (PeriodExp periodExp : periodExpList) {
                if (!periodExp.isDefault && periodExp.inPeriod(time)) {
                    exp = periodExp.exp;
                    break;
                } else if (periodExp.isDefault) {
                    exp = periodExp.exp;
                }
            }
        }
        return Math.pow(price, exp) * score;
    }




    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class PeriodExp {
        public String start;
        public String end;
        public boolean isDefault;
        public double exp;

        /**
         * @param expression e.g. "11:30~13:30,1.3 or default,1"
         * @return
         */
        public static PeriodExp getInstance(String expression) {
            String[] splits = StringUtils.split(expression, ",");
            double exp = Double.parseDouble(splits[1]);
            PeriodExp instance;
            if ("default".equals(splits[0])) {
                instance = PeriodExp.builder()
                        .exp(exp)
                        .isDefault(true)
                        .build();
            } else {
                String[] times = StringUtils.split(splits[0], "~");
                instance = PeriodExp.builder()
                        .exp(exp)
                        .isDefault(false)
                        .start(times[0])
                        .end(times[1])
                        .build();
            }
            return instance;
        }

        public boolean inPeriod(String time) {
            if (!isDefault &&
                    time.compareTo(start) >= 0 && time.compareTo(end) < 0 ) {
                return true;
            } else {
                return false;
            }
        }
    }
}
