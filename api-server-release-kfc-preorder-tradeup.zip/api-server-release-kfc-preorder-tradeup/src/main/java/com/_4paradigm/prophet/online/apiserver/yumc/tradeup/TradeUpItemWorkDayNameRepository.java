package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import java.util.Map;

import static com._4paradigm.prophet.online.apiserver.yumc.tradeup.Constants.CHANNEL;
import static com._4paradigm.prophet.online.apiserver.yumc.tradeup.Constants.STORE_CODE;

/**
 * @author akis on 2019-06-28
 */
@Lazy
@Repository("tradeUpItemNationalDay")
@Slf4j
public class TradeUpItemWorkDayNameRepository extends TradeUpItemRepository {

    @Override
    public Map<String, Object> getCityRecall(Context context){
        String storeCode = (String) context.getReqParam().get(STORE_CODE);
        String workDayName = "工作日";
        String daypartName = (String) context.getReqParam().get("city_recall_daypart_name");
        String channel = (String) context.getReqParam().get(CHANNEL);
        Map<String, Object> cityRecallMap = queryCityRecall(storeCode, workDayName, daypartName, channel);

        String weekName = "周末";
        Map<String, Object> weekCityRecallMap = queryCityRecall(storeCode, weekName, daypartName, channel);
        cityRecallMap.putAll(weekCityRecallMap);

        return cityRecallMap;

    }

}
