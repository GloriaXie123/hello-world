package com._4paradigm.prophet.online.apiserver.policy.impl;


import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.policy.Policy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

@Lazy
@Component("DefaultReRankingPolicy")
public class DefaultReRankingPolicy implements Policy {

    @Value("${itemData.primaryKey:itemId}")
    private String PRED_ID;
    @Value("${predictor.score_column_name:predictScore}")
    private String PRED_SCORE;

    @Override
    public Context process(Context context)  {
        List<Map<String, Object>> tableWithScore = context.getItems();
        Collections.sort(tableWithScore, new Comparator<Map<String, Object>>() {
            @Override
            public int compare(Map<String, Object> stringObjectMap, Map<String, Object> t1) {
                return -Double.compare((Double) stringObjectMap.get(PRED_SCORE), (Double) t1.get(PRED_SCORE));
            }
        });
        context.setItems(tableWithScore);
        return context;
    }
}
