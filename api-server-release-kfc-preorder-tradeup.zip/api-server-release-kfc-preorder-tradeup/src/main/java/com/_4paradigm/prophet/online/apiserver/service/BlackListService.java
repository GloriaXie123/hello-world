package com._4paradigm.prophet.online.apiserver.service;


import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespContext;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespDTO;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespData;
import com._4paradigm.prophet.online.apiserver.repository.rtidb.RtiDBTable;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class BlackListService {

    @Autowired
    private RtiDBTable rtiDBTable;

    @Value("${tradeup.returnItems.limit:4}")
    private Integer itemLimit;

    @Value("${pt.userBlack.tableName}")
    private String blacklistTableName;
    private RtiDBTable blackListTable;

    @Value("${pt.userBlack.blacklist.key}")
    private String blacklistTablePK;

    @Value("${pt.userBlack.forcePush}")
    private String blacklistForcePush;


    @PostConstruct
    private void postConstruct() {
        blackListTable = rtiDBTable.getTable(blacklistTableName);

    }


    /****
     * 查询 usercode 是否在 blacklist 中，若在则返回黑名单用户的强推物料
     */
    public PredictRespDTO queryBlackList(String userCode, String experimentId) {

        Map<String, Object> hit = blackListTable.getRow(blacklistTablePK, userCode);
        if (hit != null && !hit.isEmpty()) {
            PredictRespContext respCtx = new PredictRespContext();
            String timestamp = String.valueOf(System.currentTimeMillis());
            String address = System.getenv("MY_POD_IP");
            String thread = String.valueOf(Thread.currentThread().getId());
            String uniqid = Base64
                    .encodeBase64String(String.join(",", timestamp, address, thread).getBytes());

            respCtx.setExperimentId(experimentId);
            respCtx.setRecallConfigVersion("Unknown");
            respCtx.setUniqueId(uniqid);

            PredictRespData respData = new PredictRespData();
            respData.setContext(respCtx);

            List<Map<String, Object>> data = new ArrayList<Map<String, Object>>();

            String[] blfs = blacklistForcePush.split(",");

            int limit = Math.min(blfs.length, itemLimit);
            int rank = 1;

            for (String promotionCode : blfs) {
                Map<String, Object> transItem = new HashMap<>(2);

                transItem.put("promotionCode", promotionCode);
                transItem.put("rank", String.valueOf(rank));
                data.add(transItem);

                if (rank >= limit) {
                    break;
                } else {
                    rank++;
                }
            }

            respData.setList(data);

            PredictRespDTO respDTO = new PredictRespDTO();
            respDTO.setRetCode(200);
            respDTO.setMessage("success");
            respDTO.setData(respData);
            return respDTO;

        } else {
            return null;
        }
    }
}
