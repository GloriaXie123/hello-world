package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;

/**
 * @author akis on 2019-06-28
 */
@Lazy
@Repository("TradeUpCartMapperOriginal")
@Slf4j
class TradeUpCartMapperOriginal extends AbstractTradeUpCartMapper  {

    @Override
    public String getCityRecallDaypart(LocalDateTime localDateTime){

        return getDaypart(localDateTime);

    }




}
