package com._4paradigm.prophet.online.apiserver.yumc.tradeup.random;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.yumc.tradeup.TradeUpRespMapper;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * @author akis on 2019-07-24
 */
@Lazy
@Component("TradeupRandomRespMapper")
public class TradeupRandomRespMapper extends TradeUpRespMapper {

    @Override
    public List<Map<String, Object>> getItems(Context context) {
        List<Map<String, Object>> items = (List<Map<String, Object>>) context.getExtraData().get("recallItems");
        Collections.shuffle(items);
        return items;
    }
}
