package com._4paradigm.prophet.online.apiserver.repository.rtidb;

import com._4paradigm.prophet.online.apiserver.exception.ApiServerException;
import com._4paradigm.prophet.online.apiserver.exception.RetCode;
import com._4paradigm.rtidb.client.KvIterator;
import com._4paradigm.rtidb.client.TabletException;
import com._4paradigm.rtidb.client.schema.ColumnDesc;
import com.google.common.collect.Maps;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeoutException;

@Slf4j
@Getter
@Setter
@Configuration
public class RtiDBTable {

    @Autowired
    private TableClient tableClient;

    private String tableName;
    private List<ColumnDesc> tableSchema;

    private static ExecutorService es;

    @Value("${RtiDB.threadPoolSize:50}")
    public void setEs(int size) {
        es = Executors.newFixedThreadPool(size);
    }

    // For get RtiDBTable instance
    public RtiDBTable getTable(String name) {
        RtiDBTable rtiDBTable = new RtiDBTable();
        rtiDBTable.setTableName(name);
        rtiDBTable.setTableClient(this.tableClient);
        rtiDBTable.initTableSchema();
        return rtiDBTable;
    }

    public void initTableSchema() {
        this.tableSchema = this.tableClient.getTableSchema(this.tableName);
    }

    public List<ColumnDesc> getTableSchema() {
        return this.tableSchema;
    }

    private Map<String, Object> mapSchema(Object[] result) {
        if (result == null) {
            return null;
        }
        Map<String, Object> row = Maps.newHashMapWithExpectedSize(this.tableSchema.size());
        int len = this.tableSchema.size();
        for (int idx = 0; idx < len; idx++) {
            String col = this.tableSchema.get(idx).getName();
            Object val = result[idx];
            row.put(col, val);
        }
        return row;
    }

    public Future<List<Map<String, Object>>> asyncScan(String pk, String value, long startTime, long endTime, Integer limit) {
        return es.submit(() -> this.scan(pk, value, startTime, endTime, limit));
    }

    public List<Map<String, Object>> scan(String pk, String value, long startTime, long endTime, Integer limit) throws ApiServerException {
        List<Map<String, Object>> resultList = new ArrayList<>();
        try {
            KvIterator it = this.tableClient.getTableSyncClient().scan(this.tableName, value, pk, startTime, endTime, limit);
            while(it.valid()) {
                Object[] result = it.getDecodedValue();
                resultList.add(this.mapSchema(result));
                it.next();
            }
        } catch (TimeoutException e) {
            throw new ApiServerException(RetCode.rtidb_timeout, "rtidb timeout", e);
        } catch (TabletException e) {
            throw new ApiServerException(RetCode.rtidb_failed, "rtidb tablet exception", e);
        } catch (Exception e) {
            log.debug("rtidb scan failed, pk={}, value={}, startTime={}, endTime={}, limit={}", pk, value, startTime, endTime, limit, e);
        }
        return resultList;
    }

    /**
     * 组合 key 查询
     */
    public List<Map<String, Object>> scan(String pk, Map<String, Object> value, long startTime, long endTime, Integer limit) throws ApiServerException {
        List<Map<String, Object>> resultList = new ArrayList<>();
        try {
            KvIterator it = this.tableClient.getTableSyncClient().scan(this.tableName, value, pk, startTime, endTime, null,limit);
            while(it.valid()) {
                Object[] result = it.getDecodedValue();
                resultList.add(this.mapSchema(result));
                it.next();
            }
        } catch (TimeoutException e) {
            throw new ApiServerException(RetCode.rtidb_timeout, "rtidb timeout", e);
        } catch (TabletException e) {
            throw new ApiServerException(RetCode.rtidb_failed, "rtidb tablet exception", e);
        } catch (Exception e) {
            log.debug("rtidb scan failed, pk={}, value={}, startTime={}, endTime={}, limit={}", pk, value, startTime, endTime, limit, e);
        }
        return resultList;
    }

    public Future<List<Map<String, Object>>>  asyncScan (String pk, String value, long startTime, long endTime) {
        return es.submit(() -> this.scan(pk, value, startTime, endTime, 0));
    }

    public List<Map<String, Object>> scan(String pk, String value, long startTime, long endTime) throws ApiServerException {
        return this.scan(pk, value, startTime, endTime, 0);
    }

    public Future<List<Map<String, Object>>>  asyncScan (String pk, String value, long startTime) {
        return es.submit(() -> this.scan(pk, value, startTime, 0, 0));
    }

    public List<Map<String, Object>> scan(String pk, String value, long startTime) throws ApiServerException {
        return this.scan(pk, value, startTime, 0, 0);
    }

    public List<Map<String, Object>> scan(String pk, Map<String, Object> keyMap) throws ApiServerException {
        return this.scan(pk, keyMap, 0,0,0);
    }

    public Future<Map<String, Object>> asyncGetRow(String pk, String value, long ts) {
        return es.submit(() -> this.getRow(pk, value, ts));
    }

    public Map<String, Object> getRow(String pk, String value, long ts) throws ApiServerException {
        Map<String, Object> result = null;
        try {
            Object[] ret = this.tableClient.getTableSyncClient().getRow(this.tableName, value, pk, ts);
            result = this.mapSchema(ret);
        } catch (TimeoutException e) {
            throw new ApiServerException(RetCode.rtidb_timeout, "rtidb timeout", e);
        } catch (TabletException e) {
            throw new ApiServerException(RetCode.rtidb_failed, "rtidb tablet exception", e);
        } catch (Exception e) {
            log.debug("rtidb get row failed, pk={}, value={}, ts={}", pk, value, ts, e);
        }
        if (result == null) {
            result = new HashMap<>();
        }
        return result;
    }

    public Future<Map<String, Object>> asyncGetRow(String pk, String value) {
        return es.submit(() -> this.getRow(pk, value, 0));
    }

    public Map<String, Object> getRow(String pk, String value) throws ApiServerException {
        return this.getRow(pk, value, 0);
    }

    /**
     * 组合 key 查询
     * @param idxName
     * @param keyMap
     * @param ts
     * @param tsName
     * @return
     */
    public Future<Map<String, Object>> asyncGetRow(String idxName, Map<String, Object> keyMap, long ts, String tsName) {
        return es.submit(() -> this.getRow(idxName, keyMap, ts, tsName));
    }

    public Map<String, Object> getRow(String idxName, Map<String, Object> keyMap, long ts, String tsName) throws ApiServerException {
        Map<String, Object> result = null;
        try {
            Object[] ret = this.tableClient.getTableSyncClient().getRow(this.tableName, keyMap, idxName, ts, tsName, null);
            result = this.mapSchema(ret);
        } catch (TimeoutException e) {
            throw new ApiServerException(RetCode.rtidb_timeout, "rtidb timeout", e);
        } catch (TabletException e) {
            throw new ApiServerException(RetCode.rtidb_failed, "rtidb tablet exception", e);
        } catch (Exception e) {
            log.debug("rtidb get row failed, idxName={}, keyMap={}, ts={}, tsName={}", idxName, keyMap, ts, tsName, e);
        }
        if (result == null) {
            result = new HashMap<>();
        }
        return result;
    }

    public Future<Map<String, Object>> asyncGetRow(String idxName, Map<String, Object> keyMap, long ts) {
        return es.submit(() -> this.getRow(idxName, keyMap, ts));
    }

    public Map<String, Object> getRow(String idxName, Map<String, Object> keyMap, long ts) throws ApiServerException {
        return this.getRow(idxName, keyMap, ts, null);
    }

    public Future<Map<String, Object>> asyncGetRow(String idxName, Map<String, Object> keyMap) {
        return es.submit(() -> this.getRow(idxName, keyMap));
    }

    public Map<String, Object> getRow(String idxName, Map<String, Object> keyMap) throws ApiServerException {
        return this.getRow(idxName, keyMap, 0, null);
    }

    public Future<List<Map<String, Object>>> asyncPreview(String pk, Integer limit) {
        return es.submit(() -> this.preview(pk, limit));
    }

    public List<Map<String, Object>> preview(String pk, Integer limit) throws ApiServerException {
        List<Map<String, Object>> resultList = new ArrayList<>();
        KvIterator it = null;
        try {
            if (pk.isEmpty()) {
                it = this.tableClient.getTableSyncClient().traverse(this.tableName);
            } else it = this.tableClient.getTableSyncClient().traverse(this.tableName, pk);
            while(it.valid()) {
                Object[] result = it.getDecodedValue();
                resultList.add(this.mapSchema(result));
                if (limit > 0 && resultList.size() >= limit) {
                    break;
                }
                it.next();
            }
        } catch (TimeoutException e) {
            throw new ApiServerException(RetCode.rtidb_timeout, "rtidb timeout", e);
        } catch (TabletException e) {
            throw new ApiServerException(RetCode.rtidb_failed, "rtidb tablet exception", e);
        } catch (Exception e) {
            log.debug("rtidb traverse failed, pk={}, limit={}", pk, limit, e);
        }
        return resultList;
    }
}
