package com._4paradigm.prophet.online.apiserver.util;

import com.alibaba.fastjson.JSON;

import java.util.List;
import java.util.Map;

public class JsonUtils {
    public static Map<String, Object> toMap(String json) {
        return JSON.parseObject(json);
    }

    public static List<Map> toList(String json) {
        return JSON.parseArray(json, Map.class);
    }

}
