package com._4paradigm.prophet.online.apiserver.yumc.tradeup.random;

import static com._4paradigm.prophet.online.apiserver.yumc.tradeup.Constants.CHANNEL;
import static com._4paradigm.prophet.online.apiserver.yumc.tradeup.Constants.CITY_NAME;
import static com._4paradigm.prophet.online.apiserver.yumc.tradeup.Constants.SHOPPING_CART_SUBCLASSES;
import static com._4paradigm.prophet.online.apiserver.yumc.tradeup.Constants.STORE_CODE;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.model.context.ReqParamMapper;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.req.predictReqDTO;
import com._4paradigm.prophet.online.apiserver.yumc.tradeup.Request;
import com.alibaba.fastjson.JSON;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import javax.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * @author akis on 2019-07-24
 */
@Slf4j
@Lazy
@Component("TradeupRandomCartMapper")
public class TradeupRandomCartMapper implements ReqParamMapper {

    @Value("${tradeup.timezone:+08:00}")
    private String timezone;

    @Value("${tradeup.rerank.timePattern:HH:mm}")
    private String timePattern;

    private DateTimeFormatter TIME_FORMATTER;


    @PostConstruct
    private void init() {
        TIME_FORMATTER = DateTimeFormatter.ofPattern(timePattern);
    }

    @Override
    public Map<String, Object> process(predictReqDTO req, Context context) {
        Map<String, Object> rawFeatures = req.getRawFeatures();
        Request request = JSON.parseObject(JSON.toJSONString(rawFeatures), Request.class);
        context.getExtraData().put(SHOPPING_CART_SUBCLASSES, new HashSet<String>(0));
        return new HashMap<>(getExtraParams(request));
    }


    private Map<String, String> getExtraParams(Request request) {
        Map<String, String> extraParams = new HashMap<>();
        extraParams.put("userCode", StringUtils.lowerCase(request.getUserCode()));
        extraParams.put("systemTime", request.getSystemTime());
        extraParams.put("promiseTime", request.getPromiseTime());
        extraParams.put(CITY_NAME, request.getCityName());
        extraParams.put("cityCode", request.getCityCode());
        extraParams.put(STORE_CODE, request.getStoreCode());
        extraParams.put("brand", request.getBrand());
        extraParams.put("transactionId", request.getTransactionId());
        extraParams.put("marketCode", request.getMarketCode());
        extraParams.put(CHANNEL, mapChannel(request.getChannel()));
        extraParams.putAll(extractTime(Integer.parseInt(request.getSystemTime())));
        return extraParams;
    }


    private String mapChannel(String ori) {
        String channel;
        if (ori == null) {
            channel = "Unknown";
        } else if ("ALIPAY_MINIAPP".equals(ori)) {
            channel = "ALIMINI";
        } else {
            channel = StringUtils.upperCase(ori);
        }
        return channel;
    }

    private Map<String, String> extractTime(Integer ts) {
        Map<String, String> res = new HashMap<>(2);
        Instant instant = Instant.ofEpochSecond(ts);
        LocalDateTime localDateTime = instant.atZone(ZoneOffset.of(timezone)).toLocalDateTime();

        int day = localDateTime.getDayOfWeek().getValue();
        if (day >= 1 && day <= 5) {
            res.put("work_day_name", "工作日");
        } else {
            res.put("work_day_name", "周末");
        }

        String timeNow = TIME_FORMATTER.format(localDateTime);
        String daypart = "";
        if (between(timeNow, "06:00", "09:30")) {
            daypart = "Breakfast";
        } else if (between(timeNow, "09:30", "11:00")) {
            daypart = "Morning";
        } else if (between(timeNow, "11:00", "14:00")) {
            daypart = "Lunch";
        } else if (between(timeNow, "14:00", "17:00")) {
            daypart = "Afternoon";
        } else if (between(timeNow, "17:00", "20:00")) {
            daypart = "Dinner";
        } else if (between(timeNow, "20:00", "24:00")) {
            daypart = "Late night";
        }
        res.put("daypart_name", daypart);

        return res;
    }

    private boolean between(String time, String start, String end) {
        if (time.compareTo(start) >= 0 && time.compareTo(end) < 0) {
            return true;
        } else {
            return false;
        }
    }
}
