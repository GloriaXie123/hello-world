package com._4paradigm.prophet.online.apiserver.exception;

public enum RetCode {
    unknown(10000),
    rtidb_table_not_found(20001),
    rtidb_failed(20002),
    rtidb_timeout(20003),

    prediction_failed(30001),

    reranking_failed(40001);

    private int retCode;

    RetCode(int retCode) {
        this.retCode = retCode;
    }

    public int code() {
        return this.retCode;
    }
}
