package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.model.context.RecallConfig;
import com._4paradigm.prophet.online.apiserver.policy.Policy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * @author akis on 2019-06-28
 */
@Lazy
@Component("tradeUpRecallPolicy")
public class TradeUpRecallPolicy implements Policy {

    @Value("userRecallTableName")
    private String userRecallTableName;

    @Value("userRecallKey")
    private String userRecallKey;

    @Value("cityRecallTableName")
    private String cityRecallTableName;

    @Value("cityRecallKey")
    private String cityRecallKey;

    @Override
    public Context process(Context context) {
        RecallConfig conf = new RecallConfig();
        if (context.getRecallConfig() == null) {
            context.setRecallConfig(conf);
        }
        String expression = String.format(
                "Union(Table('%s', '%s'), Table('%s', '%s'))",userRecallTableName, userRecallKey,
                cityRecallTableName, cityRecallKey);
        context.getRecallConfig().setExpression(expression);
        return context;
    }
}
