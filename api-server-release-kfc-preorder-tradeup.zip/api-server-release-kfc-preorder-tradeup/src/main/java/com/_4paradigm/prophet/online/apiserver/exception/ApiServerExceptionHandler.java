package com._4paradigm.prophet.online.apiserver.exception;

import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.http.HttpServletRequest;

@Slf4j
@RestControllerAdvice
public class ApiServerExceptionHandler {

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity handleException(HttpServletRequest request, Exception ex) {
        RetCode retCode = RetCode.unknown;
        log.error("api server exception, retCode={}, message={}", retCode.code(), ex.getMessage(), ex);
        PredictRespDTO resp = new PredictRespDTO();
        resp.setRetCode(retCode.code());
        resp.setMessage(ex.getMessage());
        return ResponseEntity.status(500).body(resp);
    }

}
