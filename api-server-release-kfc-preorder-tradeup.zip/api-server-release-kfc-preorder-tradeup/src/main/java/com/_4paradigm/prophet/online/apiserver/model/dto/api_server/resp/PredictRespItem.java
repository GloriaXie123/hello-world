package com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp;

import lombok.Data;

@Data
public class PredictRespItem {
    private String itemId;
    private String rank;
}
