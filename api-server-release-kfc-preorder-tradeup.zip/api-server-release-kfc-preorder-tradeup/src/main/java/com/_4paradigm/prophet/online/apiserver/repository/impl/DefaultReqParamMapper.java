package com._4paradigm.prophet.online.apiserver.repository.impl;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.req.predictReqDTO;
import com._4paradigm.prophet.online.apiserver.model.context.ReqParamMapper;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import java.util.Map;

@Lazy
@Repository("DefaultReqParamMapper")
public class DefaultReqParamMapper implements ReqParamMapper {

    @Override
    public Map<String, Object> process(predictReqDTO req, Context context) {
        return req.getRawFeatures();
    }
}
