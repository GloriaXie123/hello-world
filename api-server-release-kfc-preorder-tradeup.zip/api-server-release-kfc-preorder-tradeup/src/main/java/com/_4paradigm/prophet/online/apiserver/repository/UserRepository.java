package com._4paradigm.prophet.online.apiserver.repository;

import com._4paradigm.prophet.online.apiserver.model.context.Context;

import java.util.Map;

public interface UserRepository {
    Map<String, Object> getUser(Context context);
}
