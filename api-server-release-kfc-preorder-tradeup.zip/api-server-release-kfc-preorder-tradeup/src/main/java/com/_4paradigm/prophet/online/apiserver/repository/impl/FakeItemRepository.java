package com._4paradigm.prophet.online.apiserver.repository.impl;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.repository.ItemRepository;
import com._4paradigm.prophet.online.apiserver.util.FileUtils;
import com._4paradigm.prophet.online.apiserver.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Lazy
@Repository("FakeItems")
public class FakeItemRepository implements ItemRepository {

    List<Map<String, Object>> items = null;

    @PostConstruct
    private void postConstruct() {
        try {
            items = new ArrayList<>();
            String json = FileUtils.readFileFromResource("items.json");
            List<Map> data = JsonUtils.toList(json);
            for(Map entity : data) {
                HashMap<String, Object> item = new HashMap<>();
                item.putAll(entity);
                items.add(item);
            }
        } catch (IOException e) {
            if (log.isDebugEnabled()) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public List<Map<String, Object>> getItems(Context context) {
        return items;
    }
}
