package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.model.context.ContextLogger;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

@Slf4j
@Lazy
@Repository("TradeUpLogger")
public class TradeUpContextLogger implements ContextLogger {

    private static final org.slf4j.Logger recordLogger = org.slf4j.LoggerFactory
            .getLogger("record-log");
    private static final org.slf4j.Logger sampleLogger = org.slf4j.LoggerFactory
            .getLogger("sample-log");
    private ExecutorService es = Executors.newFixedThreadPool(2);

    private void asyncWrite(Context context) {
        Long start = System.currentTimeMillis();
        if (sampleLogger.isInfoEnabled()) {
            int i = 0;
            for (Map<String, Object> item : context.getItems()) {
                i += 1;
                Map<String, Object> sample = Maps
                        .newHashMapWithExpectedSize(context.getCommon().size() + 4 + item.size());
                sample.putAll(context.getCommon());
                sample.put("itemRank", i);
                sample.put("uniqueId", context.getUniqueId());
                sample.put("experimentId", context.getExperimentId());
                sample.putAll(item);
                // Debug
                if (context.getIsDebug()) {
                    sample.put("_apiServer_debug_sample_", true);
                }
                sampleLogger.info(JSON.toJSONString(sample, SerializerFeature.DisableCircularReferenceDetect));
            }
        }
        Long end = System.currentTimeMillis();
        if (recordLogger.isInfoEnabled()) {
            Object latencyObj = context.getExtraData().get("Latency");
            if (latencyObj != null) {
                Map<String, Long> latencyMap = (Map<String, Long>) latencyObj;
                Long latency = end - start;
                latencyMap.put("log", latency);
            }
            recordLogger.info("{}", JSON.toJSONString(simplify(context), SerializerFeature.DisableCircularReferenceDetect));
        }
    }

    @Override
    public void write(Context context) {
        this.es.submit(() -> {
            this.asyncWrite(context);
        });
    }

    private SimplifiedContext simplify(Context context) {
        return SimplifiedContext.builder()
                .common(context.getCommon())
                .extraData(context.getExtraData())
                .items(context.getItems())
                .response(context.getResponse())
                .build();
    }
}
