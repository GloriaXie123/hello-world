package com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp;

import lombok.Data;

@Data
public class PredictRespDTO {
    private Integer retCode;
    private String message;
    private PredictRespData data;
}
