package com._4paradigm.prophet.online.apiserver.model.context;

public interface ContextLogger {
    void write(Context context);
}