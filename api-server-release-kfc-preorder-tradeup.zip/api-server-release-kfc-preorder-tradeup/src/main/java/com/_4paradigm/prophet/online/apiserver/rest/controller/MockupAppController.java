package com._4paradigm.prophet.online.apiserver.rest.controller;

import com._4paradigm.prophet.online.apiserver.model.dto.api_server.req.predictReqDTO;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespContext;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespDTO;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespData;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/mockup/api/v1")
@Slf4j
public class MockupAppController {

    //Apollo动态物料配置
    @Value("${mockup.service}")
    private String mockupService;

    //是否随机
    @Value("${mockup.service.random}")
    private String mockupServiceRandom;

    @PostMapping("/prediction")
    public ResponseEntity<PredictRespDTO> createPrediction(@RequestBody predictReqDTO predictReqDTO,@RequestParam(name = "scene") String scene) {
        long start = System.currentTimeMillis();

        PredictRespDTO predictRespDTO = new PredictRespDTO();
        PredictRespData predictRespData = new PredictRespData();

        PredictRespContext predictRespContext = new PredictRespContext();
        predictRespContext.setExperimentId(predictReqDTO.getContext().getExperimentId());
        predictRespContext.setRecallConfigVersion("mockup");
        String timestamp = String.valueOf(System.currentTimeMillis());
        String address = System.getenv("MY_POD_IP");
        String thread = String.valueOf(Thread.currentThread().getId());
        String uniqid = Base64.encodeBase64String(String.join(",", timestamp, address, thread).getBytes());
        predictRespContext.setUniqueId(uniqid);
        predictRespData.setContext(predictRespContext);

        Map<String, Object> items = (Map<String, Object>) JSON.parse(mockupService);
        Map<String, Object> itemsDetail = (Map<String, Object>) JSON.parse(String.valueOf(items.get(scene)));
        if (null==itemsDetail){
            predictRespDTO.setRetCode(204);
            predictRespDTO.setMessage("No Content");
            predictRespDTO.setData(null);
            return new ResponseEntity<>(predictRespDTO, HttpStatus.OK);
        }

        List<Map<String, Object>> promotionCodesList = (List<Map<String, Object>>)(itemsDetail.get("material"));

        if("off".equals(mockupServiceRandom)){
            //sort排序
            Collections.sort(promotionCodesList, new Comparator<Map<String, Object>>() {
                @Override
                public int compare(Map<String, Object> o1, Map<String, Object> o2) {
                    int i = Integer.parseInt(o1.get("rank").toString());
                    int j = Integer.parseInt(o2.get("rank").toString());
                    return i==j ? 0 :(i<j ? -1 :1);
                }
            });
        }else if ("on".equals(mockupServiceRandom)){
            //打乱顺序
            Collections.shuffle(promotionCodesList);
        }else{
            predictRespDTO.setRetCode(204);
            predictRespDTO.setMessage("No Content");
            predictRespDTO.setData(null);
            return new ResponseEntity<>(predictRespDTO, HttpStatus.OK);
        }

        int count= Integer.parseInt(itemsDetail.get("count").toString());

        List<Map<String, Object>> data = new ArrayList<Map<String, Object>>();
        for (int i = 0; i < (promotionCodesList.size()) && i <count; i++) {
            Map<String, Object> transItem = new HashMap<>();
            transItem = promotionCodesList.get(i);
            transItem.put("rank", i+1);
            data.add(transItem);
        }

        predictRespData.setList(data);
        predictRespDTO.setRetCode(200);
        predictRespDTO.setMessage("success");
        predictRespDTO.setData(predictRespData);

        long end = System.currentTimeMillis();
        log.info("data[{}],count[{}],request time is  [{}]",data.toString(),data.size(),end - start);

        return new ResponseEntity<>(predictRespDTO, HttpStatus.OK);
    }

}
