package com._4paradigm.prophet.online.apiserver.repository.impl;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.repository.ItemRepository;
import com._4paradigm.prophet.online.apiserver.repository.rtidb.RtiDBTable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Map;

@Slf4j
@Lazy
@Repository("RtiDBItems")
public class RtiDBItemRepository implements ItemRepository {

    @Value("${itemData.RtiDBItems.tableName:itemTable}")
    private String itemTableName;

    @Value("${itemData.RtiDBItems.tablePrimaryKey:itemId}")
    private String itemTablePK;

    @Autowired
    private RtiDBTable rtiDBTable;

    RtiDBTable table;

    @PostConstruct
    private void postConstruct() {
        System.out.println("====== Construction for RtiDBItems ======");
        try {
            table = rtiDBTable.getTable(itemTableName);
        } catch (Exception e) {
            if (log.isDebugEnabled()) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public List<Map<String, Object>> getItems(Context context) {
        return table.preview(itemTablePK, 10);
    }
}
