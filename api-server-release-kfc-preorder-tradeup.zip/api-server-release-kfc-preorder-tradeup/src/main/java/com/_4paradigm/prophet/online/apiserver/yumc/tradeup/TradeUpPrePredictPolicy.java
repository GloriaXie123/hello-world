package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.policy.Policy;
import com._4paradigm.prophet.online.apiserver.repository.rtidb.RtiDBTable;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Map;

import static com._4paradigm.prophet.online.apiserver.yumc.tradeup.Constants.*;

/**
 * @author akis on 2019-06-30
 */
@Lazy
@Component("TradeUpPrePredict")
@Slf4j
public class TradeUpPrePredictPolicy implements Policy {

    @Autowired
    private RtiDBTable rtiDBTable;

    @Value("${rtidb.combinedKey}")
    private String combinedKey;


    @Value("${pt.storeRecall.tableName}")
    private String storeTableName;
    private RtiDBTable storeTable;
    @Value("${pt.tradeUpItem.tableName}")
    private String tradeUpStatsTableName;
    private RtiDBTable tradeUpStatsTable;


    private ThreadLocal<String> transactionIdTreadLocal = ThreadLocal.withInitial(() -> "empty");

    @PostConstruct
    private void postConstruct() {
        storeTable = rtiDBTable.getTable(storeTableName);
        tradeUpStatsTable = rtiDBTable.getTable(tradeUpStatsTableName);
    }

    @Override
    public Context process(Context context) {
        String transactionId = (String) context.getReqParam().get("transactionId");
        transactionIdTreadLocal.set(transactionId);
        joinStoreProfile(context);
        joinItemProfile(context);
        // set biz_date to today
        context.getCommon().put("biz_date", context.getReqParam().get(DATE_TODAY));
        context.getCommon().put("transaction_start_time", System.currentTimeMillis());
        return context;
    }

    private void joinStoreProfile(Context context) {
        Object storedCode = context.getReqParam().get(STORE_CODE);
        Object workDayName = context.getReqParam().get("work_day_name");

        Map<String, Object> storeProfile = queryStoreProfile(storedCode, workDayName);
        context.getCommon().putAll(storeProfile);
    }


    @Cacheable(cacheNames = "storeProfiles")
    public Map<String, Object> queryStoreProfile(Object storedCode, Object workDayName) {
        Map<String, Object> keyMap = Maps.newHashMapWithExpectedSize(2);
        keyMap.put("s_store_code", storedCode);
        keyMap.put("lastday_work_day_name", workDayName);

        Map<String, Object> row = storeTable.getRow(combinedKey, keyMap);
        if (row.isEmpty()) {
            keyMap.put("s_store_code", "0");
            keyMap.put("lastday_work_day_name", "0");
            row = storeTable.getRow(combinedKey, keyMap);
        }

        return row;
    }

    private void joinItemProfile(Context context) {
        String workDayName = (String) context.getReqParam().get("work_day_name");
        String daypartName = (String) context.getReqParam().get("daypart_name");

        String cityName = (String) context.getCommon().get("s_city_name");
        if (StringUtils.isEmpty(cityName)) {
            log.warn("transactionId[{}], cannot get city name from store profile, "
                    + "attempt to use request city name", transactionIdTreadLocal.get());
            cityName = (String) context.getReqParam().get("cityName");
        } else {
            context.getCommon().put(CITY_NAME, cityName);
        }

        for (Map<String, Object> item : context.getItems()) {
            String sellCode = (String) item.get("sell_code");
            Map<String, Object> tradeUpItemReturns = queryItemProfile(sellCode, workDayName, daypartName, cityName);
            item.putAll(tradeUpItemReturns);
            item.put("biz_date", context.getReqParam().get(DATE_TODAY));
        }
    }

    @Cacheable(cacheNames = "itemProfiles")
    public Map<String, Object> queryItemProfile(Object sellCode, Object workDayName,
                                                Object daypartName, Object cityName) {
        Map<String, Object> tradeUpStatsKeyMap = Maps.newHashMapWithExpectedSize(4);
        tradeUpStatsKeyMap.put("sell_code", sellCode);
        tradeUpStatsKeyMap.put("lastday_work_day_name", workDayName);
        tradeUpStatsKeyMap.put("daypart_name", daypartName);
        tradeUpStatsKeyMap.put("city_name", cityName);
        /*log.debug("transactionId[{}], join item profile with combined key map[{}]",
                transactionIdTreadLocal.get(), tradeUpStatsKeyMap);*/
        Map<String, Object> row = tradeUpStatsTable.getRow(combinedKey, tradeUpStatsKeyMap);
        if (row.isEmpty()) {
            tradeUpStatsKeyMap.put("sell_code", "0");
            tradeUpStatsKeyMap.put("lastday_work_day_name", "0");
            tradeUpStatsKeyMap.put("daypart_name", "0");
            tradeUpStatsKeyMap.put("city_name", "0");
            row = tradeUpStatsTable.getRow(combinedKey, tradeUpStatsKeyMap);
            //解决sellCode被赋值为0 的问题
            row.put("sell_code",sellCode);
        }

        return row;
    }
}
