package com._4paradigm.prophet.online.apiserver.repository.impl;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.repository.UserRepository;
import com._4paradigm.prophet.online.apiserver.repository.rtidb.RtiDBTable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.Map;

@Slf4j
@Lazy
@Repository("RtiDBUser")
public class RtiDBUserRepository implements UserRepository {
    @Value("${userData.RtiDBUser.tableName:userTable}")
    private String userTableName;

    @Value("${userData.RtiDBUser.tablePrimaryKey:userId}")
    private String userTablePK;

    @Autowired
    private RtiDBTable rtiDBTable;

    RtiDBTable table;

    @PostConstruct
    private void postConstruct() {
        System.out.println(userTableName);
        try {
            table = rtiDBTable.getTable(userTableName);
        } catch (Exception e) {
            if (log.isDebugEnabled()) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public Map<String, Object> getUser(Context context) {
        String userId = context.getReqParam().get(userTablePK).toString();
        return table.getRow(userTablePK, userId);
    }
}
