package com._4paradigm.prophet.online.apiserver.repository.impl;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.repository.UserRepository;
import com._4paradigm.prophet.online.apiserver.util.FileUtils;
import com._4paradigm.prophet.online.apiserver.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.Map;

@Slf4j
@Lazy
@Repository("FakeUser")
public class FakeUserRepository implements UserRepository {

    Map <String, Object> user = null;

    @PostConstruct
    private void postConstruct() {
        try {
            String json = FileUtils.readFileFromResource("user.json");
            user = JsonUtils.toMap(json);
        } catch (IOException e) {
            if (log.isDebugEnabled()) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public Map<String, Object> getUser(Context context) {
        return user;
    }
}
