package com._4paradigm.prophet.online.apiserver.yumc.tradeup.random;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.policy.Policy;
import java.util.List;
import java.util.Map;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * @author akis on 2019-07-24
 */
@Lazy
@Component("TradeupFakePrepredictPolicy")
public class TradeupFakePrepredictPolicy implements Policy {

    @Override
    public Context process(Context context) {
        List<Map<String, Object>> items = context.getItems();

        // set items to be null in order to skip prediction
        context.setItems(null);
        context.getExtraData().put("recallItems", items);
        return context;
    }
}
