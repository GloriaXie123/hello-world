package com._4paradigm.prophet.online.apiserver.policy.impl;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.model.context.RecallConfig;
import com._4paradigm.prophet.online.apiserver.policy.Policy;
import org.springframework.boot.actuate.autoconfigure.info.ConditionalOnEnabledInfoContributor;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Lazy
@Component("FakePreRecallPolicy")
public class FakePreRecallPolicy implements Policy{
    @Override
    public Context process(Context context) {
        RecallConfig conf = new RecallConfig();
        if (context.getRecallConfig() == null) {
            context.setRecallConfig(conf);
        }
        context.getRecallConfig().setExpression(
                "Union(Table('SHOUREN_RECALL_TABLE_1', 'user_1'), Table('SHOUREN_RECALL_TABLE_2', 'store_1'))"
        );
        return context;
    }
}
