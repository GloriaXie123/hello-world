package com._4paradigm.prophet.online.apiserver.model.dto.api_server.req;

import lombok.Data;

@Data
public class PredictReqContext {
    private boolean isDebug;
    private String experimentId;

    public void setIsDebug(boolean isDebug) {
        this.isDebug = isDebug;
    }
}
