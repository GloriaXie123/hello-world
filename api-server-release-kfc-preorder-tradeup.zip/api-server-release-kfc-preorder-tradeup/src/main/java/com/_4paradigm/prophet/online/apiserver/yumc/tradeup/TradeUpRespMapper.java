package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.model.context.RespParamMapper;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespContext;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespDTO;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespData;
import com._4paradigm.prophet.online.apiserver.repository.rtidb.RtiDBTable;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;

import static com._4paradigm.prophet.online.apiserver.yumc.tradeup.Constants.STORE_CODE;

/**
 * @author akis on 2019-06-28
 */
@Lazy
@Component("TradeUpRespMapper")
@Slf4j
public class TradeUpRespMapper implements RespParamMapper {

    @Autowired
    private RtiDBTable rtiDBTable;

    @Value("${rtidb.combinedKey}")
    private String combinedKey;

    @Value("${context.brand}")
    private String brand;

    @Value("${context.platform}")
    private String platform;

    @Value("${pt.sellCode2PromotionCode.tableName}")
    private String sellCode2PromotionCodeTableName;
    private RtiDBTable sellCode2PromotionCodeTable;

    @Value("${pt.productDisabled.tableName}")
    private String productDisabledTableName;
    private RtiDBTable productDisabledTable;

    @Value("${pt.linkid2sellCode.tableName}")
    private String linkid2sellCodeTableName;
    private RtiDBTable linkid2sellCodeTable;

    @Value("${promotionCode2linkid.tableName}")
    private String promotionCode2linkidTableName;
    private RtiDBTable promotionCode2linkidTable;

    @Value("${tradeup.returnItems.limit}")
    private Integer itemLimit;
    @Value("${tradeup.returnItems.limit}")
    private Integer returnLimit;

    @Value("${pt.multiple.itemsLimit}")
    private Integer itemMultipleLimit;
    @Value("${pt.multiple.sellCode}")
    private List<String> multipleSellCode;

    @Value("#{${pt.returnItems.TALimit}}")
    private Map<String, Integer> TALimit;

    @Value("#{${pt.multiple.MappingCode}}")
    private Map<String, Map> multipleMappingCode;
    @Value("${pt.multiple.location}")
    private String multipleLocation;

    @Value("${pt.forcePush.items}")
    private List<String> forcePushItems;

    private String storeCode;

    private String transactionId;

    //每日物料表 p_rtidb_tradeup_product_list_daily
    @Value("${pr.filtrationSoldOut.tableName}")
    private String filtrationSoldOutTableName;
    private RtiDBTable filtrationSoldOutPriceTable;

    @PostConstruct
    private void initRtidbTables() {
        sellCode2PromotionCodeTable = rtiDBTable.getTable(sellCode2PromotionCodeTableName);
        productDisabledTable = rtiDBTable.getTable(productDisabledTableName);
        linkid2sellCodeTable = rtiDBTable.getTable(linkid2sellCodeTableName);
        promotionCode2linkidTable = rtiDBTable.getTable(promotionCode2linkidTableName);
        filtrationSoldOutPriceTable = rtiDBTable.getTable(filtrationSoldOutTableName);
    }

    //查询每日物料表
    public Map<String, Object> get() {
        return filtrationSoldOutPriceTable.getRow("brand","KFC_PRE");
    }

    public List<String> getForcePushItems(List<String> forcePushItems) {
        Map<String, Object> map = get();
        if (map.isEmpty()) {
            log.warn("getLinkIdCouponcodePrice is null!");
            return forcePushItems;
        }

        List<String> list = new ArrayList<>();
        String promotioncode = ","+map.get("promotioncode")+",";
        for (String i : forcePushItems) {
            if (promotioncode.contains(","+i+",")){
                list.add(i);
            }
        }
        return list;
    }

    public List<Map<String, Object>> getItems(Context context) {
        return context.getItems();
    }

    @Override
    public PredictRespDTO process(Context context) {
        transactionId = (String) context.getReqParam().get("transactionId");
        storeCode = (String) context.getReqParam().get(STORE_CODE);
        double cartAmount = (double) context.getReqParam().get("ta");

        PredictRespContext respCtx = new PredictRespContext();
        respCtx.setExperimentId(context.getExperimentId());
        respCtx.setRecallConfigVersion("Unknown");
        respCtx.setUniqueId(context.getUniqueId());

        PredictRespData respData = new PredictRespData();
        respData.setContext(respCtx);

        List<Map<String, Object>> data = new ArrayList<>();
        List<Map<String, Object>> items = getItems(context);

        List<String> returnItem = new ArrayList<>();
        Map<Object, String> disableProduct = new HashMap<>();
        //重新赋值，
        itemLimit=returnLimit ;
        //根据TA 选择推送个数
        for (Map.Entry<String, Integer> entry : TALimit.entrySet()) {
            String amount = entry.getKey();
            Integer ta_limit = entry.getValue();
            int min = Integer.parseInt(amount.split("-")[0]);
            int max = Integer.parseInt(amount.split("-")[1]);
            if (cartAmount > min && cartAmount <= max) {
                itemLimit=ta_limit;
            }
        }

        int limit = Math.min(items.size(), itemLimit);

        int rank = 1;
        for (Map<String, Object> item : items) {
            Map<String, Object> transItem = new HashMap<>(2);
            String sellCode = (String) item.get("sell_code");
            if (sellCode.equals("0")) {
                continue;
            }
            //判断物料是否缺货，缺货则跳过不推送给前端。 缺货物料记录至context中
            if (isDisabled(sellCode)) {
                String rankStr = String.valueOf(rank);
                if (disableProduct.containsKey(rankStr)) {
                    disableProduct.put(rankStr + "+", sellCode);
                } else {
                    disableProduct.put(rankStr, sellCode);
                }
                continue;
            }
            //根据sellCode转换为promotionCode
            String promotionCode = queryPromotionCode(sellCode);
            if (StringUtils.isEmpty(promotionCode)) {
                log.warn("transactionId[{}], get empty promotion code from sell code[{}]",
                        transactionId, sellCode);
                continue;
            }
            transItem.put("promotionCode", promotionCode);
            transItem.put("rank", String.valueOf(rank++));
            data.add(transItem);

            if (rank > limit) {
                break;
            }
            returnItem.add(promotionCode);
        }

        if (!disableProduct.isEmpty()) {
            log.warn("transactionId[{}], disabled product is [{}]", transactionId, disableProduct);
        }

        //当过滤完成后的返回物料数量不足设置的返回数量时，取全量物料库补充
        if (data.size() < itemLimit) {
            List<String> replenishItem = new ArrayList<>();
            List<String> s = getForcePushItems(forcePushItems);//去除下架
            log.debug("after forcePushItems:"+s.toString());
            for (String item : s) {
                if (!returnItem.contains(item)) {
                    if (promotionCodeDisabled(item)) {
                        continue;
                    }
                    Map<String, Object> transItem = new HashMap<>(2);
                    transItem.put("promotionCode", item);
                    transItem.put("rank", String.valueOf(rank++));
                    data.add(transItem);
                    replenishItem.add(item);
                }
                if (rank > itemLimit) {
                    break;
                }
            }
            log.warn("transactionId[{}], replenish product is [{}]", transactionId, replenishItem);
        }

        List<Map<String, Object>> resultData = new LinkedList<>();
        //判断是否有大物料映射
        if (itemMultipleLimit > 0) {

            List<Map<String, Object>> multipleList = getMultipleList(cartAmount, data);
            // 增加bundle点位 E / F组规则 by hdk
            List<Map<String, Object>> reRankData = new LinkedList<>();
            int index = 0;
            for (Map<String, Object> predictor: data) {
                boolean containsKey = false;
                for (Map<String, Object> multiple : multipleList) {
                    if (multiple.containsKey(predictor.get("promotionCode"))) {
                        containsKey = true;
                        break;
                    }
                }
                if (containsKey) {
                    reRankData.add(index++, predictor);
                } else {
                    reRankData.add(predictor);
                }
            }
            switch (multipleLocation) {
                case "1":
                    resultData.addAll(multipleList);
                    resultData.addAll(data);
                    break;
                case "2":
                    resultData.addAll(data);
                    resultData.addAll(multipleList);
                    break;
                case "3":
                    resultData.addAll(data);
                    for (Map<String, Object> multipleMap : multipleList) {
                        int rank1 = Integer.parseInt((String) multipleMap.get("rank"));
                        resultData.add(rank1, multipleMap);
                    }
                    break;
                case "4":
                case "5":
                    resultData.addAll(reRankData);
                    for (Map<String, Object> multipleMap : multipleList) {
                        int rank1 = Integer.parseInt((String) multipleMap.get("rank"));
                        resultData.add(rank1, multipleMap);
                    }
                    break;
                default:
                    resultData.addAll(data);
            }

            int resultRank = 1;
            for (Map<String, Object> resultDatum : resultData) {
                resultDatum.put("rank", String.valueOf(resultRank++));
            }
            resultData = resultData.stream().map(m -> {
                Map<String,Object> map = new HashMap<>();
                map.put("promotionCode", m.get("promotionCode"));
                map.put("rank", m.get("rank"));
                return map;
            }).collect(Collectors.toList());
        } else {
            resultData.addAll(data);
        }

        context.getExtraData().put("resultData", resultData);

        if (resultData.size() != itemLimit && resultData.size() != itemMultipleLimit + itemLimit) {
            log.warn("transactionId[{}], response product size is [{}]", transactionId, resultData.size());
        }

        respData.setList(resultData);

        PredictRespDTO respDTO = new PredictRespDTO();
        respDTO.setRetCode(200);
        respDTO.setMessage("success");
        respDTO.setData(respData);
        return respDTO;
    }


    @Cacheable(cacheNames = "sellCode2PromotionCode")
    public String queryPromotionCode(String sellCode) {
        return (String) sellCode2PromotionCodeTable.getRow("sell_code", sellCode).get("promotioncode");
    }

    @Cacheable(cacheNames = "sellcode2Linkid")
    public String sellcode2Linkid(String sellCode) {
        return (String) linkid2sellCodeTable.getRow("sell_code", sellCode).get("linkid");
    }

    @Cacheable(cacheNames = "promotionCode2linkid")
    public String promotionCode2linkid(String promotionCode) {
        Map<String, Object> keyMap = Maps.newHashMapWithExpectedSize(4);
        keyMap.put("promotioncode", promotionCode);
        keyMap.put("brand", brand);
        return (String) promotionCode2linkidTable.getRow(combinedKey, keyMap).get("linkid");
    }

    private boolean isDisabled(String sellCode) {
        String linkid = sellcode2Linkid(sellCode);
        Map<String, Object> productDisabled = queryProductDisabled(storeCode, linkid);
        if (productDisabled.isEmpty()) {
            return false;
        }
        String operate_type = (String) productDisabled.get("operate_type");
        return operate_type.equals("1") || operate_type.equals("2");
    }

    private boolean promotionCodeDisabled(String promotionCode) {
        String linkid = promotionCode2linkid(promotionCode);
        Map<String, Object> productDisabled = queryProductDisabled(storeCode, linkid);
        if (productDisabled.isEmpty()) {
            return false;
        }
        String operate_type = (String) productDisabled.get("operate_type");
        return operate_type.equals("1") || operate_type.equals("2");
    }

    private Map<String, Object> queryProductDisabled(String storeCode, String linkid) {
        Map<String, Object> keyMap = Maps.newHashMapWithExpectedSize(4);
        keyMap.put("store_code", storeCode);
        keyMap.put("brand", brand);
        keyMap.put("platform", platform);
        keyMap.put("linkid", linkid);
        return productDisabledTable.getRow(combinedKey, keyMap);
    }

    private List<Map<String, Object>> getMultipleList(double cartAmount, List<Map<String, Object>> data) {
        List<String> disableMultipleProduct = new ArrayList<>();


        int rank = 1;
        List<Map<String, Object>> multipleList = new ArrayList<>();
        List<String> returnMultiple = new ArrayList<>();

        for (Map.Entry<String, Map> entry : multipleMappingCode.entrySet()) {
            String amount = entry.getKey();
            Map map = entry.getValue();

            int min = Integer.parseInt(amount.split("-")[0]);
            int max = Integer.parseInt(amount.split("-")[1]);
            // 增加bundle点位 E / F组规则 by hdk
            int mapped_index = "5".equals(multipleLocation) ? 1 : 0;

            if (cartAmount >= min && cartAmount < max) {
                for (Map<String, Object> item : data) {
                    String promotionCode = (String) item.get("promotionCode");
                    String multipleCode = (String) map.get(promotionCode);

                    if (StringUtils.isNotEmpty(multipleCode)) {
                        Map<String, Object> transItem = new HashMap<>(2);
                        transItem.put(promotionCode, multipleCode);
                        transItem.put("promotionCode", multipleCode);
                        // 增加bundle点位 E / F组规则 by hdk
                        switch (multipleLocation) {
                            case "3":
                                transItem.put("rank", String.valueOf(Integer.parseInt(String.valueOf(item.get("rank"))) + multipleList.size()));
                                break;
                            case "4":
                            case "5":
                                transItem.put("rank", mapped_index + "");
                                mapped_index = mapped_index + 2;
                                break;
                            default:
                                break;
                        }
                        multipleList.add(transItem);

                        returnMultiple.add(multipleCode);
                        rank++;
                    }
                    if (rank > itemMultipleLimit) {
                        break;
                    }
                }

                if (multipleList.size() < itemMultipleLimit) {
                    List<String> multiple = new ArrayList<>(multipleSellCode);
                    Collections.shuffle(multiple);
                    boolean flag = true;
                    for (String multipleCode : multiple) {
                        if (!returnMultiple.contains(multipleCode)) {
                            if (promotionCodeDisabled(multipleCode)) {
                                disableMultipleProduct.add(multipleCode);
                                continue;
                            }
                            Map<String, Object> transItem = new HashMap<>(2);
                            transItem.put("promotionCode", multipleCode);
                            if (mapped_index <= 1 && flag) {
                                switch (multipleLocation) {
                                    case "4":
                                        transItem.put("rank", "0" );
                                        break;
                                    case "5":
                                        transItem.put("rank", "1" );
                                        break;
                                    default:
                                        break;
                                }
                                flag = false;
                            } else {
                                transItem.put("rank", String.valueOf(data.size() + multipleList.size()));
                            }
                            multipleList.add(transItem);
                            rank++;
                        }
                        if (rank > itemMultipleLimit) {
                            break;
                        }
                    }
                }
            }
        }

        if (disableMultipleProduct.size() > 0) {
            log.warn("transactionId[{}], disableMultipleProduct is [{}]", transactionId, disableMultipleProduct);
        }

        return multipleList;
    }
}
