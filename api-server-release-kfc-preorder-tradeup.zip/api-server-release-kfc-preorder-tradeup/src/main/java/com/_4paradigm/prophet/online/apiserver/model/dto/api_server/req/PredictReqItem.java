package com._4paradigm.prophet.online.apiserver.model.dto.api_server.req;

import lombok.Data;

@Data
public class PredictReqItem {
    private String linkId;
    private String sizeId;
    private String baseId;
    private String num;
    private String price;
    private String addPrice;
    private String type;
    private String round;
    private String systemId;
}
