package com._4paradigm.prophet.online.apiserver.repository.impl;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.repository.ItemRepository;
import com._4paradigm.prophet.online.apiserver.repository.rtidb.RtiDBTable;
import com.google.common.collect.Sets;
import com.googlecode.aviator.AviatorEvaluator;
import com.googlecode.aviator.AviatorEvaluatorInstance;
import com.googlecode.aviator.runtime.function.AbstractFunction;
import com.googlecode.aviator.runtime.function.FunctionUtils;
import com.googlecode.aviator.runtime.type.AviatorObject;
import com.googlecode.aviator.runtime.type.AviatorString;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Slf4j
@Lazy
@Repository("LocalRecallItems")
public class LocalRecallItemRepository implements ItemRepository {

    private AviatorEvaluatorInstance instance;

    @Value("${itemData.primaryKey:itemId}")
    private String itemPrimaryKey;

    @Value("${itemData.LocalRecallItems.recallTablePrimaryKey:key}")
    private String tablePrimaryKey = "key";

    @Value("${itemData.LocalRecallItems.recallTableDataKey:value}")
    private String tableDataKey = "value";

    @Autowired
    private RtiDBTable rtiDBTable;

    private class TableFuncion extends AbstractFunction {
        private RtiDBTable rtiDBTable;
        private String tablePrimaryKey = "key";

        public String getName() {
            return "Table";
        }

        @Override
        public AviatorObject call(Map<String, Object> env, AviatorObject arg0, AviatorObject arg1) {
            String result = "";
            String tableName = FunctionUtils.getStringValue(arg0, env);
            String indexName = FunctionUtils.getStringValue(arg1, env);
            try {
                Object[] ret = LocalRecallItemRepository.this
                        .rtiDBTable.getTableClient().getTableSyncClient()
                        .getRow(tableName, indexName, tablePrimaryKey, 0);
                result = ret[1].toString();
            } catch (Exception e) {
                if (log.isDebugEnabled()) {
                    e.printStackTrace();
                }
            }
            return new AviatorString(result);
        }
    }

    private class UnionFunction extends AbstractFunction {
        public String getName() {
            return "Union";
        }

        @Override
        public AviatorObject call(Map<String, Object>env, AviatorObject arg0, AviatorObject arg1) {
            String leftIdListStr = FunctionUtils.getStringValue(arg0, env);
            String rightIdListStr = FunctionUtils.getStringValue(arg1, env);
            Set<String> leftIdSet = new HashSet<>();
            Set<String> rightIdSet = new HashSet<>();
            if (!leftIdListStr.isEmpty()) {
                leftIdSet = new HashSet<>(Arrays.asList(leftIdListStr.split(",")));
            }
            if(!rightIdListStr.isEmpty()) {
                rightIdSet  = new HashSet<>(Arrays.asList(rightIdListStr.split(",")));
            }
            leftIdSet.addAll(rightIdSet);
            String result = String.join(",", leftIdSet);
            return new AviatorString(result);
        }
    }

    private class IntersectFunction extends AbstractFunction {
        public String getName(){
            return "Intersect";
        }

        @Override
        public AviatorObject call(Map<String, Object>env, AviatorObject arg0, AviatorObject arg1) {
            String leftIdListStr = FunctionUtils.getStringValue(arg0, env);
            String rightIdListStr = FunctionUtils.getStringValue(arg1, env);
            Set<String> leftIdSet = new HashSet<>();
            Set<String> rightIdSet = new HashSet<>();
            if (!leftIdListStr.isEmpty()) {
                leftIdSet = new HashSet<>(Arrays.asList(leftIdListStr.split(",")));
            }
            if(!rightIdListStr.isEmpty()) {
                rightIdSet  = new HashSet<>(Arrays.asList(rightIdListStr.split(",")));
            }
            Set<String> ret = Sets.intersection(leftIdSet, rightIdSet);
            String result = String.join(",", ret);
            return new AviatorString(result);
        }
    }

    private class MinusFunction extends AbstractFunction {
        public String getName() {
            return "Minus";
        }

        @Override
        public AviatorObject call(Map<String, Object>env, AviatorObject arg0, AviatorObject arg1) {
            String leftIdListStr = FunctionUtils.getStringValue(arg0, env);
            String rightIdListStr = FunctionUtils.getStringValue(arg1, env);
            Set<String> leftIdSet = new HashSet<>();
            Set<String> rightIdSet = new HashSet<>();
            if (!leftIdListStr.isEmpty()) {
                leftIdSet = new HashSet<>(Arrays.asList(leftIdListStr.split(",")));
            }
            if(!rightIdListStr.isEmpty()) {
                rightIdSet  = new HashSet<>(Arrays.asList(rightIdListStr.split(",")));
            }
            leftIdSet.removeAll(rightIdSet);
            String result = String.join(",", leftIdSet);
            return new AviatorString(result);
        }
    }

    @PostConstruct
    private void postConstructor() {
        this.instance = AviatorEvaluator.newInstance();
        this.instance.addFunction(new TableFuncion());
        this.instance.addFunction(new UnionFunction());
        this.instance.addFunction(new IntersectFunction());
        this.instance.addFunction(new MinusFunction());
    }

    @Override
    public List<Map<String, Object>> getItems(Context context) {
        String exp = context.getRecallConfig().getExpression();
        String result = (String) this.instance.execute(exp);

        List<Map<String, Object>> ret = new ArrayList<>();
        if (!result.isEmpty()) {
            List<String> idList = Arrays.asList(result.split(","));
            Integer count = 0;
            for(String id: idList) {
                Map<String, Object> item = new HashMap<>();
                item.put(itemPrimaryKey, id);
                item.put("TitleWords", (count < 2)?13:130);
                count = count + 1;
                ret.add(item);
            }
        }
        return ret;
    }
}
