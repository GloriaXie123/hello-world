package com._4paradigm.prophet.online.apiserver.model.context;

import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespDTO;

public interface RespParamMapper {
    PredictRespDTO process(Context context);
}
