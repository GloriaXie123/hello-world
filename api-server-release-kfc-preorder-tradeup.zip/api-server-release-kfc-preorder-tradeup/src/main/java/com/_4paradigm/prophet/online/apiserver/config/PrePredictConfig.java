package com._4paradigm.prophet.online.apiserver.config;

import com._4paradigm.prophet.online.apiserver.policy.Policy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PrePredictConfig {
    @Autowired
    private ApplicationContext context;

    @Bean("prePredictPolicyAlias")
    public Policy prePredictPolicyAlias(@Value("${policy.prePredict.ImplType}") String qualifier) {
        return (Policy) context.getBean(qualifier);
    }
}
