package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.repository.UserRepository;
import com._4paradigm.prophet.online.apiserver.repository.rtidb.RtiDBTable;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.Map;

/**
 * @author akis on 2019-06-30
 */
@Lazy
@Repository("TradeUpUser")
@Slf4j
public class TradeUpUserRepository implements UserRepository {

    @Autowired
    private RtiDBTable rtiDBTable;

    @Value("${pt.user.key}")
    private String userTablePK;

    @Value("${pt.user.tableName}")
    private String userTableName;
    private RtiDBTable userTable;

    @PostConstruct
    private void postConstruct() {
        userTable = rtiDBTable.getTable(userTableName);
    }

    @Override
    public Map<String, Object> getUser(Context context) {
        String userCode = (String) context.getReqParam().get("userCode");
        if (Strings.isNullOrEmpty(userCode)) {
            userCode = "0";
        }
        Map<String, Object> row = userTable.getRow(userTablePK, userCode);
        if (row.isEmpty()) {
            row = userTable.getRow(userTablePK, "0");
        }
        return row;

    }
}
