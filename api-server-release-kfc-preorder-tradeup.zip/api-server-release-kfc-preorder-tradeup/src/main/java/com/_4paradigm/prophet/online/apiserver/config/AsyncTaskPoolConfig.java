package com._4paradigm.prophet.online.apiserver.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

@EnableAsync
@Configuration
class AsyncTaskPoolConfig {

    @Value("${asyncTaskExecutor.corePoolSize:50}")
    private int corePoolSize;

    @Value("${asyncTaskExecutor.maxPoolSize:100}")
    private int maxPoolSize;

    @Value("${asyncTaskExecutor.queueCapacity:100}")
    private int queueCapacity;

    @Value("${asyncTaskExecutor.keepAliveSeconds:60}")
    private int keepAliveSeconds;

    @Bean("asyncTaskExecutor")
    public Executor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setKeepAliveSeconds(keepAliveSeconds);
        executor.setThreadNamePrefix("asyncTaskExecutor-");
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.AbortPolicy());
        return executor;
    }
}