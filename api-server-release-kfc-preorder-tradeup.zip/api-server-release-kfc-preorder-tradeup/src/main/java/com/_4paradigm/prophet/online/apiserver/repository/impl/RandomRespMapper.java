package com._4paradigm.prophet.online.apiserver.repository.impl;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.model.context.RespParamMapper;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespContext;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespDTO;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespData;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespItem;
import com._4paradigm.prophet.online.apiserver.util.ZipUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

import javax.naming.spi.Resolver;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

@Lazy
@Configuration("RandomRespMapper")
public class RandomRespMapper implements RespParamMapper {
    @Value("${context.RandomRespMapper.itemLimit:5}")
    private Integer itemLimit;

    @Value("${context.RandomRespMapp.codePrefix:HKD0}")
    private String codePrefix;

    private List<Map<String, Object>> RandomItemList() {
        List<Map<String, Object>> ret = new ArrayList<>();
        Integer randNum = 9999;
        Set<Integer> numSet = new HashSet<>();
        for (int idx = 0; idx < itemLimit; idx++) {
            randNum = ThreadLocalRandom.current().nextInt(1000, 10000);
            while(numSet.contains(randNum)) {
                randNum = ThreadLocalRandom.current().nextInt(1000, 10000);
            }
            numSet.add(randNum);
            Map<String, Object> item = new HashMap<>();
            item.put("rank",(String.valueOf(idx+1)));
            item.put("promotionCode", codePrefix.concat(Integer.toString(randNum)));
            ret.add(item);
        }
        return ret;
    }

    @Override
    public PredictRespDTO process(Context context) {
        PredictRespData respData = new PredictRespData();
        respData.setList(this.RandomItemList());

        PredictRespContext respCtx = new PredictRespContext();
        respCtx.setUniqueId(context.getUniqueId());
        respCtx.setExperimentId(context.getExperimentId());
        respCtx.setRecallConfigVersion("Unknown");
        respData.setContext(respCtx);

        PredictRespDTO respDTO = new PredictRespDTO();
        respDTO.setRetCode(200);
        respDTO.setMessage("success");
        respDTO.setData(respData);
        return respDTO;
    }
}
