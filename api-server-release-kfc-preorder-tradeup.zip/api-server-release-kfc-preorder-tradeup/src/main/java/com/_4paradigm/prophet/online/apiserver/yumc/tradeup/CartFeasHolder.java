package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import java.util.HashMap;
import java.util.Map;

/**
 * @author akis on 2019-06-28
 */
public class CartFeasHolder {

    public Map<String, Double> taFeas = new HashMap<String, Double>(10) {
        {
            put("ta", 0.0);
            put("cart_combo_sell_price", 0.0);
            put("cart_single_sell_price", 0.0);
            put("cart_promo_sell_price", 0.0);
            put("cart_disc_sell_price", 0.0);
        }
    };

    public Map<String, Integer> cntFeas = new HashMap<String, Integer>(110) {
        {
            put("cart_kidstoyflag", 0);
            put("cart_combo_unit_sold", 0);
            put("cart_single_unit_sold", 0);
            put("cart_promo_unit_sold", 0);
            put("cart_disc_unit_sold", 0);
            put("cart_total_unit_sold", 0);

            // 单品
            put("cart_side_sold", 0);
            put("cart_coffee_sold", 0);
            put("cart_conge_sold", 0);
            put("cart_nutrition_sold", 0);
            put("cart_panini_sold", 0);
            put("cart_riceroll_sold", 0);
            put("cart_dabing_sold", 0);
            put("cart_burger_sold", 0);
            put("cart_chickensnack_sold", 0);
            put("cart_cob_sold", 0);
            put("cart_csd_sold", 0);
            put("cart_eggtart_sold", 0);
            put("cart_icecream_sold", 0);
            put("cart_sidefrenchfries_sold", 0);
            put("cart_sideothers_sold", 0);
            put("cart_tea_sold", 0);
            put("cart_twister_sold", 0);
            put("cart_wing_sold", 0);
            put("cart_waffle_sold", 0);
            put("cart_croissant_sold", 0);
            put("cart_nonfood_sold", 0);
            put("cart_pie_sold", 0);
            put("cart_rice_sold", 0);
            put("cart_juice_sold", 0);
            put("cart_lto_sold", 0);

            // 套餐子项
            put("cart_combo_side_sold", 0);
            put("cart_combo_coffee_sold", 0);
            put("cart_combo_conge_sold", 0);
            put("cart_combo_nutrition_sold", 0);
            put("cart_combo_panini_sold", 0);
            put("cart_combo_riceroll_sold", 0);
            put("cart_combo_dabing_sold", 0);
            put("cart_combo_burger_sold", 0);
            put("cart_combo_chickensnack_sold", 0);
            put("cart_combo_cob_sold", 0);
            put("cart_combo_csd_sold", 0);
            put("cart_combo_eggtart_sold", 0);
            put("cart_combo_icecream_sold", 0);
            put("cart_combo_sidefrenchfries_sold", 0);
            put("cart_combo_sideothers_sold", 0);
            put("cart_combo_tea_sold", 0);
            put("cart_combo_twister_sold", 0);
            put("cart_combo_wing_sold", 0);
            put("cart_combo_waffle_sold", 0);
            put("cart_combo_croissant_sold", 0);
            put("cart_combo_nonfood_sold", 0);
            put("cart_combo_pie_sold", 0);
            put("cart_combo_rice_sold", 0);
            put("cart_combo_juice_sold", 0);
            put("cart_combo_lto_sold", 0);

            // 优惠子项
            put("cart_promo_side_sold", 0);
            put("cart_promo_coffee_sold", 0);
            put("cart_promo_conge_sold", 0);
            put("cart_promo_nutrition_sold", 0);
            put("cart_promo_panini_sold", 0);
            put("cart_promo_riceroll_sold", 0);
            put("cart_promo_dabing_sold", 0);
            put("cart_promo_burger_sold", 0);
            put("cart_promo_chickensnack_sold", 0);
            put("cart_promo_cob_sold", 0);
            put("cart_promo_csd_sold", 0);
            put("cart_promo_eggtart_sold", 0);
            put("cart_promo_icecream_sold", 0);
            put("cart_promo_sidefrenchfries_sold", 0);
            put("cart_promo_sideothers_sold", 0);
            put("cart_promo_tea_sold", 0);
            put("cart_promo_twister_sold", 0);
            put("cart_promo_wing_sold", 0);
            put("cart_promo_waffle_sold", 0);
            put("cart_promo_croissant_sold", 0);
            put("cart_promo_nonfood_sold", 0);
            put("cart_promo_pie_sold", 0);
            put("cart_promo_rice_sold", 0);
            put("cart_promo_juice_sold", 0);
            put("cart_promo_lto_sold", 0);


            // type=4
            put("cart_disc_side_sold", 0);
            put("cart_disc_coffee_sold", 0);
            put("cart_disc_conge_sold", 0);
            put("cart_disc_nutrition_sold", 0);
            put("cart_disc_panini_sold", 0);
            put("cart_disc_riceroll_sold", 0);
            put("cart_disc_dabing_sold", 0);
            put("cart_disc_burger_sold", 0);
            put("cart_disc_chickensnack_sold", 0);
            put("cart_disc_cob_sold", 0);
            put("cart_disc_csd_sold", 0);
            put("cart_disc_eggtart_sold", 0);
            put("cart_disc_icecream_sold", 0);
            put("cart_disc_sidefrenchfries_sold", 0);
            put("cart_disc_sideothers_sold", 0);
            put("cart_disc_tea_sold", 0);
            put("cart_disc_twister_sold", 0);
            put("cart_disc_wing_sold", 0);
            put("cart_disc_waffle_sold", 0);
            put("cart_disc_croissant_sold", 0);
            put("cart_disc_nonfood_sold", 0);
            put("cart_disc_pie_sold", 0);
            put("cart_disc_rice_sold", 0);
            put("cart_disc_juice_sold", 0);
            put("cart_disc_lto_sold", 0);
        }
    };


}
