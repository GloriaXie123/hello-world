package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
/**
 * @author akis on 2019-06-28
 */
public class Constants {
    public static final Map<String, String> category2Flag = new HashMap<String, String>() {
        {
            put("breakfast side", "cart_side");
            put("coffee", "cart_coffee");
            put("congee", "cart_conge");
            put("nutrition", "cart_nutrition");
            put("panini", "cart_panini");
            put("rice roll", "cart_riceroll");
            put("大饼", "cart_dabing");
            put("burger", "cart_burger");
            put("chicken snack", "cart_chickensnack");
            put("cob", "cart_cob");
            put("csd", "cart_csd");
            put("eggtart", "cart_eggtart");
            put("icecream", "cart_icecream");
            put("side french fries", "cart_sidefrenchfries");
            put("side others", "cart_sideothers");
            put("tea", "cart_tea");
            put("twister", "cart_twister");
            put("wing", "cart_wing");
            put("waffle", "cart_waffle");
            put("croissant", "cart_croissant");
            put("non-food", "cart_nonfood");
            put("snack", "cart_snack");
            put("pie", "cart_pie");
            put("juice", "cart_juice");
            put("rice", "cart_rice");
        }
    };


    public static final Map<String, String> flag2Type0FeaName = new HashMap<String, String>() {
        {
            put("cart_side", "cart_side_sold");
            put("cart_coffee", "cart_coffee_sold");
            put("cart_conge", "cart_conge_sold");
            put("cart_nutrition", "cart_nutrition_sold");
            put("cart_panini", "cart_panini_sold");
            put("cart_riceroll", "cart_riceroll_sold");
            put("cart_dabing", "cart_dabing_sold");
            put("cart_burger", "cart_burger_sold");
            put("cart_chickensnack", "cart_chickensnack_sold");
            put("cart_cob", "cart_cob_sold");
            put("cart_csd", "cart_csd_sold");
            put("cart_eggtart", "cart_eggtart_sold");
            put("cart_icecream", "cart_icecream_sold");
            put("cart_sidefrenchfries", "cart_sidefrenchfries_sold");
            put("cart_sideothers", "cart_sideothers_sold");
            put("cart_tea", "cart_tea_sold");
            put("cart_twister", "cart_twister_sold");
            put("cart_wing", "cart_wing_sold");
            put("cart_waffle", "cart_waffle_sold");
            put("cart_croissant", "cart_croissant_sold");
            put("cart_nonfood", "cart_nonfood_sold");
            put("cart_snack", "cart_snack_sold");
            put("cart_pie", "cart_pie_sold");
            put("cart_juice", "cart_juice_sold");
            put("cart_rice", "cart_rice_sold");
            put("cart_lto", "cart_lto_sold");
        }
    };

    public static final Map<String, String> flag2Type2FeaName = new HashMap<String, String>() {
        {
            put("cart_side", "cart_combo_side_sold");
            put("cart_coffee", "cart_combo_coffee_sold");
            put("cart_conge", "cart_combo_conge_sold");
            put("cart_nutrition", "cart_combo_nutrition_sold");
            put("cart_panini", "cart_combo_panini_sold");
            put("cart_riceroll", "cart_combo_riceroll_sold");
            put("cart_dabing", "cart_combo_dabing_sold");
            put("cart_burger", "cart_combo_burger_sold");
            put("cart_chickensnack", "cart_combo_chickensnack_sold");
            put("cart_cob", "cart_combo_cob_sold");
            put("cart_csd", "cart_combo_csd_sold");
            put("cart_eggtart", "cart_combo_eggtart_sold");
            put("cart_icecream", "cart_combo_icecream_sold");
            put("cart_sidefrenchfries", "cart_combo_sidefrenchfries_sold");
            put("cart_sideothers", "cart_combo_sideothers_sold");
            put("cart_tea", "cart_combo_tea_sold");
            put("cart_twister", "cart_combo_twister_sold");
            put("cart_wing", "cart_combo_wing_sold");
            put("cart_waffle", "cart_combo_waffle_sold");
            put("cart_croissant", "cart_combo_croissant_sold");
            put("cart_nonfood", "cart_combo_nonfood_sold");
            put("cart_snack", "cart_combo_snack_sold");
            put("cart_pie", "cart_combo_pie_sold");
            put("cart_juice", "cart_combo_juice_sold");
            put("cart_rice", "cart_combo_rice_sold");
            put("cart_lto", "cart_combo_lto_sold");
        }
    };

    public static final Map<String, String> flag2Type3FeaName = new HashMap<String, String>() {
        {
            put("cart_side", "cart_promo_side_sold");
            put("cart_coffee", "cart_promo_coffee_sold");
            put("cart_conge", "cart_promo_conge_sold");
            put("cart_nutrition", "cart_promo_nutrition_sold");
            put("cart_panini", "cart_promo_panini_sold");
            put("cart_riceroll", "cart_promo_riceroll_sold");
            put("cart_dabing", "cart_promo_dabing_sold");
            put("cart_burger", "cart_promo_burger_sold");
            put("cart_chickensnack", "cart_promo_chickensnack_sold");
            put("cart_cob", "cart_promo_cob_sold");
            put("cart_csd", "cart_promo_csd_sold");
            put("cart_eggtart", "cart_promo_eggtart_sold");
            put("cart_icecream", "cart_promo_icecream_sold");
            put("cart_sidefrenchfries", "cart_promo_sidefrenchfries_sold");
            put("cart_sideothers", "cart_promo_sideothers_sold");
            put("cart_tea", "cart_promo_tea_sold");
            put("cart_twister", "cart_promo_twister_sold");
            put("cart_wing", "cart_promo_wing_sold");
            put("cart_waffle", "cart_promo_waffle_sold");
            put("cart_croissant", "cart_promo_croissant_sold");
            put("cart_nonfood", "cart_promo_nonfood_sold");
            put("cart_snack", "cart_promo_snack_sold");
            put("cart_pie", "cart_promo_pie_sold");
            put("cart_juice", "cart_promo_juice_sold");
            put("cart_rice", "cart_promo_rice_sold");
            put("cart_lto", "cart_promo_lto_sold");
        }
    };

    public static final Map<String, String> flag2Type4FeaName = new HashMap<String, String>() {
        {
            put("cart_side", "cart_disc_side_sold");
            put("cart_coffee", "cart_disc_coffee_sold");
            put("cart_conge", "cart_disc_conge_sold");
            put("cart_nutrition", "cart_disc_nutrition_sold");
            put("cart_panini", "cart_disc_panini_sold");
            put("cart_riceroll", "cart_disc_riceroll_sold");
            put("cart_dabing", "cart_disc_dabing_sold");
            put("cart_burger", "cart_disc_burger_sold");
            put("cart_chickensnack", "cart_disc_chickensnack_sold");
            put("cart_cob", "cart_disc_cob_sold");
            put("cart_csd", "cart_disc_csd_sold");
            put("cart_eggtart", "cart_disc_eggtart_sold");
            put("cart_icecream", "cart_disc_icecream_sold");
            put("cart_sidefrenchfries", "cart_disc_sidefrenchfries_sold");
            put("cart_sideothers", "cart_disc_sideothers_sold");
            put("cart_tea", "cart_disc_tea_sold");
            put("cart_twister", "cart_disc_twister_sold");
            put("cart_wing", "cart_disc_wing_sold");
            put("cart_waffle", "cart_disc_waffle_sold");
            put("cart_croissant", "cart_disc_croissant_sold");
            put("cart_nonfood", "cart_disc_nonfood_sold");
            put("cart_snack", "cart_disc_snack_sold");
            put("cart_pie", "cart_disc_pie_sold");
            put("cart_juice", "cart_disc_juice_sold");
            put("cart_rice", "cart_disc_rice_sold");
            put("cart_lto", "cart_disc_lto_sold");
        }
    };

    public static final String KIDS_TOY = "kids meal toy";

    public static final String CART_LTO= "cart_lto";


    public static final String CITY_NAME = "city_name";
    public static final String CHANNEL = "preorder_channel_name";
    public static final String STORE_CODE = "store_code";

    public static final String SHOPPING_CART_SUBCLASSES ="shoppingCartSubclasses";
    public static final String SHOPPING_CART_SUBCATEGORIES = "shoppingCartSubcategories";
    public static final String DATE_TODAY="dateToday";
    public static final String TIME_NOW="timeNow";



    public static Set<String> SUBCATEGORIES_LTO =
            new HashSet<>(Arrays.asList("congee", "wing", "croissant", "panini", "juice",
                    "chicken snack", "coffee", "side others", "burger", "csd", "cob", "rice",
                    "side french fries", "waffle", "nutrition", "eggtart", "breakfast side",
                    "snack", "twister", "pie", "non-food", "tea", "rice roll", "icecream", "大饼"));

    public static Set<String> CATEGORIES_LTO =
            new HashSet<>(Arrays.asList("non-food","non food", "通用套餐头", "others", "none"));

    public static final List<String> all_classes = Arrays.asList("10pc chicken", "11pc chicken",
            "12pc chicken", "42", "9pc chicken", "Aqueous and others", "BIG Cone", "Burger",
            "Chicken Rice", "Chicken Twister", "Chizza", "Congee", "Croissant", "Dough Sticks",
            "Dough Sticks", "Drum Stick", "Egg", "Eggtart", "Float Coffee", "Fried Wing", "Fruit Tea",
            "Hash Brown", "Hot Tea", "Juice", "K-flurry", "Milk", "Milk Tea", "Mirinda", "Non-Food",
            "Non-food kids premium", "Nugget", "Nutritional Tea", "Other Teas", "Others", "Panini",
            "Pastry", "Pepsi", "Pie", "Pop Corn", "Pork Rice", "Regular Coffee", "Rice Roll", "Salad Meal",
            "Side French Fries", "Side Others", "Side Soup", "Side Vegetable", "Side Others", "Soya Milk",
            "Sundae", "Taco", "Tea", "Waffle", "Waffle Icecream", "Wing Side", "beef wrap", "cake",
            "chicken Twister", "chicken rice", "chicken snack", "cone", "fried wing", "null", "roasted wing",
            "北海道冰淇淋", "大饼", "早餐全餐", "爆米花", "现磨咖啡推广版", "粽子", "纯纯玉米饮", "葡萄柚鲜果莫吉托特饮");

    public static final List<String> all_categories = Arrays.asList("Dessert", "Drink", "Main", "Non-Food", "Others", "Side Item", "Side Item", "Snack", "null");

    public static final List<String> all_sub_categories = Arrays.asList("42", "Aqueous and others",
            "Breakfast Side", "Breakfast Side", "Burger", "COB", "CSD", "Chicken Snack", "Cob", "Coffee",
            "Congee", "Croissant", "Csd", "Eggtart", "Icecream", "Juice", "Main Other", "Mirinda",
            "Non-Food", "Non-food kids", "Nutrition", "Others", "Panini", "Pastry", "Pie", "Rice",
            "Rice Roll", "Salad Meal", "Side French Fries", "Side Others", "Side Others", "Tea",
            "Twister", "Waffle", "Wing", "Wrap", "cake", "chicken snack", "null", "wing", "大饼",
            "早餐全餐", "爆米花", "粽子");
}
