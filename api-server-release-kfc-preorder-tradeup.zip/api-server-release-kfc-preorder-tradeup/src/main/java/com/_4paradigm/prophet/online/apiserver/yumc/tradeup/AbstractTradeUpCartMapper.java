package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.model.context.ReqParamMapper;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.req.predictReqDTO;
import com._4paradigm.prophet.online.apiserver.repository.rtidb.RtiDBTable;
import com._4paradigm.prophet.online.apiserver.yumc.tradeup.Request.ShoppingItem;
import com._4paradigm.prophet.online.apiserver.yumc.tradeup.Request.SubItem;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Strings;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Lazy;

import javax.annotation.PostConstruct;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com._4paradigm.prophet.online.apiserver.yumc.tradeup.Constants.*;

/**
 * @author akis on 2019-06-28
 */
@Lazy
@Slf4j
public abstract class AbstractTradeUpCartMapper implements ReqParamMapper {

    @Autowired
    private RtiDBTable rtiDBTable;

    @Autowired
    private ObjectMapper objectMapper;

    @Value("${tradeup.timezone:+08:00}")
    private String timezone;

    @Value("${tradeup.datePattern:yyyy-MM-dd}")
    private String datePattern;

    @Value("${tradeup.rerank.timePattern:HH:mm}")
    private String timePattern;

    private DateTimeFormatter DATE_FORMATTER;
    private DateTimeFormatter TIME_FORMATTER;


    @Value("${pt.linkId2Category.tableName}")
    private String linkId2CategoryTableName;
    private RtiDBTable linkId2CategoryTable;

    @Value("${pt.systemId2LinkId.tableName}")
    private String systemId2LinkIdTableName;
    private RtiDBTable systemId2LinkIdTable;

    @Value("${pt.storeProduct.combo.tableName}")
    private String storeProductComboTableName;
    private RtiDBTable storeProductComboTable;

    @Value("${pt.storeProduct.CSingle.tableName}")
    private String storeCSingleProductTableName;
    private RtiDBTable storeCSingleProductTable;

    private ThreadLocal<String> transactionIdTreadLocal = ThreadLocal.withInitial(() -> "empty");

    @PostConstruct
    private void initRtidbTables() {
        DATE_FORMATTER = DateTimeFormatter.ofPattern(datePattern);
        TIME_FORMATTER = DateTimeFormatter.ofPattern(timePattern);

        linkId2CategoryTable = rtiDBTable.getTable(linkId2CategoryTableName);
        systemId2LinkIdTable = rtiDBTable.getTable(systemId2LinkIdTableName);

        storeProductComboTable = rtiDBTable.getTable(storeProductComboTableName);
        storeCSingleProductTable = rtiDBTable.getTable(storeCSingleProductTableName);
    }

    @Override
    public Map<String, Object> process(predictReqDTO req, Context context) {
        Map<String, Object> rawFeatures = req.getRawFeatures();
        Request request = objectMapper.convertValue(rawFeatures, Request.class);
        log.debug("converted request: {}", request);
        transactionIdTreadLocal.set(request.getTransactionId());
        CartFeasHolder cartFeasHolder = new CartFeasHolder();
        Set<String> shoppingCartSubclasses = new HashSet<>();
        Set<String> shoppingCartSubcategories = new HashSet<>();
        //统计个数/ta
        accumulate(request, cartFeasHolder, shoppingCartSubclasses, shoppingCartSubcategories);
        context.getExtraData().put(SHOPPING_CART_SUBCLASSES, shoppingCartSubclasses);
        context.getExtraData().put(SHOPPING_CART_SUBCATEGORIES, shoppingCartSubcategories);
        context.getExtraData().put("rawRequest", rawFeatures);

        Map<String, Object> cartFeas = Maps.newHashMapWithExpectedSize(100);
        cartFeas.putAll(cartFeasHolder.taFeas);
        cartFeas.putAll(cartFeasHolder.cntFeas);
        cartFeas.putAll(getExtraParams(request));
        return cartFeas;
    }

    /**
     * 1. 统计每个单品的个数
     * 2. 统计儿童餐品的个数
     * 3. 统计套餐的总个数
     * 4. 统计非套餐（single unit）的总个数
     * 5. 统计所有产品的总个数（套餐子项 + single unit）
     * 6. 统计非套餐的总TA
     * 7. 统计套餐的总TA
     * 8. 统计所有商品总TA
     */
    private void accumulate(Request request, CartFeasHolder cartFeasHolder,
                            Set<String> shoppingCartSubclasses, Set<String> shoppingCartSubcategories) {
        // 获取前端请求参数中的购物车信息
        for (ShoppingItem shoppingItem : request.getShoppingCart()) {
            // may get an empty object from json value like {}
            String linkId = shoppingItem.getLinkId();
            String storeCode = request.getStoreCode();
            String systemId = shoppingItem.getSystemId();
            String type = shoppingItem.getType();
            if (linkId == null) {
                continue;
            }
            if (shoppingItem.getItemLinkIds() != null && shoppingItem.getItemLinkIds().size() > 0) {
//                jira 417 KFC 2个tradeup场景购物车拉平逻辑更新
//                1. 首先判断是否自带了itemLinkIds字段
//                2. 如果有，则直接用itemLinkIds中的子项，跳过370中的逻辑
//                3. 如果没有，保持现有逻辑
            } else if ("0".equals(linkId)) {
                if ("3".equals(type) || "4".equals(type)) {
                    linkId = queryLinkIdFromSystemId(systemId);
                    if (linkId == null) {
                        log.warn("transactionId[{}], get linkId[null] from systemId[{}]",
                                transactionIdTreadLocal.get(), systemId);
                        continue;
                    }
                    Map<String, Object> storeProduct = storeProductComboTable.getRow("storecode", storeCode);
                    String storeProductLink = (String) storeProduct.get("linkids");
                    if (StringUtils.isNotEmpty(storeProductLink)) {
                        if (storeProductLink.contains(linkId)) {
                            setItemLinkidsByLinkidAndStoreCode(shoppingItem, linkId, storeCode, type);
                        }
                    } else {
                        log.warn("transactionId[{}], store product link is empty, storecode is [{}]",
                                transactionIdTreadLocal.get(), storeCode);
                    }
                }
                // linkid不为空或0时，type 为3/4时，需要获取子项
            } else if("3".equals(type) || "4".equals(type)) {
                setItemLinkidsByLinkidAndStoreCode(shoppingItem, linkId, storeCode, type);
            }
            int num = Integer.parseInt(shoppingItem.getNum());
            int realPrice = Integer.parseInt(shoppingItem.getRealPrice());
            int itemPrice = num * realPrice;

            // 有子项的情况
            if (shoppingItem.getItemLinkIds() != null && shoppingItem.getItemLinkIds().size() > 0) {
                cartFeasHolder.taFeas.put("cart_combo_sell_price",
                        cartFeasHolder.taFeas.get("cart_combo_sell_price") + itemPrice / 100.0);
                cartFeasHolder.cntFeas.put("cart_combo_unit_sold",
                        cartFeasHolder.cntFeas.get("cart_combo_unit_sold") + num);
                for (SubItem subItem : shoppingItem.getItemLinkIds()) {
                    String subLinkId = subItem.getLinkId();
                    if (subLinkId == null || "0".equals(subLinkId)) {
                        continue;
                    }

                    int subNum = Integer.parseInt(subItem.getNum());
                    processCommonFeatures(cartFeasHolder,
                            shoppingCartSubclasses,
                            shoppingCartSubcategories,
                            subNum,
                            subLinkId,
                            subItem.getType()
                    );
                }
            } else { //非套餐
                // 单品统计
                if ("0".equals(type)) {
                    cartFeasHolder.cntFeas.put("cart_single_unit_sold",
                            cartFeasHolder.cntFeas.get("cart_single_unit_sold") + num);
                    cartFeasHolder.taFeas.put("cart_single_sell_price",
                            cartFeasHolder.taFeas.get("cart_single_sell_price") + itemPrice / 100.0);
                    // 优惠券统计
                } else if ("3".equals(type)) {
                    cartFeasHolder.cntFeas.put("cart_promo_unit_sold",
                            cartFeasHolder.cntFeas.get("cart_promo_unit_sold") + num);
                    cartFeasHolder.taFeas.put("cart_promo_sell_price",
                            cartFeasHolder.taFeas.get("cart_promo_sell_price") + itemPrice / 100.0);
                }
                // disc统计 非券优惠类型
                if ("4".equals(type)) {
                    cartFeasHolder.cntFeas.put("cart_disc_unit_sold",
                            cartFeasHolder.cntFeas.get("cart_disc_unit_sold") + num);
                    cartFeasHolder.taFeas.put("cart_disc_sell_price",
                            cartFeasHolder.taFeas.get("cart_disc_sell_price") + itemPrice / 100.0);
                }
                if (linkId == null || "0".equals(linkId)) {
                    continue;
                }
                processCommonFeatures(cartFeasHolder,
                        shoppingCartSubclasses,
                        shoppingCartSubcategories,
                        num,
                        linkId,
                        type);
            }
            cartFeasHolder.taFeas.put("ta", cartFeasHolder.taFeas.get("ta") + itemPrice / 100.0);
        }
    }

    private void setItemLinkidsByLinkidAndStoreCode(ShoppingItem shoppingItem, String linkId, String storeCode, String type) {
        Map<String, Object> cSingleMenuData = queryStoreCSingleProduct(storeCode, linkId);
        List<SubItem> subItems = makeItemLinkIds(cSingleMenuData, type);
        shoppingItem.setItemLinkIds(subItems);
        log.debug("transactionId[{}], linkId is [{}] storeProduct is [{}]",
                transactionIdTreadLocal.get(), linkId,subItems);
    }

    private void processCommonFeatures(CartFeasHolder cartFeasHolder,
                                       Set<String> shoppingCartSubclasses, Set<String> shoppingCartSubcategories,
                                       int num, String linkId, String type) {
        MutableBoolean isKidsToy = new MutableBoolean();
        isKidsToy.setFalse();

        Map<String, Object> productSupply = queryProductSupply(linkId);
        if (productSupply.isEmpty()) {
            log.warn("transactionId[{}], cannot get productSupply from linkId[{}]", transactionIdTreadLocal.get(), linkId);
        } else {
            String flagName = getFeaFlagName(productSupply, shoppingCartSubclasses, shoppingCartSubcategories, isKidsToy);
            if (flagName != null) {
                String cntFeaName = null;
                if ("0".equals(type)) {
                    cntFeaName = Constants.flag2Type0FeaName.get(flagName);
                } else if ("2".equals(type)) {
                    cntFeaName = Constants.flag2Type2FeaName.get(flagName);
                } else if ("3".equals(type)) {
                    cntFeaName = Constants.flag2Type3FeaName.get(flagName);
                } else if ("4".equals(type)) {
                    cntFeaName = Constants.flag2Type4FeaName.get(flagName);
                }
                if (cntFeaName != null) {
                    cartFeasHolder.cntFeas.put(cntFeaName,
                            cartFeasHolder.cntFeas.get(cntFeaName) + num);
                }
            }

        }
        if (isKidsToy.getValue()) {
            cartFeasHolder.cntFeas.put("cart_kidstoyflag",
                    cartFeasHolder.cntFeas.get("cart_kidstoyflag") + num);
        }
        cartFeasHolder.cntFeas.put("cart_total_unit_sold",
                cartFeasHolder.cntFeas.get("cart_total_unit_sold") + num);
    }

    private Map<String, String> getExtraParams(Request request) {
        Map<String, String> extraParams = Maps.newHashMapWithExpectedSize(15);
        extraParams.put("userCode", StringUtils.lowerCase(request.getUserCode()));
        extraParams.put("systemTime", request.getSystemTime());
        extraParams.put("promiseTime", request.getPromiseTime());
        extraParams.put(CITY_NAME, request.getCityName());
        extraParams.put("cityCode", request.getCityCode());
        extraParams.put(STORE_CODE, request.getStoreCode());
        extraParams.put("brand", request.getBrand());
        extraParams.put("transactionId", request.getTransactionId());
        extraParams.put("marketCode", request.getMarketCode());
        extraParams.put(CHANNEL, mapChannel(request.getChannel()));
        extraParams.put("online_channel", request.getChannel());
        extraParams.putAll(extractTime(Integer.parseInt(request.getSystemTime())));
        return extraParams;
    }

    private String mapChannel(String ori) {
        String channel;
        if (ori == null) {
            channel = "Unknown";
        } else if ("ALIPAY_MINIAPP".equals(ori)) {
            channel = "ALIMINI";
        } else {
            channel = StringUtils.upperCase(ori);
        }
        return channel;
    }

    private Map<String, String> extractTime(Integer ts) {
        Instant instant = Instant.ofEpochSecond(ts);
        LocalDateTime localDateTime = instant.atZone(ZoneOffset.of(timezone)).toLocalDateTime();

        Map<String, String> res = Maps.newHashMapWithExpectedSize(4);
        res.put(DATE_TODAY, DATE_FORMATTER.format(localDateTime));


        int day = localDateTime.getDayOfWeek().getValue();
        if (day >= 1 && day <= 5) {
            res.put("work_day_name", "工作日");
        } else {
            res.put("work_day_name", "周末");
        }
        String daypart = getDaypart(localDateTime);
        String cityrecall = getCityRecallDaypart(localDateTime);
        res.put("city_recall_daypart_name", cityrecall);
        res.put("daypart_name", daypart);

        return res;
    }

    public abstract String getCityRecallDaypart(LocalDateTime localDateTime);


    public String getDaypart(LocalDateTime localDateTime) {

        String timeNow = TIME_FORMATTER.format(localDateTime);

        String daypart = "";

        if (between(timeNow, "06:00", "09:30")) {
            daypart = "Breakfast";
        } else if (between(timeNow, "09:30", "11:00")) {
            daypart = "Morning";
        } else if (between(timeNow, "11:00", "14:00")) {
            daypart = "Lunch";
        } else if (between(timeNow, "14:00", "17:00")) {
            daypart = "Afternoon";
        } else if (between(timeNow, "17:00", "20:00")) {
            daypart = "Dinner";
        } else if (between(timeNow, "20:00", "24:00")) {
            daypart = "Late night";
        }

        return daypart;
    }

    private boolean between(String time, String start, String end) {

        return time.compareTo(start) >= 0 && time.compareTo(end) < 0;
    }


    private String getFeaFlagName(Map<String, Object> productSupply, Set<String> shoppingCartSubclasses,
                                  Set<String> shoppingCartSubcategories, MutableBoolean isKidsToy) {
        String feaName = null;
        String subcategory = StringUtils.lowerCase((String) productSupply.get("subcategory"));
        String category = StringUtils.lowerCase((String) productSupply.get("category"));
        String subClass = StringUtils.lowerCase((String) productSupply.get("subclass"));

        if (subcategory != null && Constants.category2Flag.get(subcategory) != null) {
            feaName = Constants.category2Flag.get(subcategory);
        } else if (!Constants.SUBCATEGORIES_LTO.contains(subcategory)
                && !Constants.CATEGORIES_LTO.contains(category)
                && category != null) {
            feaName = Constants.CART_LTO;
        }

        shoppingCartSubclasses.add(subClass);
        shoppingCartSubcategories.add(subcategory);
        isKidsToy.setValue(Constants.KIDS_TOY.equals(subClass));

        return feaName;
    }

    @Cacheable(cacheNames = "systemId2LinkId")
    public String queryLinkIdFromSystemId(String systemId) {
        if (Strings.isNullOrEmpty(systemId)) {
            return null;
        }
        Map<String, Object> res = systemId2LinkIdTable.getRow("systemid", systemId);
        return (String) res.get("linkid");
    }

    @Cacheable(cacheNames = "linkId2Categories")
    public Map<String, Object> queryProductSupply(String linkId) {
        return linkId2CategoryTable.getRow("linkid", linkId);
    }

    @Cacheable(cacheNames = "storeCSingleProduct")
    public Map<String, Object> queryStoreCSingleProduct(String storeCode, String linkid) {
        Map<String, Object> cityRecallKeyMap = new HashMap<>(2);
        cityRecallKeyMap.put("storecode", storeCode);
        cityRecallKeyMap.put("itemlinkid", linkid);
        return storeCSingleProductTable.getRow("combined_key", cityRecallKeyMap);
    }


    private List<SubItem> makeItemLinkIds(Map<String, Object> csingleMenu, String type) {
        List<SubItem> itemLinkIds = new ArrayList<>();
        log.debug("transactionId[{}], CSingleMenu is: {}", transactionIdTreadLocal.get(), csingleMenu);
        if (csingleMenu != null && !csingleMenu.isEmpty()) {
            String[] prices = ((String) csingleMenu.get("prices")).split(",");
            String[] linkids = ((String) csingleMenu.get("linkids")).split(",");
            String[] rounds = ((String) csingleMenu.get("rounds")).split(",");
            String[] itemcounts = ((String) csingleMenu.get("itemcounts")).split(",");

            if (validSize(prices.length, rounds.length, linkids.length, itemcounts.length)) {
                for (int i = 0; i < linkids.length; i++) {

                    String linkid = linkids[i];
                    String round = rounds[i];
                    String price = prices[i];
                    String itemcount = itemcounts[i];

                    SubItem subItem = new SubItem();
                    subItem.setLinkId(linkid);
                    // 子项的type继承自优惠的type
                    subItem.setType(type);
                    subItem.setRound(round);
                    subItem.setNum(itemcount);
                    subItem.setPrice(price);
                    itemLinkIds.add(subItem);
                }
            } else {
                log.warn("transactionId[{}], CSingleMenu property size not equal, CSingleMenu is [{}]",
                        transactionIdTreadLocal.get(), csingleMenu);
            }
        }
        return itemLinkIds;
    }

    private boolean validSize(int... lengths) {
        assert lengths.length >= 2;
        boolean equal = true;
        int len0 = lengths[0];
        for (int i = 1; i < lengths.length; i++) {
            equal &= (len0 == lengths[i]);
        }
        return equal;
    }
}
