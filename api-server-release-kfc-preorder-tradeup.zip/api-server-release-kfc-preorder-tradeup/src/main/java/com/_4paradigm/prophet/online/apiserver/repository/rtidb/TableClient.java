package com._4paradigm.prophet.online.apiserver.repository.rtidb;

import com._4paradigm.rtidb.client.TableSyncClient;
import com._4paradigm.rtidb.client.ha.RTIDBClientConfig;
import com._4paradigm.rtidb.client.ha.impl.NameServerClientImpl;
import com._4paradigm.rtidb.client.ha.impl.RTIDBClusterClient;
import com._4paradigm.rtidb.client.impl.TableSyncClientImpl;
import com._4paradigm.rtidb.client.schema.ColumnDesc;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

@Slf4j
@Configuration
public class TableClient {

    @Value("${RtiDB.zookeeper.endpoints}")
    private String zkEndpoins;
    @Value("${RtiDB.zookeeper.rootPath}")
    private String zkRootPath;
    @Value("${RtiDB.zookeeper.leaderPath}")
    private String leaderPath;

    private static ReentrantLock initLock = new ReentrantLock();
    private static NameServerClientImpl nsc;
    private static RTIDBClientConfig config;
    private static RTIDBClusterClient clusterClient;
    private static TableSyncClient tableSyncClient;

    @PostConstruct
    public void initClient() {
        initLock.lock();
        try {
            if (nsc == null) {
                nsc = new NameServerClientImpl(zkEndpoins, zkRootPath);
            }
            if (config == null) {
                config = new RTIDBClientConfig();
                config.setZkEndpoints(zkEndpoins);
                config.setZkRootPath(zkRootPath);
                config.setMaxRetryCnt(1);
                config.setIoThreadNum(1);
                config.setRemoveDuplicateByTime(false);
            }
            if (clusterClient == null) {
                clusterClient = new RTIDBClusterClient(config);
                clusterClient.init();
            }
            if (tableSyncClient == null) {
                tableSyncClient = new TableSyncClientImpl(clusterClient);
            }
        } catch (Exception e) {
            if (log.isDebugEnabled()) {
                e.printStackTrace();
            }
            // TODO: Raise Exception to panic
        }
        initLock.unlock();
    }

    public List<ColumnDesc> getTableSchema(String name) {
        return clusterClient.getHandler(name).getSchema();
    }

    public TableSyncClient getTableSyncClient() {
        return tableSyncClient;
    }

    public String getZkEndpoins() {
        return this.zkEndpoins;
    }
}
