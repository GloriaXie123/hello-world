package com._4paradigm.prophet.online.apiserver.yumc.tradeup.rerank;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.policy.Policy;
import java.util.List;
import java.util.Map;

/**
 * @author akis on 2019-07-11
 */
public abstract class AbstractTradeUpReRankingPolicy implements Policy {

    @Override
    public Context process(Context context) {
        List<Map<String, Object>> tableWithScore = context.getItems();
        tableWithScore.sort((item1, item2) -> -Double.compare(calculate(item1), calculate(item2)));
        return context;
    }

    /**
     * 自定义计算方法
     * @param item
     * @return
     */
    abstract public double calculate(Map<String, Object> item);
}
