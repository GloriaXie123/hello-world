package com._4paradigm.prophet.online.apiserver.util;

import org.springframework.core.io.ClassPathResource;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

public class FileUtils {
    public static String readFileFromResource(String path) throws IOException {
        ClassPathResource resource = new ClassPathResource(path);
        BufferedReader reader = new BufferedReader(new InputStreamReader(resource.getInputStream()));
        String content = reader.lines().collect(Collectors.joining("\n"));
        reader.close();
        return content;
    }
}
