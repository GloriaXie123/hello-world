package com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp;

import lombok.Data;

@Data
public class PredictRespContext {
    private String uniqueId;
    private String recallConfigVersion;
    private String experimentId;
}
