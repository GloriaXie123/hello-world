package com._4paradigm.prophet.online.apiserver.policy.impl;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.policy.Policy;

public class FakePostPolicy implements Policy {
    @Override
    public Context process(Context context) {
        System.out.println(this.getClass().getName() + " called");
        System.out.println("context: " + context);
        return null;
    }
}
