package com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class PredictRespData {
    private PredictRespContext context;
    private List<Map<String, Object>> list;
}
