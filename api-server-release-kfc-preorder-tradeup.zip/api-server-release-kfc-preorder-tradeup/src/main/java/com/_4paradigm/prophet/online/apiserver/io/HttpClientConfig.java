package com._4paradigm.prophet.online.apiserver.io;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class HttpClientConfig {

    // autowired for http client metrics
    @Autowired
    RestTemplateBuilder restTemplateBuilder;
    @Value("${predictor.client.connection.max:100}")
    private int maxConnTotal;
    @Value("${predictor.client.connect.timeout:5000}")
    private int connectTimeout;
    @Value("${predictor.client.socket.timeout:10000}")
    private int socketTimeout;
    @Value("${predictor.client.connection.timeout:1000}")
    private int connectionRequestTimeout;

    @Bean
    public RestTemplate restTemplate() {
        RequestConfig requestConfig = RequestConfig.custom()
                .setSocketTimeout(socketTimeout)
                .setConnectionRequestTimeout(connectionRequestTimeout)
                .setConnectTimeout(connectTimeout)
                .build();

        CloseableHttpClient httpClient = HttpClientBuilder
                .create()
                .setDefaultRequestConfig(requestConfig)
                .setMaxConnTotal(maxConnTotal)
                .setMaxConnPerRoute(maxConnTotal)
                .build();
        ClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(
                httpClient);

        return restTemplateBuilder.requestFactory(() -> clientHttpRequestFactory)
                .build();
    }
}
