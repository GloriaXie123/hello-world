package com._4paradigm.prophet.online.apiserver.model.dto.api_server.req;

import lombok.Data;

import java.util.List;

@Data
public class PredictReqShoppingCart {
    private String linkId;
    private String sizeId;
    private String baseId;
    private String num;
    private Float price;
    private Float realPrice;
    private Integer type;
    private String systemId;
    private List<PredictReqItem> itemLinkIds;
}
