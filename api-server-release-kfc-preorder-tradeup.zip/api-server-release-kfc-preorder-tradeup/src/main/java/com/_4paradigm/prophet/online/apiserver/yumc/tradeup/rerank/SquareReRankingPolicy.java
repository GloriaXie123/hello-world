package com._4paradigm.prophet.online.apiserver.yumc.tradeup.rerank;

import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * @author akis on 2019-07-11
 */
@Lazy
@Component("SquareReRankingPolicy")
public class SquareReRankingPolicy extends AbstractTradeUpReRankingPolicy {

    @Value("${predictor.score_column_name:predictScore}")
    private String predictScore;

    @Value("${tradeup.item.price:price}")
    private String sellPrice;

    @Override
    public double calculate(Map<String, Object> item) {
        double score = (Double) item.get(predictScore);
        double price = 1;
        if (item.get(sellPrice) != null) {
            price = (Double) item.get(sellPrice);
        }
        return Math.pow(price, 2) * score;
    }
}
