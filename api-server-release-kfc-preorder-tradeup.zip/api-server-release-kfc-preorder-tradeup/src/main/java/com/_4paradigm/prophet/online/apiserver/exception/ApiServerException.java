package com._4paradigm.prophet.online.apiserver.exception;

import lombok.Data;

@Data
public class ApiServerException extends RuntimeException {
    private RetCode retCode;

    public ApiServerException(RetCode retCode, String message, Throwable t) {
        super(message, t);
        this.retCode = retCode;
    }

    public ApiServerException(RetCode retCode, String message) {
        super(message);
        this.retCode = retCode;
    }
}
