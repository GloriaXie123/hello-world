//package com._4paradigm.prophet.online.apiserver.repository.impl;
//
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.stereotype.Component;
//
//@Slf4j
//@Component
//public class ConfigurationOutputCommandLineRunner implements CommandLineRunner {
//
//    @Value("${tradeup.responseItems.reverse}")
//    private String responseItemsReverse;
//
//    @Value("${tradeup.returnItems.limit}")
//    private String returnItemsLimit;
//
//    @Value("${tradeup.recall.removeFilter}")
//    private String recallRemoveFilter;
//
//    @Value("${tradeup.recall.excludedSellCodes}")
//    private String recallExcludedSellCodes;
//
//    @Value("${tradeup.recall.excludeCertainItem}")
//    private String recallExcludeCertainItem;
//
//    @Value("${tradeup.rerank.priority}")
//    private String rerankPriority;
//
//    @Value("${fallback.promotionCodes}")
//    private String promotionCodes;
//
//    @Override
//    public void run(String... args) throws Exception {
//        log.info("Load Configuration. tradeup.responseItems.reverse={} tradeup.returnItems.limit={} tradeup.recall.removeFilter={} tradeup.recall.excludedSellCodes={} tradeup.recall.excludeCertainItem={} tradeup.rerank.priority={} fallback.promotionCodes={}",
//                responseItemsReverse,
//                returnItemsLimit,
//                recallRemoveFilter,
//                recallExcludedSellCodes,
//                recallExcludeCertainItem,
//                rerankPriority,
//                promotionCodes);
//    }
//}
