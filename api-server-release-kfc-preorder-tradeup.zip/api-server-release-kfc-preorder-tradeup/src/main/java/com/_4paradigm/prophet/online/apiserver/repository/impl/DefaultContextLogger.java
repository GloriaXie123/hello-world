package com._4paradigm.prophet.online.apiserver.repository.impl;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.model.context.ContextLogger;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

@Slf4j
@Repository("DefaultContextLogger")
public class DefaultContextLogger implements ContextLogger {
    private static final org.slf4j.Logger recordLogger = org.slf4j.LoggerFactory.getLogger("record-log");

    @Override
    public void write(Context context) {
        recordLogger.info(JSON.toJSONString(context));
    }
}
