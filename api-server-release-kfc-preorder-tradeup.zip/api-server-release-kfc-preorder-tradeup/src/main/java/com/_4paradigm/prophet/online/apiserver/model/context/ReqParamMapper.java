package com._4paradigm.prophet.online.apiserver.model.context;

        import com._4paradigm.prophet.online.apiserver.model.dto.api_server.req.predictReqDTO;

        import java.util.Map;

public interface ReqParamMapper {
    Map<String, Object> process(predictReqDTO req, Context context);
}
