package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import com.github.benmanes.caffeine.cache.Caffeine;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * @author akis on 2019-08-21
 */
@Configuration
@EnableCaching
@EnableScheduling
@Slf4j
public class CacheConfig {

    @Bean
    public CacheManager cacheManager() {
        CaffeineCacheManager cacheManager = new CaffeineCacheManager();
        cacheManager.setCaffeine(Caffeine.newBuilder());
        return cacheManager;
    }

    /**
     * 每天早上10点清空缓存
     */
    @Scheduled(cron = "${cron.expression: 0 0 10 * * ?}")
    @CacheEvict(cacheNames = {"storeProfiles", "itemProfiles", "systemId2LinkId",
            "linkId2Categories", "cityRecall", "sellCode2PromotionCode"}, allEntries = true)
    public void clearCache() {
        log.info("all caches cleared");
    }
}
