package com._4paradigm.prophet.online.apiserver.config;

import com._4paradigm.prophet.online.apiserver.model.context.RespParamMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ResponseDTOMapperConfig {
    @Autowired
    private ApplicationContext context;

    @Bean("responseDTOMapperAlias")
    public RespParamMapper respParamMapperAlias(@Value("${context.respParamMapper.ImplType}") String qualifier) {
        return (RespParamMapper) context.getBean(qualifier);
    }
}
