package com._4paradigm.prophet.online.apiserver.model.dto.api_server.req;

import lombok.Data;

import java.util.List;

@Data
public class PredictReqRawFeature {
    private String userCode;
    private Long systemTime;
    private Long promiseTime;
    private String cityName;
    private String cityCode;
    private String storeCode;
    private String brand;
    private String transactionId;
    private String marketCode;
    private String channel;
    private String extraParam;
    private List<PredictReqShoppingCart> shoppingCarts;
}
