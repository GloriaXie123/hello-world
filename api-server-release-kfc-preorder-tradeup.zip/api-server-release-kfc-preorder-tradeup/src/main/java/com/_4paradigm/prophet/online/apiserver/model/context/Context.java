package com._4paradigm.prophet.online.apiserver.model.context;

import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespDTO;
import lombok.Data;
import org.apache.commons.codec.binary.Base64;

import java.util.List;
import java.util.Map;

@Data
public class Context {
    private Boolean isDebug;
    private String uniqueId;
    private String experimentId;
    private Map<String, Object> reqParam;
    private Map<String, Object> user;
    private Map<String, Object> common;
    private RecallConfig recallConfig;
    private List<Map<String, Object>> items;
    private Map<String, Object> extraData;
    private PredictRespDTO response;

    public String genUniqueId() {
        String timestamp = String.valueOf(System.currentTimeMillis());
        String address = System.getenv("MY_POD_IP");
        String thread = String.valueOf(Thread.currentThread().getId());
        return Base64.encodeBase64String(String.join(",", timestamp, address, thread).getBytes());
    }

}
