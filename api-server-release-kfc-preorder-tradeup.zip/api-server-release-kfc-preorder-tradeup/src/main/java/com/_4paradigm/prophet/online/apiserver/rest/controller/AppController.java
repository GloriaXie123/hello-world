package com._4paradigm.prophet.online.apiserver.rest.controller;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.model.context.RespParamMapper;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.req.predictReqDTO;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespDTO;
import com._4paradigm.prophet.online.apiserver.service.BlackListService;
import com._4paradigm.prophet.online.apiserver.service.ForcePushService;
import com._4paradigm.prophet.online.apiserver.service.PredictionService;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/api/v1")
@Slf4j
public class AppController {

    @Autowired
    private PredictionService predictionService;

    @Autowired
    private BlackListService blacklistService;

    @Autowired
    private ForcePushService forcePushService;

    @Value("${tradeup.request.timeout}")
    private int requestTimeout;

    @Autowired
    @Qualifier("fallbackRespParamMapper")
    private RespParamMapper respParamMapper;

    @Value("${pt.forcePush.enabled}")
    private Boolean forcePushEnabled;

    @Value("${pt.userBlack.enabled}")
    private Boolean userBlackEnabled;

    @PostMapping("/prediction")
    public ResponseEntity<PredictRespDTO> createPrediction(@RequestBody predictReqDTO reqDTO) {

        long start = System.currentTimeMillis();
        String transactionId = (String) reqDTO.getRawFeatures().get("transactionId");

        // 1. 黑名单用户强推
        String userCode = (String) reqDTO.getRawFeatures().get("userCode");
        if (userBlackEnabled && StringUtils.isNotEmpty(userCode)) {
            String experimentId = reqDTO.getContext().getExperimentId();
            PredictRespDTO respDTO = blacklistService.queryBlackList(userCode, experimentId);
            if (respDTO != null) {
                return new ResponseEntity<>(respDTO, HttpStatus.OK);
            }
        }

        // 2. 普通强推
        if (forcePushEnabled) {
            return new ResponseEntity<>(forcePushService.forcePush(reqDTO), HttpStatus.OK);
        }


        try {
            Future<PredictRespDTO> futureResult = predictionService.predictAsync(reqDTO);
            PredictRespDTO resp = futureResult.get(requestTimeout, TimeUnit.MILLISECONDS);

            long end = System.currentTimeMillis();
            if (end - start > 85) {
                log.warn("transactionId[{}], request time is  [{}]", transactionId, end - start);
            }

            if (resp.getRetCode() == 200) {
                return new ResponseEntity<>(resp, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            log.warn("exception occured during predication:exception={} message={}", e.getCause(), e.getMessage());
            Context context = new Context();
            context.setExperimentId(reqDTO.getContext().getExperimentId());
            PredictRespDTO fallbackResp = respParamMapper.process(context);
            log.warn("api server timeout exception and will return the fallback response. tid={} usercode={} experimentId={} uniqueId={} itemInfo={}",
                    reqDTO.getRawFeatures().get("transactionId"),
                    reqDTO.getRawFeatures().get("userCode"),
                    fallbackResp.getData().getContext().getExperimentId(),
                    fallbackResp.getData().getContext().getUniqueId(),
                    context.getExtraData().get("itemLog").toString());
            return new ResponseEntity<>(fallbackResp, HttpStatus.OK);
        }


    }
}
