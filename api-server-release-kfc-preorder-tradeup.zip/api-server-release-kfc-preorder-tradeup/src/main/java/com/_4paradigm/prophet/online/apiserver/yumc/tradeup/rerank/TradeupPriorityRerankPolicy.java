package com._4paradigm.prophet.online.apiserver.yumc.tradeup.rerank;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.policy.Policy;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * @author akis on 2019-07-24
 */
@Lazy
@Component("TradeupPriorityRerankPolicy")
public class TradeupPriorityRerankPolicy implements Policy {

    @Setter
    @Value("#{${tradeup.rerank.priority: {default: 1}}}")
    private Map<String, Double> priorityMap;

    @Value("${predictor.score_column_name}")
    private String predictScore;

    @Override
    public Context process(Context context) {
        context.getExtraData().put("rerankRule", priorityMap);
        List<Map<String, Object>> tableWithScore = context.getItems();

        tableWithScore.sort((item1, item2) ->
                -Double.compare(calculate(item1), calculate(item2)));
        return context;
    }


    public double calculate(Map<String, Object> item) {
        double score = (Double) item.get(predictScore);
        String sellCode = (String) item.get("sell_code");
        double defaultPriority = priorityMap.getOrDefault("default", 1.0);
        double priority = priorityMap.getOrDefault(sellCode, defaultPriority);

        return priority * score;
    }
}
