package com._4paradigm.prophet.online.apiserver.yumc.tradeup.rerank;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.policy.FiltrationSoldOutPolicy;
import com._4paradigm.prophet.online.apiserver.repository.rtidb.RtiDBTable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <功能详细描述>
 * 下架物料打分前去除
 * @author kai.xu
 * @date 2020年07月12日
 */
@Lazy
@Slf4j
@Component("TradeupFiltrationSoldOutPolicy")
public class TradeupFiltrationSoldOutPolicy implements FiltrationSoldOutPolicy {

    @Autowired
    private RtiDBTable rtiDBTable;

    //每日物料表 p_rtidb_tradeup_product_list_daily
    @Value("${pr.filtrationSoldOut.tableName}")
    private String filtrationSoldOutTableName;
    private RtiDBTable filtrationSoldOutPriceTable;

    @PostConstruct
    private void postConstruct() {
        filtrationSoldOutPriceTable = rtiDBTable.getTable(filtrationSoldOutTableName);
    }

    //查询每日物料表
    public Map<String, Object> get() {
        return filtrationSoldOutPriceTable.getRow("brand","KFC_PRE");
    }

    @Override
    public Context process(Context context) {
        Map<String, Object> map = get();
        if (map.isEmpty()) {
            log.warn("getLinkIdCouponcodePrice is null!");
            return context;
        }
        String sellCode = ","+map.get("sell_code")+",";
        log.debug("sellCode:"+sellCode);

        List<Map<String, Object>> items = context.getItems();

        log.debug("before items:"+items.toString());
        List<Map<String, Object>> newItems = new ArrayList<>();

        for (Map<String, Object> i : items) {
            if (sellCode.contains(","+(i.get("sell_code"))+",")){
                newItems.add(i);
            }
        }
        log.debug("after items:"+newItems.toString());

        context.setItems(newItems);
        return context;
    }

}
