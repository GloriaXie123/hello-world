package com._4paradigm.prophet.online.apiserver.model.dto.predictor_client.resp;

import lombok.Data;

import java.util.List;

@Data
public class PredictCliRespDTO {
    String requestId;
    String status;
    List<PredictCliRespInstance> instances;
}
