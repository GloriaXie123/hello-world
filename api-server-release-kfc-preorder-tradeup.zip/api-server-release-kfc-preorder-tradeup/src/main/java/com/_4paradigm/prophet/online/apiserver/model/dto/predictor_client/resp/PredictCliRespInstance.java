package com._4paradigm.prophet.online.apiserver.model.dto.predictor_client.resp;

import lombok.Data;

import java.util.List;

@Data
public class PredictCliRespInstance {
    String id;
    List<Double> scores;
}
