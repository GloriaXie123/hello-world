package com._4paradigm.prophet.online.apiserver.model.dto.api_server.req;

import lombok.Data;

import java.util.Map;

@Data
public class predictReqDTO {
    private PredictReqContext context;
    private Map<String, Object> rawFeatures;
}
