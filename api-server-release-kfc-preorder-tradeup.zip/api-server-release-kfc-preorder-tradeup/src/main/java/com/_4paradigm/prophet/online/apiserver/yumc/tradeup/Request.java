package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import java.util.List;
import lombok.Data;

/**
 * @author akis on 2019-06-28
 */
@Data
public class Request {
    private String userCode;
    private String systemTime;
    private String promiseTime;
    private String cityName;
    private String cityCode;
    private String storeCode;
    private String brand;
    private String transactionId;
    private String marketCode;
    private String channel;
    private String extraParam;
    private List<ShoppingItem> shoppingCart;


    @Data
    public static class ShoppingItem {
        private String linkId;
        private String sizeId;
        private String baseId;
        private String type;
        private String num;
        private String price;
        private String realPrice;
        private String systemId;
        private List<SubItem> itemLinkIds;
    }

    @Data
    public static class SubItem {
        private String linkId;
        private String sizeId;
        private String baseId;
        private String num;
        private String price;
        private String addPrice;
        private String type;
        private String round;
        private String systemId;
    }
}
