package com._4paradigm.prophet.online.apiserver.yumc.tradeup.rerank;

import com._4paradigm.prophet.online.apiserver.model.dto.api_server.req.predictReqDTO;
import com._4paradigm.prophet.online.apiserver.policy.ConversionCostPolicy;
import com._4paradigm.prophet.online.apiserver.repository.rtidb.RtiDBTable;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <功能详细描述>
 * 券购买转换成实际购买价
 * @author kai.xu
 * @date 2020年07月12日
 * 多阶段开发 一阶段：配置查询 二阶段：数据库查询，数据更精准
 */
@Lazy
@Slf4j
@Component("TradeupConversionCostPolicy")
public class TradeupConversionCostPolicy implements ConversionCostPolicy {

    @Autowired
    private RtiDBTable rtiDBTable;

    @Value("${rtidb.combinedKey}") 
    private String combinedKey;

   /* //物料优惠价格表 p_rtidb_linkId_couponcode_price linkId、couponcode、price
    @Value("${pr.linkIdCouponcodePrice.tableName}")
    private String linkIdCouponcodePriceTableName;
    private RtiDBTable linkIdCouponcodePriceTable;

    @PostConstruct
    private void postConstruct() {
        linkIdCouponcodePriceTable = rtiDBTable.getTable(linkIdCouponcodePriceTableName);
    }*/

    //转化费率
    @Value("${conversion.cost.rate}")
    private String conversionCostRate;

   /* //查询物料优惠价格表
    public Map<String, Object> getLinkIdCouponcodePrice(String linkId) {
        Map<String, Object> map = Maps.newHashMapWithExpectedSize(1);
        map.put("linkId", linkId);
        return linkIdCouponcodePriceTable.getRow(combinedKey,map);
    }*/

    //阶段1 (阶段二开发完成就废除)
    @Override
    public predictReqDTO process(predictReqDTO req) {

        if(Double.parseDouble(conversionCostRate)<0 || Double.parseDouble(conversionCostRate)>1){
            log.error("conversionCostRate:"+conversionCostRate+" error,break TradeupConversionCostPolicy!");
            return req;
        }

        Map<String, Object> rawFeaturesMap = req.getRawFeatures();
        List<Map<String,Object>> shoppingCartList = (List<Map<String, Object>>) rawFeaturesMap.get("shoppingCart");
        List<Map<String,Object>> list = new ArrayList<>();

        log.debug("before shoppingCart:"+shoppingCartList.toString());
        for (Map<String, Object> i : shoppingCartList) {
            if(null!=i.get("type")&&"4".equals(i.get("type").toString())){
                i.put("realPrice",Math.round(Double.parseDouble(i.get("price").toString())*Double.parseDouble(conversionCostRate)));
                list.add(i);
            }else{
                list.add(i);
            }
        }
        log.debug("after shoppingCart:"+list.toString());

        rawFeaturesMap.put("shoppingCart",list);
        req.setRawFeatures(rawFeaturesMap);
        return req;
    }

    //阶段二
   /* @Override
    public predictReqDTO process(predictReqDTO req) {

        if(Double.parseDouble(conversionCostRate)<0 || Double.parseDouble(conversionCostRate)>1){
            log.warn("conversionCostRate:"+conversionCostRate+" error,break TradeupConversionCostPolicy!");
            return req;
        }

        Map<String, Object> rawFeaturesMap = req.getRawFeatures();
        List<Map<String,Object>> shoppingCartList = (List<Map<String, Object>>) rawFeaturesMap.get("shoppingCart");
        List<Map<String,Object>> list = new ArrayList<>();

        log.debug("before shoppingCart:"+shoppingCartList.toString());
        for (Map<String, Object> i : shoppingCartList) {
            if("4".equals(i.get("type").toString())){
                Map<String, Object> map = getLinkIdCouponcodePrice(i.get("linkId").toString());
                log.debug("getLinkIdCouponcodePrice map："+map.toString());
                if (map.isEmpty()) {
                    i.put("realPrice",Math.round(Double.parseDouble(i.get("price").toString())*Double.parseDouble(conversionCostRate)));
                }else{
                    i.put("realPrice",map.get("price").toString());
                }
                list.add(i);
            }else{
                list.add(i);
            }
        }
        log.debug("after shoppingCart:"+list.toString());

        rawFeaturesMap.put("shoppingCart",list);
        req.setRawFeatures(rawFeaturesMap);

        return req;
    }*/

}
