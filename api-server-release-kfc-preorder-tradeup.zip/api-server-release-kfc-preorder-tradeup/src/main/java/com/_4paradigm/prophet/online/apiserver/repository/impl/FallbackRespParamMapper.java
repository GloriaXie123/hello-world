package com._4paradigm.prophet.online.apiserver.repository.impl;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.model.context.RespParamMapper;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespContext;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespDTO;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespData;
import com._4paradigm.prophet.online.apiserver.repository.rtidb.RtiDBTable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Repository("fallbackRespParamMapper")
public class FallbackRespParamMapper implements RespParamMapper {

    @Value("${fallback.promotion.codes:#{T(java.util.Collections).emptyList()}}")
    private String[] fallbackPromotionCodes;

    @Value("${tradeup.returnItems.limit}")
    private int itemLimit;

    @Autowired
    private RtiDBTable rtiDBTable;

    //每日物料表 p_rtidb_tradeup_product_list_daily
    @Value("${pr.filtrationSoldOut.tableName}")
    private String filtrationSoldOutTableName;
    private RtiDBTable filtrationSoldOutPriceTable;

    @PostConstruct
    private void initRtidbTables() {
        filtrationSoldOutPriceTable = rtiDBTable.getTable(filtrationSoldOutTableName);
    }

    //查询每日物料表
    public Map<String, Object> get() {
        return filtrationSoldOutPriceTable.getRow("brand","KFC_PRE");
    }

    @Override
    public PredictRespDTO process(Context context) {
        PredictRespData respData = new PredictRespData();
        respData.setList(this.getFallbackItemList(context));

        PredictRespContext respCtx = new PredictRespContext();
        respCtx.setRecallConfigVersion("Not Implemented");
        respCtx.setExperimentId(context.getExperimentId());
        respCtx.setUniqueId(context.genUniqueId());
        respData.setContext(respCtx);

        PredictRespDTO respDTO = new PredictRespDTO();
        respDTO.setRetCode(200);
        respDTO.setMessage("success");
        respDTO.setData(respData);

        return respDTO;
    }

    private List<Map<String, Object>> getFallbackItemList(Context context) {

        List<Map<String, Object>> ret = new ArrayList<>();
        StringBuilder stringBuilder = new StringBuilder();

        String[] s = getForcePushItems(fallbackPromotionCodes);

        log.debug("fallbackPromotionCodes:"+s.toString());

        List filteredList = Arrays.stream(s).
                filter(item -> !item.trim().isEmpty()).collect(Collectors.toList());
        if(filteredList.isEmpty()) {
            return ret;
        }
        if( itemLimit >= filteredList.size() ) {
            itemLimit = filteredList.size();
        }

        stringBuilder.append("[return item list:");
        for (int idx = 0; idx < itemLimit; idx++) {
            Map<String, Object> item = new HashMap<>();
            item.put("rank",(String.valueOf(idx+1)));
            item.put("promotionCode", filteredList.get(idx));
            stringBuilder.append("rank=").append(idx+1).
                    append(" promotionCode=").append(filteredList.get(idx)).append(" ");
            ret.add(item);
        }
        stringBuilder.append("]");

        Map<String,Object> extraData = new HashMap();
        extraData.put("itemLog", stringBuilder);
        context.setExtraData(extraData);


        return ret;
    }

    private String[] getForcePushItems(String[] fallbackPromotionCodes) {
        Map<String, Object> map = get();
        if (map.isEmpty()) {
            return fallbackPromotionCodes;
        }

        List<String> list = new ArrayList<>();
        String promotioncode = ","+map.get("promotioncode")+",";

        for (String i : fallbackPromotionCodes) {
            if (promotioncode.contains(","+i+",")){
                list.add(i);
            }
        }
        int size=list.size();
        return  (String[])list.toArray(new String[size]);
    }
}
