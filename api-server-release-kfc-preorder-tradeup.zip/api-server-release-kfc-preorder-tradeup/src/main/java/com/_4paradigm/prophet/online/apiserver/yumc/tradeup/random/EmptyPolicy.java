package com._4paradigm.prophet.online.apiserver.yumc.tradeup.random;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.policy.Policy;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * @author akis on 2019-07-24
 */
@Lazy
@Component("EmptyPolicy")
public class EmptyPolicy implements Policy {

    @Override
    public Context process(Context context) {
        return null;
    }
}
