package com._4paradigm.prophet.online.apiserver.model.dto.predictor_client.req;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class PredictCliReqDTO {
    private String accessToken;
    private String requestId;
    private Integer resultLimit;
    private Map<String, Object> commonFeatures;
    private List<Map<String, Object>> rawInstances;
    private boolean isDebug;
    private boolean warmupRequest;
}
