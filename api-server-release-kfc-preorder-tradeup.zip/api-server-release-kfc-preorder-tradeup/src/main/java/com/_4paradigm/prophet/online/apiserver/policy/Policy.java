package com._4paradigm.prophet.online.apiserver.policy;

import com._4paradigm.prophet.online.apiserver.model.context.Context;

public interface Policy {
    Context process(Context context);
}
