package com._4paradigm.prophet.online.apiserver.repository.impl;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.model.context.RespParamMapper;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespContext;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespDTO;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespData;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespItem;
import com._4paradigm.prophet.online.apiserver.util.ZipUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Lazy
@Repository("DefaultRespParamMapper")
public class DefaultRespParamMapper implements RespParamMapper {

    @Value("${itemData.primaryKey:itemId}")
    private String PRED_ID;

    @Override
    public PredictRespDTO process(Context context) {
        PredictRespContext respCtx = new PredictRespContext();
        respCtx.setRecallConfigVersion("Not Implemented");
        respCtx.setExperimentId(context.getExperimentId());
        respCtx.setUniqueId(context.getUniqueId());

        PredictRespData ret = new PredictRespData();
        ret.setContext(respCtx);

        List<Map<String, Object>> itemList = new ArrayList<>();
        int bound = context.getItems().size();
        for (int idx = 0; idx < bound; idx++) {
            Map<String, Object> item = new HashMap<>();
            item.put("itemId", context.getItems().get(idx).get(PRED_ID).toString());
            item.put("randk", Integer.toString(idx+1));
            itemList.add(item);
        }

        PredictRespDTO respDTO = new PredictRespDTO();
        respDTO.setRetCode(200);
        respDTO.setMessage("Hello World");

        ret.setList(itemList);
        respDTO.setData(ret);
        return respDTO;
    }
}
