package com._4paradigm.prophet.online.apiserver.yumc.tradeup;

import com._4paradigm.prophet.online.apiserver.model.context.Context;
import com._4paradigm.prophet.online.apiserver.repository.ItemRepository;
import com._4paradigm.prophet.online.apiserver.repository.rtidb.RtiDBTable;
import com.alibaba.fastjson.JSON;
import com.google.common.base.Strings;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.time.LocalDateTime;
import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import static com._4paradigm.prophet.online.apiserver.yumc.tradeup.Constants.*;

/**
 * @author akis on 2019-06-28
 */
@Lazy
@Repository("TradeUpItem")
@Slf4j
public class TradeUpItemRepository implements ItemRepository {

    @Autowired
    private RtiDBTable rtiDBTable;

    @Value("${rtidb.combinedKey}")
    private String combinedKey;

    @Value("${pt.onlineCityRecall.enabled}")
    private boolean onlineCityRecallEnabled;
    @Value("${pt.onlineCityRecall.availableLatencyMinutes}")
    private int onlineRecallAvailableLatencyMinutes;
    @Value("${pt.onlineCityRecall.tableName}")
    private String onlineCityRecallTableName;
    private RtiDBTable onlineCityRecallTable;

    @Value("${pt.userRecall.tableName}")
    private String userRecallTableName;
    private RtiDBTable userRecallTable;
    @Value("${pt.cityRecall.tableName}")
    private String cityRecallTableName;
    private RtiDBTable cityRecallTable;

    @Value("${pt.filter.subclass.enabled}")
    private boolean filterSubclassEnabled;
    @Value("${pt.filter.SellCodes.enabled}")
    private boolean filterSellCodeEnabled;
    @Value("${pt.filter.SellCodes}")
    private Set<String> filterSellCodes;

    @Value("${filter.weekday.enabled}")
    private boolean filterWeekdayEnabled;
    @Value("${filter.weekday.items}")
    private String filterWeekdayItems;

    @Value("${filter.daypart.enabled}")
    private boolean filterDayPartEnabled;
    @Value("${filter.daypart.items}")
    private String filterDayPartItems;



    /**
     * default is empty map, example: {"icecream": "850456|234567"}
     */
    @Value("#{${tradeup.recall.excludeCertainItem: {:}}}")
    private Map<String, String> excludeCertainItemMap;


    private ThreadLocal<String> transactionIdTreadLocal = ThreadLocal.withInitial(() -> "empty");

    @PostConstruct
    public void init() {
        userRecallTable = rtiDBTable.getTable(userRecallTableName);
        cityRecallTable = rtiDBTable.getTable(cityRecallTableName);
        onlineCityRecallTable = rtiDBTable.getTable(onlineCityRecallTableName);
        excludeCertainItemMap = excludeCertainItemMap.entrySet().stream()
                .collect(Collectors.toMap(entry -> StringUtils.lowerCase(entry.getKey()), Entry::getValue));
    }

    @Override
    public List<Map<String, Object>> getItems(Context context) {
        context.getExtraData().put("excludeCertainItemBySubCategory", excludeCertainItemMap);
        String transactionId = (String) context.getReqParam().get("transactionId");
        transactionIdTreadLocal.set(transactionId);

        String userCode = (String) context.getReqParam().get("userCode");

        // 用户召回
        Map<String, Object> userRecallMap = queryUserRecall(userCode);
        context.getExtraData().put("userRecall", userRecallMap);

        // 店铺召回
        Map<String, Object> cityRecallMap = getCityRecall(context);
        context.getExtraData().put("cityRecall", cityRecallMap);

        // 召回拼接
        List<Map<String, Object>> items = mergeItems(userRecallMap, cityRecallMap);
        context.getExtraData().put("mergeItems", Utils.copyAsObject(items));
        log.debug("transactionId[{}], recall items [{}]", transactionId, items);

        // 召回过滤
        if (!items.isEmpty()) {
            Set<String> shoppingCartSubclasses = (Set<String>) context.getExtraData().get(SHOPPING_CART_SUBCLASSES);
            Set<String> shoppingCartSubcategories = (Set<String>) context.getExtraData().get(SHOPPING_CART_SUBCATEGORIES);
            List<Map<String, Object>> afterFilteredItems = filterItems(context, items, shoppingCartSubclasses, shoppingCartSubcategories);
            context.getExtraData().put("filteredItems", Utils.copyAsObject(afterFilteredItems));
            log.debug("transactionId[{}], after filtered items [{}]", transactionId, afterFilteredItems);
            if (afterFilteredItems.isEmpty()) {
                log.warn("transactionId[{}], after filtered item is empty", transactionId);
            }
            return afterFilteredItems;
        } else {
            log.warn("transactionId[{}], merge recall items is empty", transactionId);
        }
        return items;
    }

    private Map<String, Object> queryUserRecall(String userCode) {
        if (Strings.isNullOrEmpty(userCode)) {
            userCode = "0";
        }
        return userRecallTable.getRow("user_code", userCode);
    }

    public Map<String, Object> getCityRecall(Context context) {
        Map<String, Object> ret = Maps.newHashMap();

        String storeCode = (String) context.getReqParam().get(STORE_CODE);

        if (onlineCityRecallEnabled) {
            String onlineChannel = (String) context.getReqParam().get("online_channel");
            Map<String, Object> onlineCityRecallKeyMap = Maps.newHashMapWithExpectedSize(2);
            onlineCityRecallKeyMap.put("store_code", storeCode);
            onlineCityRecallKeyMap.put("preorder_channel_name", onlineChannel);
            Map<String, Object> onlineCityRecall = onlineCityRecallTable.getRow(combinedKey, onlineCityRecallKeyMap);

            if (!onlineCityRecall.isEmpty()) {
                DateTime timestamp = (DateTime) onlineCityRecall.get("insert_time");

                long insertTime = timestamp.getMillis();
                long now = System.currentTimeMillis();
                if ((now - insertTime) / 60000 < onlineRecallAvailableLatencyMinutes) {
                    ret = onlineCityRecall;
                } else {
                    log.warn("online city recall latency too long, latest insert time is [{}],"
                            + "use offline city recall table", insertTime);
                }
            } else {
                log.warn("online city recall failed, null or empty, use offline city recall table");
            }
        }

        if (!onlineCityRecallEnabled || ret.isEmpty()) {
            String workDayName = (String) context.getReqParam().get("work_day_name");
            String daypartName = (String) context.getReqParam().get("city_recall_daypart_name");
            String channel = (String) context.getReqParam().get(CHANNEL);
            ret = queryCityRecall(storeCode, workDayName, daypartName, channel);
        }
        return ret;
    }

    @Cacheable(cacheNames = "cityRecall")
    public Map<String, Object> queryCityRecall(String storeCode, String workDayName,
                                               String daypartName, String channel) {
        Map<String, Object> cityRecallKeyMap = Maps.newHashMapWithExpectedSize(4);
        cityRecallKeyMap.put("store_code", storeCode);
        cityRecallKeyMap.put("work_day_name", workDayName);
        cityRecallKeyMap.put("daypart_name", daypartName);
        cityRecallKeyMap.put("preorder_channel_name", channel);
        return cityRecallTable.getRow(combinedKey, cityRecallKeyMap);
    }

    private List<Map<String, Object>> mergeItems(Map<String, Object> userRecallMap, Map<String, Object> cityRecallMap) {
        Map<String, Map<String, Object>> items = Maps.newHashMapWithExpectedSize(40);
        log.debug("transactionId[{}], userRecallMap is: {} and cityRecallMap is: {}",
                transactionIdTreadLocal.get(), userRecallMap, cityRecallMap);
        if (userRecallMap != null && !userRecallMap.isEmpty()) {
            String[] userSellCodes = ((String) userRecallMap.get("sell_codes")).split(",");
            String[] vals = ((String) userRecallMap.get("vals")).split(",");
            String[] ranks = ((String) userRecallMap.get("ranks")).split(",");
            String[] subCategories = ((String) userRecallMap.get("sub_categories")).split(",");

            if (validSize(userSellCodes.length, vals.length, ranks.length, subCategories.length)) {
                for (int i = 0; i < userSellCodes.length; i++) {
                    Map<String, Object> item = Maps.newHashMapWithExpectedSize(50);
                    String sellCode = userSellCodes[i];
                    item.put("sell_code", sellCode);
                    item.put("val", Integer.valueOf(vals[i]));
                    item.put("rank", Integer.valueOf(ranks[i]));
                    item.put("subCategory", StringUtils.lowerCase(subCategories[i]));
                    //补充默认数据
                    item.put("city_val", 0.0d);
                    item.put("city_rank", 0);
                    items.put(sellCode, item);
                }
            } else {
                log.warn("transactionId[{}], user recall items property size not equal, userRecallMap is [{}]",
                        transactionIdTreadLocal.get(), userRecallMap);
            }

        }
        if (cityRecallMap != null && !cityRecallMap.isEmpty()) {
            String[] citySellCodes = ((String) cityRecallMap.get("sell_codes")).split(",");
            String[] cityVals = ((String) cityRecallMap.get("city_vals")).split(",");
            String[] cityRanks = ((String) cityRecallMap.get("city_ranks")).split(",");
            String[] subCategories = ((String) cityRecallMap.get("sub_categories")).split(",");

            if (validSize(citySellCodes.length, cityVals.length, cityRanks.length, subCategories.length)) {
                for (int i = 0; i < citySellCodes.length; i++) {
                    String sellCode = citySellCodes[i];
                    String subCategory = StringUtils.lowerCase(subCategories[i]);
                    Map<String, Object> item = items.get(sellCode);
                    if (item != null) {
                        item.put("city_val", Double.valueOf(cityVals[i]));
                        item.put("city_rank", Integer.valueOf(cityRanks[i]));
                    } else {
                        item = Maps.newHashMapWithExpectedSize(50);
                        item.put("sell_code", sellCode);
                        item.put("city_val", Double.valueOf(cityVals[i]));
                        item.put("city_rank", Integer.valueOf(cityRanks[i]));
                        item.put("val", 0);
                        item.put("rank", 0);
                        item.put("subCategory", subCategory);
                        items.put(sellCode, item);
                    }
                }
            } else {
                log.warn("transactionId[{}], city recall items property size not equal, cityRecallMap is [{}]",
                        transactionIdTreadLocal.get(), cityRecallMap);
            }
        }
        return new ArrayList<>(items.values());
    }

    /**
     * 1. 过滤购物车中类别重复的商品
     * 2. 过滤黑名单中的商品
     * 3. 根据指定 subCategory 过滤指定商品
     *
     * @param items                     召回物料
     * @param shoppingCartSubclasses    购物车中用户添加的物料的 subclass
     * @param shoppingCartSubcategories 购物车中用户添加的物料的 subCategory
     * @return
     */
    private List<Map<String, Object>> filterItems(Context context, List<Map<String, Object>> items,
                                                  Set<String> shoppingCartSubclasses, Set<String> shoppingCartSubcategories) {

        String daypart = (String) context.getReqParam().get("daypart_name");

        // 过滤购物车中用户添加的物料的 subclass
        if (filterSubclassEnabled) {
            items = items.stream().filter(item -> notInCart(shoppingCartSubclasses, item)).collect(Collectors.toList());
            log.debug("transactionId[{}], after notInCart, {}", transactionIdTreadLocal.get(), items);
            context.getExtraData().put("itemAfterNotInCart", Utils.copyAsObject(items));
        }

        // 过滤召回物料
        if (filterSellCodeEnabled) {
            items = items.stream().filter(item -> !filterSellCodes.contains((String) item.get("sell_code"))).collect(Collectors.toList());
            log.debug("transactionId[{}], after filter sellCode, {}", transactionIdTreadLocal.get(), items);
            context.getExtraData().put("itemAfterInBlacklist", Utils.copyAsObject(items));
        }

        //过滤购物车中用户添加的物料的 subCategory
        Set<String> excludeCertainItem = shoppingCartSubcategories.stream()
                .map(excludeCertainItemMap::get)
                .filter(StringUtils::isNotEmpty)
                .flatMap(itemList -> Arrays.stream(itemList.split("\\|")))
                .collect(Collectors.toSet());
        items = items.stream().filter(item -> !excludeCertainItem.contains((String) item.get("sell_code"))).collect(Collectors.toList());
        log.debug("transactionId[{}], excludeCertainItem[{}]", transactionIdTreadLocal.get(), excludeCertainItem);
        context.getExtraData().put("excludeCertainItem", excludeCertainItem);


        if (filterWeekdayEnabled) {
            Map<Integer, Object> weekdayItems = (Map<Integer, Object>) JSON.parse(filterWeekdayItems);
            List<String> filterItems = (List<String>) weekdayItems.get(LocalDateTime.now().getDayOfWeek().getValue());
            if (filterItems != null && filterItems.size() > 0) {
                items = items.stream().filter(item -> !filterItems.contains((String) item.get("sell_code"))).collect(Collectors.toList());
            }
            log.debug("transactionId[{}], alter filtered by discount is {}", transactionIdTreadLocal.get(), Utils.copyAsObject(items));
        }

        if (filterDayPartEnabled) {
            Map<Integer, Object> dayPartItems = (Map<Integer, Object>) JSON.parse(filterDayPartItems);
            List<String> filterItems = (List<String>) dayPartItems.get(daypart);
            if (filterItems != null && filterItems.size() > 0) {
                items = items.stream().filter(item -> !filterItems.contains((String) item.get("sell_code"))).collect(Collectors.toList());
            }
            log.debug("transactionId[{}], alter filtered by discount is {}", transactionIdTreadLocal.get(), Utils.copyAsObject(items));
        }


        return items;
    }

    /**
     * 根据购物车中的 subclass 去重，注意：由于一些原因，item.get("subCategory")实际获取的是 subclass
     *
     * @param shoppingCartSubclasses
     * @param item
     * @return
     */
    private boolean notInCart(Set<String> shoppingCartSubclasses, Map<String, Object> item) {
        String subCategory = (String) item.get("subCategory");
        return !shoppingCartSubclasses.contains(subCategory);
    }

    private boolean validSize(int... lengths) {
        assert lengths.length >= 2;
        boolean equal = true;
        int len0 = lengths[0];
        for (int i = 1; i < lengths.length; i++) {
            equal &= (len0 == lengths[i]);
        }
        return equal;
    }
}
