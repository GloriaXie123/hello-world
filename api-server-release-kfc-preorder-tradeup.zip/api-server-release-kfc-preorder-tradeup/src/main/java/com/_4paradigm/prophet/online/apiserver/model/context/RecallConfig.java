package com._4paradigm.prophet.online.apiserver.model.context;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class RecallConfig {
    Map<String, List<String>> inclusiveKeys;
    Map<String, List<String>> exclusiveKeys;
    String expression;
}
