package com._4paradigm.prophet.online.apiserver.service;


import com._4paradigm.prophet.online.apiserver.model.dto.api_server.req.predictReqDTO;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespContext;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespDTO;
import com._4paradigm.prophet.online.apiserver.model.dto.api_server.resp.PredictRespData;
import com._4paradigm.prophet.online.apiserver.repository.rtidb.RtiDBTable;
import com.google.common.base.Joiner;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.*;

@Slf4j
@Service
public class ForcePushService {

    @Value("${pt.forcePush.items}")
    private String forcePushItems;

    @Value("${tradeup.returnItems.limit:4}")
    private Integer itemLimit;

    @Autowired
    private RtiDBTable rtiDBTable;

    //每日物料表 p_rtidb_tradeup_product_list_daily
    @Value("${pr.filtrationSoldOut.tableName}")
    private String filtrationSoldOutTableName;
    private RtiDBTable filtrationSoldOutPriceTable;

    @PostConstruct
    private void initRtidbTables() {
        filtrationSoldOutPriceTable = rtiDBTable.getTable(filtrationSoldOutTableName);
    }

    //查询每日物料表
    public Map<String, Object> get() {
        return filtrationSoldOutPriceTable.getRow("brand","KFC_PRE");
    }

    public String getForcePushItems(String forcePushItems) {
        Map<String, Object> map = get();
        if (map.isEmpty()) {
            log.warn("getLinkIdCouponcodePrice is null!");
            return forcePushItems;
        }

        List<String> list = new ArrayList<>();
        String promotioncode = ","+map.get("promotioncode")+",";

        String str[] = forcePushItems.split(",");
        List<String> strings = Arrays.asList(str);

        for (String i : strings) {
            if (promotioncode.contains(","+i+",")){
                list.add(i);
            }
        }
        return Joiner.on(",").join(list);
    }

    /****
     * 根据强推逻辑,判断是否推
     */
    public PredictRespDTO forcePush(predictReqDTO reqDTO) {

        //返回值类型
        PredictRespContext respCtx = new PredictRespContext();
        String timestamp = String.valueOf(System.currentTimeMillis());
        String address = System.getenv("MY_POD_IP");
        String thread = String.valueOf(Thread.currentThread().getId());
        String uniqid = Base64
                .encodeBase64String(String.join(",", timestamp, address, thread).getBytes());

        String experimentId = reqDTO.getContext().getExperimentId();

        respCtx.setExperimentId(experimentId);
        respCtx.setRecallConfigVersion("Unknown");
        respCtx.setUniqueId(uniqid);

        PredictRespData respData = new PredictRespData();
        respData.setContext(respCtx);

        List<Map<String, Object>> data = new ArrayList<>();

        forcePushItems = getForcePushItems(forcePushItems);
        log.debug("after forcePushItems:"+forcePushItems.toString());

        String[] fpItems = forcePushItems.split(",");

        int limit = Math.min(fpItems.length, itemLimit);
        int rank = 1;

        for (String promotionCode : fpItems) {
            Map<String, Object> transItem = new HashMap<>(2);

            transItem.put("promotionCode", promotionCode);
            transItem.put("rank", String.valueOf(rank));
            data.add(transItem);

            if (rank >= limit) {
                break;
            } else {
                rank++;
            }
        }

        respData.setList(data);

        PredictRespDTO respDTO = new PredictRespDTO();
        respDTO.setRetCode(200);
        respDTO.setMessage("success");
        respDTO.setData(respData);
        return respDTO;

    }

}
