#!/bin/sh

set -x

if [ "$DEBUG_MODE" = "true" ]; then
    echo "enable debug mode"
    while true; do sleep 2; date; done
else
    chmod +x bin/*
    mkdir -p logs
    echo "starting filebeat"
    echo "kafka endpoints: $KAFKA_ENDPOINTS"
    echo "kafka topic: $KAFKA_TOPIC"
    echo "max message size: $MAX_MESSAGE_BYTES"
    nohup ./bin/filebeat -e -c conf/as_filebeat.yml > logs/filebeat.log 2>&1 &
    ./bin/app.sh
fi